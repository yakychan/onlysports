<?php
// ****** ACTIVAR ERRORES PARA DEBUG ******
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// ****** FIN ACTIVAR ERRORES ******
session_start();
// --- CONFIGURACIÓN LOGIN PANEL (idéntica a index.php) ---
$valid_username = 'admin';
// ¡Usa un hash SHA-256 real de tu contraseña! Puedes generarlo online o con: echo hash('sha256', 'tu_contraseña_aqui');
// para generar pueden usar: https://emn178.github.io/online-tools/sha256.html
$valid_password_hash = '8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918'; // Reemplaza con tu hash real, defecto es admin
$login_error = '';
$is_logged_in = isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in'] === true;
// --- Lógica de Login/Logout del Panel ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'login') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    $entered_password_hash = hash('sha256', $password);
    if ($username === $valid_username && hash_equals($valid_password_hash, $entered_password_hash)) {
        $_SESSION['user_logged_in'] = true;
        session_regenerate_id(true);
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    } else {
        $login_error = 'Usuario o contraseña incorrectos.';
        $is_logged_in = false;
    }
}
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_unset();
    session_destroy();
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}
// --- CONFIGURACIÓN DE ENCRIPTACIÓN (idéntica a index.php) ---
define('AES_KEY', 'CLAVEAESIGUALQUELAAPP');
define('AES_IV', 'CLAVEAESIGUALQUELAAPP');
define('AES_METHOD', 'aes-256-cbc');
// --- Funciones de Cifrado/Descifrado (reutilizadas) ---
function encryptData($data) { 
    $jsonString = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); 
    if ($jsonString === false) throw new Exception("PHP: Error JSON Encode: " . json_last_error_msg());
    $encrypted = openssl_encrypt($jsonString, AES_METHOD, AES_KEY, OPENSSL_RAW_DATA, AES_IV); 
    if ($encrypted === false) throw new Exception("PHP: Error OpenSSL Encrypt: " . openssl_error_string()); 
    return base64_encode($encrypted); 
}
function decryptData($base64EncryptedData) { 
    $encrypted = base64_decode($base64EncryptedData); 
    if ($encrypted === false) throw new Exception("PHP: Error Base64 Decode"); 
    $decryptedJson = openssl_decrypt($encrypted, AES_METHOD, AES_KEY, OPENSSL_RAW_DATA, AES_IV); 
    if ($decryptedJson === false) { 
        $decryptedJson = openssl_decrypt($encrypted, AES_METHOD, AES_KEY, 0, AES_IV); 
        if ($decryptedJson === false) throw new Exception("PHP: Error OpenSSL Decrypt: " . openssl_error_string()); 
    } 
    $data = json_decode($decryptedJson, true); 
    if ($data === null && json_last_error() !== JSON_ERROR_NONE) throw new Exception("PHP: Error JSON Decode post-decrypt: " . json_last_error_msg()); 
    if (!is_array($data)) return []; 
    return $data; 
}
// --- loadData y saveData (versiones genéricas de load/saveChannels) ---
function loadData($file): array { 
    if (file_exists($file)) { 
        if (!is_readable($file)) return ['error' => "PHP CRITICAL: Cannot read file '$file'. Check permissions."]; 
        $base64EncryptedData = file_get_contents($file); 
        if ($base64EncryptedData === false) return ['error' => "PHP CRITICAL: Failed to read file content from '$file'."]; 
        if (empty(trim($base64EncryptedData))) { return []; } 
        try { return decryptData($base64EncryptedData); } 
        catch (Exception $e) { return ['error' => "PHP CRITICAL: Could not decrypt/parse '$file'. Error: " . $e->getMessage()]; } 
    } else { 
        $dir = dirname($file); 
        if (!is_writable($dir)) return ['error' => "PHP CRITICAL: File '$file' not found AND directory '$dir' is not writable."]; 
        try { 
            $initialEncryptedData = encryptData([]); 
            if (file_put_contents($file, $initialEncryptedData) === false) return ['error' => "PHP CRITICAL: Could not create initial empty encrypted file '$file'."]; 
            @chmod($file, 0664); 
            return []; 
        } catch (Exception $e) { return ['error' => "PHP CRITICAL: Could not create initial file. Error: " . $e->getMessage()]; } 
    } 
}
function saveData($file, $data, $successMessage, $anchor = '#list-section'): array { 
    $dataToSave = is_array($data) ? array_values($data) : []; 
    try { 
        $base64EncryptedData = encryptData($dataToSave); 
        $dir = dirname($file); 
        if (!is_writable($dir)) return ['error' => "PHP Save Error: Directory '$dir' not writable."]; 
        if (file_exists($file) && !is_writable($file)) return ['error' => "PHP Save Error: File '$file' not writable."]; 
        if (file_put_contents($file, $base64EncryptedData, LOCK_EX) === false) throw new Exception("PHP: Failed to write to '$file'."); 
        $timestamp = time(); 
        $protocol = (!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')?"https":"http://"; 
        $host=$_SERVER['HTTP_HOST']; 
        $script_path = dirname($_SERVER['SCRIPT_NAME']); 
        $script_name = basename($_SERVER['SCRIPT_NAME']); 
        $baseUrl = $protocol . $host . ($script_path === '/' ? '' : $script_path) . '/' . $script_name; 
        if($anchor&&$anchor[0]!=='#'){$anchor='#'.$anchor;} 
        $redirectUrl=$baseUrl."?message=".urlencode($successMessage)."&t=".$timestamp.($anchor??''); 
        header("Location: " . $redirectUrl); 
        exit; 
    } catch (Exception $e) { 
        $errMsg = "PHP Save Error: " . $e->getMessage(); 
        return ['error' => $errMsg]; 
    } 
}
// ================================================================
// FORMULARIO DE LOGIN (si no está logueado)
// ================================================================
if (!$is_logged_in) { 
    error_log("PHP: User not logged in, showing login form.");
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Editor de Películas</title>
    <style>
        body{
            font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen,Ubuntu,Cantarell,"Open Sans","Helvetica Neue",sans-serif;
            background-color:#1a202c;
            color:#e2e8f0;
            display:flex;
            justify-content:center;
            align-items:center;
            min-height:100vh;
            margin:0;
        }
        .login-container{
            background-color:#2d3748;
            padding:35px 45px;
            border-radius:8px;
            box-shadow:0 4px 12px rgba(0,0,0,0.3);
            text-align:center;
            max-width:400px;
            width:90%;
            border:1px solid #4a5568;
        }
        h1{
            margin-bottom:30px;
            color:#fff;
            font-size:1.9em;
            font-weight:600;
        }
        .form-group{
            margin-bottom:20px;
            text-align:left;
        }
        label{
            display:block;
            margin-bottom:6px;
            font-weight:600;
            color:#a0aec0;
            font-size:.95em;
        }
        input[type=text],input[type=password]{
            width:100%;
            padding:11px 14px;
            border:1px solid #4a5568;
            border-radius:6px;
            box-sizing:border-box;
            font-size:1em;
            background-color:#1a202c;
            color:#e2e8f0;
        }
        input[type=text]::placeholder,input[type=password]::placeholder{
            color:#718096;
        }
        input[type=text]:focus,input[type=password]:focus{
            border-color:#3182ce;
            box-shadow:0 0 0 3px rgba(66,153,225,.5);
            outline:0;
            background-color:#2d3748;
        }
        button{
            background-color:#3182ce;
            color:#fff;
            padding:12px 20px;
            border:none;
            border-radius:6px;
            cursor:pointer;
            font-size:1.1em;
            font-weight:600;
            width:100%;
            transition:background-color .2s ease;
            margin-top:10px;
        }
        button:hover{
            background-color:#2b6cb0;
        }
        .error-message{
            color:#f56565;
            margin-top:15px;
            margin-bottom:0;
            font-size:.9em;
            font-weight:500;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h1>Editor de Películas</h1>
        <?php if($login_error):?>
        <p class="error-message"><?=htmlspecialchars($login_error)?></p>
        <?php endif;?>
        <form method="POST" action="<?=htmlspecialchars($_SERVER['PHP_SELF'])?>">
            <input type="hidden" name="action" value="login">
            <div class="form-group">
                <label for="username">Usuario:</label>
                <input type="text" id="username" name="username" required autofocus>
            </div>
            <div class="form-group">
                <label for="password">Contraseña:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit">Entrar</button>
        </form>
    </div>
</body>
</html>
<?php exit; }
// --- SI LLEGAMOS AQUÍ, EL USUARIO ESTÁ LOGUEADO ---
$jsonFile = 'peliculas.json';
$categories = [];
$message = $_GET['message'] ?? ''; if ($message) $message = htmlspecialchars(urldecode($message));
$error = '';
$totalMoviesCount = 0;
$editMovieModal = false; $editData = null; $editCatIndex = null; $editSampleIndex = null;
$editCategoryMode = false; $editCategoryIndex = null; $editCategoryName = '';
$postersDirName = 'posters';
$postersDir = __DIR__ . '/' . $postersDirName;
$protocol = (!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')?"https":"http://";
$host = $_SERVER['HTTP_HOST'];
$scriptPath = dirname($_SERVER['PHP_SELF']);
$postersBaseUrl = $protocol . $host . ($scriptPath === '/' ? '' : $scriptPath) . '/' . $postersDirName . '/';
// Carga de datos inicial para el panel
$loadResult = loadData($jsonFile);
if (isset($loadResult['error'])) { $error = $loadResult['error']; } else { 
    $categories = $loadResult; 
    if (is_array($categories)) { 
        foreach ($categories as $category) { 
            if (is_array($category) && isset($category['samples']) && is_array($category['samples'])) { 
                $totalMoviesCount += count($category['samples']); 
            } 
        } 
    } else { 
        $error = "Error: Formato de datos de películas inválido."; 
        $categories = []; 
    } 
}
// --- Procesamiento de Acciones GET (lectura) ---
$searchTerm = trim($_GET['search'] ?? ''); $isSearchActive = !empty($searchTerm);
if ($_SERVER['REQUEST_METHOD'] === 'GET' && empty($error)) {
    $action = $_GET['action'] ?? '';
    if (!$isSearchActive) {
        if ($action === 'edit') { 
            $catIndexGet = filter_input(INPUT_GET, 'cat', FILTER_VALIDATE_INT); 
            $sampleIndexGet = filter_input(INPUT_GET, 'sample', FILTER_VALIDATE_INT); 
            if ($catIndexGet !== false && $catIndexGet !== null && $sampleIndexGet !== false && $sampleIndexGet !== null && isset($categories[$catIndexGet]['samples'][$sampleIndexGet])) { 
                $editMovieModal = true; 
                $editCatIndex = $catIndexGet; 
                $editSampleIndex = $sampleIndexGet; 
                $editData = $categories[$catIndexGet]['samples'][$sampleIndexGet]; 
            } else { 
                $error = "Error: Película para editar no encontrada."; 
            } 
        } 
        elseif ($action === 'edit_category') { 
            $catIndexGet = filter_input(INPUT_GET, 'cat', FILTER_VALIDATE_INT); 
            if ($catIndexGet !== false && $catIndexGet !== null && isset($categories[$catIndexGet])) { 
                $editCategoryMode = true; 
                $editCategoryIndex = $catIndexGet; 
                $editCategoryName = $categories[$catIndexGet]['name'] ?? ''; 
            } else { 
                $error = "Error: Categoría para editar no encontrada."; 
            } 
        }
    }
}
// --- Procesamiento de Acciones POST y GET (modificación) ---
if (($_SERVER['REQUEST_METHOD'] === 'POST' || ($_SERVER['REQUEST_METHOD'] === 'GET' && in_array(($_GET['action'] ?? ''), ['move_movie', 'sort_category', 'download_decrypted', 'move_category']))) && empty($error)) {
    $action = $_POST['action'] ?? $_GET['action'] ?? '';
    $postMessage = ''; $postError = ''; $redirectAnchor = '#list-section';
    if ($action === 'login') $action = '';
    if (!empty($action)) {
        if ($action === 'download_decrypted') {
            try { 
                $dataToDownload = loadData($jsonFile); 
                if(isset($dataToDownload['error'])) { 
                    throw new Exception($dataToDownload['error']); 
                } 
                $jsonOutput = json_encode($dataToDownload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); 
                if ($jsonOutput === false) { 
                    throw new Exception("Error al codificar el JSON: " . json_last_error_msg()); 
                } 
                header('Content-Type: application/json; charset=utf-8'); 
                header('Content-Disposition: attachment; filename="peliculas_decrypted.json"'); 
                header('Content-Length: ' . strlen($jsonOutput)); 
                echo $jsonOutput; 
                exit; 
            } catch (Exception $e) { 
                $postError = "Error al descargar: " . $e->getMessage(); 
            }
        }
        $posterHandlingError = false;
        if (!is_dir($postersDir)) { 
            if (!@mkdir($postersDir, 0775, true)) { 
                $postError .= " Error Crítico: No se pudo crear directorio '$postersDirName'. "; 
                $posterHandlingError = true; 
            } else { 
                @file_put_contents($postersDir . '/.htaccess', 'Options -Indexes'); 
            } 
        } elseif (!is_writable($postersDir)) { 
            $postError .= " Error Crítico: Directorio '$postersDirName' no tiene permisos escritura. "; 
            $posterHandlingError = true; 
        }
        try {
            $currentLoadResult = loadData($jsonFile);
            if (isset($currentLoadResult['error'])) { 
                throw new Exception("Fallo al recargar datos: " . $currentLoadResult['error']); 
            }
            $categories = $currentLoadResult;
            if (($action === 'add' || $action === 'edit') && !$posterHandlingError && $_SERVER['REQUEST_METHOD'] === 'POST') {
                $newCatIndex = filter_input(INPUT_POST, 'category_index', FILTER_VALIDATE_INT);
                $name = trim(filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING, FILTER_FLAG_NO_ENCODE_QUOTES));
                $sinopsis = trim(filter_input(INPUT_POST, 'sinopsis', FILTER_SANITIZE_STRING, FILTER_FLAG_NO_ENCODE_QUOTES));
                $anio = trim(filter_input(INPUT_POST, 'anio', FILTER_SANITIZE_STRING));
                $uri = trim(filter_input(INPUT_POST, 'uri', FILTER_SANITIZE_URL));
                $inputIconoUrl = trim(filter_input(INPUT_POST, 'icono', FILTER_SANITIZE_URL));
                if ($newCatIndex === false || $newCatIndex === null || !isset($categories[$newCatIndex])) throw new Exception('Categoría inválida.');
                if (empty($name)) throw new Exception('Título de la película es obligatorio.');
                if (empty($uri) || !filter_var($uri, FILTER_VALIDATE_URL)) throw new Exception('URI obligatoria y válida.');
                $finalIconoUrl = ''; $posterOpMessage = ''; $existingIconoUrl = '';
                if ($action === 'edit') { 
                    $sampleIndexCheck = filter_input(INPUT_POST, 'sample_index', FILTER_VALIDATE_INT); 
                    $originalCatIndexCheck = filter_input(INPUT_POST, 'original_category_index', FILTER_VALIDATE_INT); 
                    if ($sampleIndexCheck !== false && $originalCatIndexCheck !== false && isset($categories[$originalCatIndexCheck]['samples'][$sampleIndexCheck]['icono'])) { 
                        $existingIconoUrl = $categories[$originalCatIndexCheck]['samples'][$sampleIndexCheck]['icono']; 
                    } 
                    $finalIconoUrl = $existingIconoUrl; 
                }
                if (!empty($inputIconoUrl) && filter_var($inputIconoUrl, FILTER_VALIDATE_URL)) { 
                    if (strpos($inputIconoUrl, $postersBaseUrl) === 0) { 
                        $finalIconoUrl = $inputIconoUrl; 
                    } else { 
                        $imageData = @file_get_contents($inputIconoUrl); 
                        if ($imageData === false) { 
                            $posterOpMessage .= " Advertencia: No se pudo descargar póster '$inputIconoUrl'. "; 
                        } else { 
                            $urlPath = parse_url($inputIconoUrl, PHP_URL_PATH);
                            $extension = $urlPath ? strtolower(pathinfo($urlPath, PATHINFO_EXTENSION)) : 'png'; 
                            $allowedExtensions = ['png', 'jpg', 'jpeg', 'gif', 'webp']; 
                            if (!in_array($extension, $allowedExtensions)) $extension = 'jpg'; 
                            $safeFilename = uniqid('poster_', true) . '.' . $extension; 
                            $localFilePath = $postersDir . '/' . $safeFilename; 
                            if (file_put_contents($localFilePath, $imageData) !== false) { 
                                $finalIconoUrl = $postersBaseUrl . $safeFilename; 
                                $posterOpMessage .= ' Póster descargado localmente.'; 
                            } else { 
                                $posterOpMessage .= " Advertencia: Póster descargado pero no guardado en '$postersDirName'. "; 
                            } 
                        } 
                    } 
                } elseif (empty($inputIconoUrl) && $action === 'edit') { 
                    $finalIconoUrl = ''; 
                }
                $movieData = [ 'name' => $name, 'uri' => $uri ];
                if (!empty($sinopsis)) $movieData['sinopsis'] = $sinopsis;
                if (!empty($anio)) $movieData['anio'] = $anio;
                if (!empty($finalIconoUrl)) $movieData['icono'] = $finalIconoUrl;
                if ($action === 'add') { 
                    if (!isset($categories[$newCatIndex]['samples'])) $categories[$newCatIndex]['samples'] = []; 
                    $categories[$newCatIndex]['samples'][] = $movieData; 
                    if(count($categories[$newCatIndex]['samples']) > 1) { 
                        usort($categories[$newCatIndex]['samples'], function($a, $b) { return strcasecmp($a['name'] ?? '', $b['name'] ?? ''); }); 
                        $baseMessage = 'Película agregada y categoría ordenada.'; 
                    } else { 
                        $baseMessage = 'Película agregada.'; 
                    } 
                    $postMessage = trim($baseMessage . $posterOpMessage); 
                    $redirectAnchor = '#cat' . $newCatIndex; 
                } 
                elseif ($action === 'edit') { 
                    $sampleIndex = filter_input(INPUT_POST, 'sample_index', FILTER_VALIDATE_INT); 
                    $originalCatIndex = filter_input(INPUT_POST, 'original_category_index', FILTER_VALIDATE_INT); 
                    if ($sampleIndex === false || $sampleIndex === null || $originalCatIndex === false || $originalCatIndex === null || !isset($categories[$originalCatIndex]['samples'][$sampleIndex])) throw new Exception('La película a editar no fue encontrada.'); 
                    if ($originalCatIndex == $newCatIndex) { 
                        $categories[$originalCatIndex]['samples'][$sampleIndex] = $movieData; 
                        $baseMessage = 'Película modificada.'; 
                        $redirectAnchor = '#cat' . $originalCatIndex; 
                    } else { 
                        array_splice($categories[$originalCatIndex]['samples'], $sampleIndex, 1); 
                        if (!isset($categories[$newCatIndex]['samples'])) $categories[$newCatIndex]['samples'] = []; 
                        $categories[$newCatIndex]['samples'][] = $movieData; 
                        if(count($categories[$newCatIndex]['samples']) > 1) { 
                            usort($categories[$newCatIndex]['samples'], function($a, $b) { return strcasecmp($a['name'] ?? '', $b['name'] ?? ''); }); 
                            $baseMessage = 'Película movida y categoría destino ordenada.'; 
                        } else { 
                            $baseMessage = 'Película movida.'; 
                        } 
                        $redirectAnchor = '#cat' . $newCatIndex; 
                    } 
                    $postMessage = trim($baseMessage . $posterOpMessage); 
                }
                $saveResult = saveData($jsonFile, $categories, $postMessage, $redirectAnchor); 
                if (isset($saveResult['error'])) $postError = $saveResult['error'];
            }
            elseif ($action === 'delete') { 
                $catIndex=filter_input(INPUT_POST,'category_index',FILTER_VALIDATE_INT); 
                $sampleIndex=filter_input(INPUT_POST,'sample_index',FILTER_VALIDATE_INT); 
                if($catIndex===false||$catIndex===null||$sampleIndex===false||$sampleIndex===null||!isset($categories[$catIndex]['samples'][$sampleIndex])) throw new Exception('Índices inválidos para eliminar.'); 
                $movieName=$categories[$catIndex]['samples'][$sampleIndex]['name']??'Desconocida'; 
                $redirectAnchor="#cat".$catIndex; 
                array_splice($categories[$catIndex]['samples'],$sampleIndex,1); 
                $postMessage='Película "'.htmlspecialchars($movieName).'" eliminada.'; 
                $saveResult=saveData($jsonFile,$categories,$postMessage,$redirectAnchor); 
                if(isset($saveResult['error'])) $postError=$saveResult['error']; 
            }
            elseif ($action === 'add_category') { 
                $newCategoryName=trim(filter_input(INPUT_POST,'new_category_name',FILTER_SANITIZE_STRING,FILTER_FLAG_NO_ENCODE_QUOTES)); 
                if(empty($newCategoryName)) throw new Exception("Nombre de categoría vacío."); 
                foreach($categories as $category) if(isset($category['name'])&&strcasecmp($category['name'],$newCategoryName)===0) throw new Exception("Categoría '".htmlspecialchars($newCategoryName)."' ya existe."); 
                $categories[]=['name'=>$newCategoryName,'samples'=>[]]; 
                $postMessage="Categoría '".htmlspecialchars($newCategoryName)."' agregada."; 
                $newCatAddedIndex=count($categories)-1; 
                $redirectAnchor="#cat".$newCatAddedIndex; 
                $saveResult=saveData($jsonFile,$categories,$postMessage,$redirectAnchor); 
                if(isset($saveResult['error'])) $postError=$saveResult['error']; 
            }
            elseif ($action === 'update_category') { 
                $catIndex=filter_input(INPUT_POST,'category_index',FILTER_VALIDATE_INT); 
                $newCategoryName=trim(filter_input(INPUT_POST,'new_category_name',FILTER_SANITIZE_STRING,FILTER_FLAG_NO_ENCODE_QUOTES)); 
                if($catIndex===false||$catIndex===null||!isset($categories[$catIndex])) throw new Exception("Índice de categoría inválido."); 
                if(empty($newCategoryName)) throw new Exception("Nuevo nombre de categoría vacío."); 
                foreach($categories as $index=>$category) if($index!=$catIndex&&isset($category['name'])&&strcasecmp($category['name'],$newCategoryName)===0) throw new Exception("Ya existe categoría '".htmlspecialchars($newCategoryName)."'."); 
                $oldCategoryName=$categories[$catIndex]['name']; 
                $categories[$catIndex]['name']=$newCategoryName; 
                $postMessage="Categoría renombrada de '".htmlspecialchars($oldCategoryName)."' a '".htmlspecialchars($newCategoryName)."."; 
                $redirectAnchor="#cat".$catIndex; 
                $saveResult=saveData($jsonFile,$categories,$postMessage,$redirectAnchor); 
                if(isset($saveResult['error'])) $postError=$saveResult['error']; 
            }
            elseif ($action === 'delete_category') { 
                $catIndex=filter_input(INPUT_POST,'category_index',FILTER_VALIDATE_INT); 
                if($catIndex===false||$catIndex===null||!isset($categories[$catIndex])) throw new Exception('Índice de categoría inválido para eliminar.'); 
                $categoryName=$categories[$catIndex]['name']??'Desconocida'; 
                array_splice($categories,$catIndex,1); 
                $postMessage='Categoría "'.htmlspecialchars($categoryName).'" eliminada.'; 
                $redirectAnchor="#list-section"; 
                $saveResult=saveData($jsonFile,$categories,$postMessage,$redirectAnchor); 
                if(isset($saveResult['error'])) $postError=$saveResult['error']; 
            }
            elseif ($action === 'move_movie') { 
                $catIndex=filter_input(INPUT_GET,'cat',FILTER_VALIDATE_INT); 
                $sampleIndex=filter_input(INPUT_GET,'sample',FILTER_VALIDATE_INT); 
                $direction=filter_input(INPUT_GET,'dir',FILTER_SANITIZE_STRING); 
                if($catIndex===false||$sampleIndex===false||!isset($categories[$catIndex]['samples'][$sampleIndex])||!in_array($direction,['up','down'])) throw new Exception('Parámetros para mover película inválidos.'); 
                $samples=&$categories[$catIndex]['samples']; 
                $count=count($samples); 
                $newIndex=-1; 
                if($direction==='up'&&$sampleIndex>0) $newIndex=$sampleIndex-1; 
                elseif($direction==='down'&&$sampleIndex<$count-1) $newIndex=$sampleIndex+1; 
                if($newIndex!==-1){ 
                    $itemToMove=array_splice($samples,$sampleIndex,1)[0]; 
                    array_splice($samples,$newIndex,0,[$itemToMove]); 
                    $saveResult=saveData($jsonFile,$categories,"Película reordenada.","#cat".$catIndex); 
                    if(isset($saveResult['error'])) $postError=$saveResult['error']; 
                } 
            }
            elseif ($action === 'sort_category') { 
                $catIndex = filter_input(INPUT_GET, 'cat', FILTER_VALIDATE_INT); 
                if ($catIndex===false||!isset($categories[$catIndex]['samples'])) throw new Exception('Categoría para ordenar inválida.'); 
                if (count($categories[$catIndex]['samples'])>1) { 
                    usort($categories[$catIndex]['samples'], function($a,$b) { return strcasecmp($a['name']??'',$b['name']??''); }); 
                    $categoryName=$categories[$catIndex]['name']; 
                    $saveResult=saveData($jsonFile, $categories, "Categoría '".htmlspecialchars($categoryName)."' ordenada A-Z.", "#cat".$catIndex); 
                    if(isset($saveResult['error'])) $postError=$saveResult['error']; 
                } 
            }
            elseif ($action === 'move_category') { 
                $catIndex = filter_input(INPUT_GET,'cat',FILTER_VALIDATE_INT); 
                $direction = filter_input(INPUT_GET,'dir',FILTER_SANITIZE_STRING); 
                if($catIndex===false||!isset($categories[$catIndex])||!in_array($direction,['up','down'])) throw new Exception('Parámetros para mover categoría inválidos.'); 
                $totalCats = count($categories); 
                $newIndex = -1; 
                if ($direction==='up'&&$catIndex>0) $newIndex=$catIndex-1; 
                elseif($direction==='down'&&$catIndex<$totalCats-1) $newIndex=$catIndex+1; 
                if($newIndex!==-1){ 
                    $itemToMove=array_splice($categories,$catIndex,1)[0]; 
                    array_splice($categories,$newIndex,0,[$itemToMove]); 
                    $saveResult=saveData($jsonFile, $categories, "Categoría reordenada.", "#cat".$newIndex); 
                    if(isset($saveResult['error'])) $postError=$saveResult['error']; 
                } 
            }
        } catch (Exception $e) { 
            $postError = 'Error: ' . $e->getMessage(); 
        }
        if (!empty($postError)) { 
            $error = $postError; 
            $loadResultOnError = loadData($jsonFile); 
            if (isset($loadResultOnError['error'])) { 
                $error.=" | ADVERTENCIA: Fallo al recargar datos tras error: ".$loadResultOnError['error']; 
            } else { 
                $categories = $loadResultOnError; 
                $totalMoviesCount = 0; 
                if(is_array($categories)){foreach($categories as $cat)if(is_array($cat)&&isset($cat['samples'])) $totalMoviesCount+=count($cat['samples']);} 
            } 
        }
    }
} 
if ($is_logged_in) {
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editor de Películas</title>
    <style>
        :root{
            --primary-color:#3182ce;
            --primary-hover:#2b6cb0;
            --danger-color:#e53e3e;
            --danger-hover:#c53030;
            --success-color:#38a169;
            --success-hover:#2f855a;
            --info-color:#319795;
            --info-hover:#2c7a7b;
            --secondary-color-bg:#4a5568;
            --secondary-color-hover:#2d3748;
            --secondary-color-text:#a0aec0;
            --bg-color:#212d40;
            --bg-alt-color:#2c3b52;
            --bg-table-row-alt:#273549;
            --bg-table-header:#3b506c;
            --bg-input:#3b506c;
            --bg-input-focus:#45617e;
            --text-color:#fff;
            --text-alt-color:#e2e8f0;
            --text-secondary-color:#a0aec0;
            --border-color:#4a5568;
            --link-color:#63b3ed;
            --link-hover-color:#90cdf4;
            --error-bg:#f8d7da;
            --error-text:#721c24;
            --error-border:#f5c6cb;
            --success-bg:#d4edda;
            --success-text:#155724;
            --success-border:#c3e6cb;
            --warning-bg:#fff3cd;
            --warning-text:#856404;
            --warning-border:#ffeeba;
            --font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen,Ubuntu,Cantarell,"Open Sans","Helvetica Neue",sans-serif;
            --border-radius:6px;
            --box-shadow:0 4px 12px rgba(0,0,0,.3)
        }
        body{
            font-family:var(--font-family);
            line-height:1.6;
            margin:0;
            padding:20px;
            background-color:var(--bg-color);
            color:var(--text-color);
            font-size:16px
        }
        .container{
            max-width:1300px;
            margin:20px auto;
            background-color:var(--bg-alt-color);
            padding:30px;
            border-radius:var(--border-radius);
            box-shadow:var(--box-shadow);
            border:1px solid var(--border-color)
        }
        .header-controls{
            display:flex;
            justify-content:space-between;
            align-items:center;
            margin-bottom:25px;
            padding-bottom:20px;
            border-bottom:1px solid var(--border-color);
            flex-wrap:wrap;
            gap:15px
        }
        .header-info{
            display:flex;
            align-items:center;
            gap:15px;
            flex-wrap:wrap
        }
        h1{
            margin:0;
            font-weight:600;
            font-size:1.9em;
            color:var(--text-color)
        }
        .data-count{
            background-color:var(--bg-table-header);
            color:var(--text-alt-color);
            padding:6px 14px;
            border-radius:15px;
            font-size:.9em;
            font-weight:500;
            white-space:nowrap
        }
        .header-actions{
            display:flex;
            align-items:center;
            gap:10px
        }
        .nav-btn{
            background-color:var(--success-color);
            color:#fff;
            padding:9px 16px;
            border:none;
            border-radius:var(--border-radius);
            cursor:pointer;
            text-decoration:none;
            font-size:.95em;
            white-space:nowrap;
            transition:background-color .2s ease;
            font-weight:500
        }
        .nav-btn:hover{
            background-color:var(--success-hover)
        }
        .logout-btn,.download-btn{
            color:#fff;
            padding:9px 16px;
            border:none;
            border-radius:var(--border-radius);
            cursor:pointer;
            text-decoration:none;
            font-size:.95em;
            white-space:nowrap;
            transition:background-color .2s ease;
            font-weight:500
        }
        .logout-btn{
            background-color:var(--danger-color)
        }
        .logout-btn:hover{
            background-color:var(--danger-hover)
        }
        .download-btn{
            background-color:var(--info-color);
            margin-right:5px
        }
        .download-btn:hover{
            background-color:var(--info-hover)
        }
        h2{
            margin-top:40px;
            margin-bottom:20px;
            font-size:1.6em;
            font-weight:600;
            border-bottom:1px solid var(--border-color);
            padding-bottom:10px;
            color:var(--text-alt-color)
        }
        h3{
            margin-top:35px;
            margin-bottom:5px;
            font-size:1.35em;
            font-weight:600;
            color:var(--text-alt-color);
            scroll-margin-top:70px;
            display:flex;
            align-items:center;
            flex-wrap:wrap;
            gap:10px
        }
        h3 small{
            font-weight:500;
            color:var(--text-secondary-color);
            font-size:.9em
        }
        .category-actions{
            display:flex;
            gap:8px;
            margin-bottom:15px;
            margin-left:5px;
            flex-wrap:wrap
        }
        .category-actions a,.category-actions button{
            padding:5px 10px;
            text-decoration:none;
            border-radius:var(--border-radius);
            font-size:.85em;
            cursor:pointer;
            border:1px solid transparent;
            vertical-align:middle;
            font-weight:500;
            transition:all .2s ease;
            white-space:nowrap
        }
        .category-actions button{
            font-family:inherit
        }
        .category-actions form{
            display:inline-block;
            vertical-align:middle;
            margin:0
        }
        .move-btn{
            background-color:var(--secondary-color-bg);
            border-color:var(--secondary-color-bg);
            color:var(--text-alt-color);
            font-size:1.2em;
            padding:3px 7px !important
        }
        .move-btn:not(.disabled):hover{
            background-color:var(--secondary-color-hover);
            border-color:var(--secondary-color-hover)
        }
        .move-btn.disabled{
            background-color:#2d3748;
            border-color:#2d3748;
            color:var(--secondary-color-text);
            cursor:not-allowed;
            pointer-events:none;
            opacity:.5
        }
        .edit-cat-btn{
            border-color:var(--secondary-color-bg);
            background-color:var(--bg-input-focus);
            color:var(--text-alt-color)
        }
        .edit-cat-btn:hover{
            background-color:var(--secondary-color-bg);
            border-color:var(--secondary-color-hover)
        }
        .delete-cat-btn{
            background-color:var(--danger-color);
            border-color:var(--danger-color);
            color:#fff
        }
        .delete-cat-btn:hover{
            background-color:var(--danger-hover);
            border-color:var(--danger-hover)
        }
        hr{
            margin:40px 0;
            border:0;
            border-top:1px solid var(--border-color)
        }
        form{
            background-color:#2c3b52cc;
            padding:25px 30px;
            border:1px solid var(--border-color);
            border-radius:var(--border-radius)
        }
        form>div{
            margin-bottom:18px
        }
        form label{
            display:block;
            margin-bottom:6px;
            font-weight:600;
            color:var(--text-alt-color)
        }
        form input[type=text],
        form input[type=url],
        form select,
        form textarea,
        form input[type=search]{
            width:100%;
            padding:10px 13px;
            border:1px solid var(--border-color);
            border-radius:var(--border-radius);
            box-sizing:border-box;
            font-size:1em;
            background-color:var(--bg-input);
            color:var(--text-color)
        }
        form textarea{
            min-height:80px;
            resize:vertical
        }
        form input:focus,
        form select:focus,
        form textarea:focus,
        form input[type=search]:focus{
            border-color:var(--primary-color);
            outline:0;
            box-shadow:0 0 0 .2rem rgba(49,130,206,.3);
            background-color:var(--bg-input-focus)
        }
        form button[type=submit],
        form a.cancel-btn{
            background-color:var(--primary-color);
            color:#fff;
            padding:11px 20px;
            border:none;
            border-radius:var(--border-radius);
            cursor:pointer;
            font-size:1.05em;
            font-weight:500;
            text-decoration:none;
            display:inline-block;
            transition:background-color .2s ease;
            margin-top:10px
        }
        form button[type=submit]:hover{
            background-color:var(--primary-hover)
        }
        form a.cancel-btn{
            background-color:var(--secondary-color-bg);
            color:var(--text-alt-color);
            margin-left:10px
        }
        .message{
            padding:14px 20px;
            margin-bottom:25px;
            border-radius:var(--border-radius);
            border:1px solid transparent;
            font-size:1em;
            font-weight:500
        }
        .success{
            background-color:var(--success-bg);
            color:var(--success-text);
            border-color:var(--success-border)
        }
        .error{
            background-color:var(--error-bg);
            color:var(--error-text);
            border-color:var(--error-border)
        }
        .warning{
            background-color:var(--warning-bg);
            color:var(--warning-text);
            border-color:var(--warning-border)
        }
        table{
            width:100%;
            border-collapse:collapse;
            margin-top:0;
        }
        th,td{
            border:1px solid var(--border-color);
            padding:10px 12px;
            text-align:left;
            vertical-align:middle;
            font-size:.93em
        }
        th{
            background-color:var(--bg-table-header);
            font-weight:600
        }
        tr:nth-child(even){
            background-color:var(--bg-table-row-alt)
        }
        tr:hover{
            background-color:var(--bg-input-focus)
        }
        td img.icon{
            max-width:48px;
            max-height:70px;
            vertical-align:middle;
            margin-right:8px;
            object-fit:contain;
            background-color:var(--bg-table-header);
            padding:2px;
            border-radius:4px;
            border:1px solid var(--border-color)
        }
        td span.na{
            color:var(--text-secondary-color);
            font-style:italic
        }
        .uri-cell{
            max-width:200px;
            overflow:hidden;
            text-overflow:ellipsis;
            white-space:nowrap;
            display:inline-block;
            vertical-align:middle;
            cursor:help
        }
        .sinopsis-cell{
            max-width:250px;
            overflow:hidden;
            text-overflow:ellipsis;
            white-space:nowrap !important;
            display:block;
        }
        td.actions{
            text-align:center;
            white-space:nowrap;
            width:auto;
            padding:6px 8px
        }
        td.actions a, td.actions button{
            display:inline-block;
            margin:3px 4px;
            padding:6px 10px;
            text-decoration:none;
            border-radius:var(--border-radius);
            font-size:.9em;
            cursor:pointer;
            border:1px solid transparent;
            vertical-align:middle;
            font-weight:500;
            transition:all .2s ease;
            color:#fff
        }
        td.actions form{
            display:inline-block;
            padding:0;
            margin:0;
            vertical-align:middle
        }
        td.actions .edit-btn{
            background-color:var(--success-color)
        }
        td.actions .edit-btn:hover{
            background-color:var(--success-hover)
        }
        td.actions .delete-btn{
            background-color:var(--danger-color)
        }
        td.actions .delete-btn:hover{
            background-color:var(--danger-hover)
        }
        td.actions .move-btn{
            font-size:1.2em;
            padding:3px 7px
        }
    </style>
</head>
<body>
    <div class="container">
        <header class="header-controls">
            <div class="header-info">
                <h1>Editor de Películas</h1>
                <?php if(empty($error)): ?><span class="data-count">Total: <?=$totalMoviesCount?> películas</span><?php endif; ?>
            </div>
            <div class="header-actions">
                <a href="index.php" class="nav-btn">Gestionar Canales</a>
                <a href="?action=download_decrypted" class="download-btn">Descargar JSON</a>
                <a href="?action=logout" class="logout-btn">Cerrar Sesión</a>
            </div>
        </header>
        <?php if($message):?><div class="message success" role="alert"><?=htmlspecialchars($message)?></div><?php endif;?>
        <?php if($error):?><div class="message error" role="alert"><?=htmlspecialchars($error)?></div><?php endif;?>
        <?php 
        $postersDirExists=is_dir($postersDir); 
        $postersDirWritable=$postersDirExists&&is_writable($postersDir); 
        if(!$postersDirWritable&&empty($error)){ 
            $permError=$postersDirExists?"La carpeta '$postersDirName' NO tiene permisos de escritura.":"La carpeta '$postersDirName' NO existe y no se pudo crear."; 
            echo "<div class='message warning' role='alert'><strong>Advertencia:</strong> $permError No se podrán guardar pósters localmente.</div>"; 
        }?>
        <section id="search-section">
            <form method="GET" action="peliculas.php" id="search-form">
                <label for="search-input">Buscar Película:</label>
                <input type="search" id="search-input" name="search" value="<?=htmlspecialchars($searchTerm)?>" placeholder="Título de la película...">
                <button type="submit">Buscar</button>
                <?php if($isSearchActive):?>
                <a href="peliculas.php" class="cancel-btn" style="margin-left: 5px;">Limpiar Búsqueda</a>
                <?php endif;?>
            </form>
        </section>
        <?php if(!$isSearchActive && empty($error)):?>
        <section id="category-forms-section">
            <?php if($editCategoryMode):?>
            <h2>Editar Nombre Categoría</h2>
            <form method="POST" action="peliculas.php#cat<?=$editCategoryIndex?>" id="edit-category-form">
                <input type="hidden" name="action" value="update_category">
                <input type="hidden" name="category_index" value="<?=htmlspecialchars((string)$editCategoryIndex)?>">
                <label for="edit_category_name">Nuevo nombre:</label>
                <input type="text" id="edit_category_name" name="new_category_name" required value="<?=htmlspecialchars($editCategoryName)?>" autofocus>
                <button type="submit">Guardar</button>
                <a href="peliculas.php#cat<?=htmlspecialchars((string)$editCategoryIndex)?>" class="cancel-btn">Cancelar</a>
            </form>
            <?php else:?>
            <h2>Agregar Nueva Categoría</h2>
            <form method="POST" action="peliculas.php#category-forms-section" id="add-category-form">
                <input type="hidden" name="action" value="add_category">
                <label for="new_category_name">Nombre:</label>
                <input type="text" id="new_category_name" name="new_category_name" required placeholder="Ej: Acción, Comedia...">
                <button type="submit">Agregar Categoría</button>
            </form>
            <?php endif;?>
        </section>
        <hr>
        <section id="form-section">
            <h2><?=$editMovieModal ? 'Modificar Película' : 'Agregar Nueva Película'?></h2>
            <form method="POST" action="peliculas.php#form-section" id="movie-form">
                <input type="hidden" name="action" value="<?=$editMovieModal ? 'edit' : 'add'?>">
                <?php if($editMovieModal):?><input type="hidden" name="sample_index" value="<?=htmlspecialchars((string)$editSampleIndex)?>"><input type="hidden" name="original_category_index" value="<?=htmlspecialchars((string)$editCatIndex)?>"><?php endif;?>
                <div>
                    <label for="category_select">Categoría:</label>
                    <select id="category_select" name="category_index" required>
                        <?=empty($categories)?'<option disabled selected>-- Agrega una categoría primero --</option>':''?>
                        <?php foreach($categories as $index=>$category): 
                            if(is_array($category)&&isset($category['name'])): 
                                echo "<option value=\"$index\" ".($editMovieModal&&$editCatIndex==$index?'selected':'').">".htmlspecialchars($category['name'])."</option>"; 
                            endif;
                        endforeach;?>
                    </select>
                </div>
                <div>
                    <label for="name">Título Película:</label>
                    <input type="text" id="name" name="name" value="<?=htmlspecialchars($editData['name']??'')?>" required>
                </div>
                <div>
                    <label for="sinopsis">Sinopsis (Opcional):</label>
                    <textarea id="sinopsis" name="sinopsis"><?=htmlspecialchars($editData['sinopsis']??'')?></textarea>
                </div>
                <div>
                    <label for="anio">Año (Opcional):</label>
                    <input type="text" id="anio" name="anio" value="<?=htmlspecialchars($editData['anio']??'')?>" placeholder="Ej: 2024" pattern="[0-9]{4}">
                </div>
                <div>
                    <label for="uri">URI (URL de la película):</label>
                    <input type="url" id="uri" name="uri" value="<?=htmlspecialchars($editData['uri']??'')?>" required>
                </div>
                <div>
                    <label for="icono">URL Póster (Opcional):</label>
                    <input type="url" id="icono" name="icono" value="<?=htmlspecialchars($editData['icono']??'')?>" placeholder="https://.../poster.jpg">
                    <small>Si se provee, se descargará a la carpeta '<?=$postersDirName?>'.</small>
                </div>
                <button type="submit" <?=empty($categories)?'disabled':''?>><?=$editMovieModal?'Guardar Cambios':'Agregar Película'?></button>
                <?php if($editMovieModal):?><a href="peliculas.php?#cat<?=htmlspecialchars((string)$editCatIndex)?>" class="cancel-btn">Cancelar</a><?php endif;?>
            </form>
        </section>
        <hr>
        <?php endif;?>
        <section id="list-section">
            <h2><?=$isSearchActive ? 'Resultados para "'.htmlspecialchars($searchTerm).'"' : 'Lista de Películas'?></h2>
            <?php if(empty($categories)):?>
                <p class="message warning">No hay categorías de películas.</p>
            <?php else:?>
                <?php foreach($categories as $catIndex => $category): ?>
                    <?php 
                    if(!is_array($category)||!isset($category['name'])) continue; 
                    $categoryName=$category['name']; 
                    $samples=$category['samples']??[]; 
                    $movieCountInCategory=count($samples);
                    $isFirstCategory = ($catIndex === 0); 
                    $isLastCategory = ($catIndex === (count($categories) - 1));
                    $showCategoryHeader = !$isSearchActive || ($isSearchActive && array_filter($samples, function($s) use ($searchTerm) { return isset($s['name']) && stripos($s['name'], $searchTerm) !== false; }));
                    if($showCategoryHeader): 
                    ?>
                    <h3 id="cat<?=$catIndex?>"><?=htmlspecialchars($categoryName)?><small>(<?=$movieCountInCategory?> películas)</small></h3>
                    <?php if(!$isSearchActive):?>
                    <div class="category-actions">
                        <a href="?action=move_category&cat=<?=$catIndex?>&dir=up#cat<?=($catIndex - 1)?>" class="move-btn <?= $isFirstCategory ? 'disabled' : '' ?>" title="Mover arriba">↑</a>
                        <a href="?action=move_category&cat=<?=$catIndex?>&dir=down#cat<?=($catIndex + 1)?>" class="move-btn <?= $isLastCategory ? 'disabled' : '' ?>" title="Mover abajo">↓</a>
                        <a href="?action=edit_category&cat=<?=$catIndex?>#category-forms-section" class="edit-cat-btn">Editar Nombre</a>
                        <form method="POST" action="peliculas.php" onsubmit="return confirm('¿Eliminar categoría \'<?=addslashes(htmlspecialchars($categoryName))?>\' y todas sus películas?');">
                            <input type="hidden" name="action" value="delete_category">
                            <input type="hidden" name="category_index" value="<?=$catIndex?>">
                            <button type="submit" class="delete-cat-btn">Eliminar</button>
                        </form>
                    </div>
                    <?php endif;?>
                    <?php if(!empty($samples)):?>
                        <div style="overflow-x:auto;">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Póster</th>
                                        <th>Título</th>
                                        <th>Año</th>
                                        <th>Sinopsis</th>
                                        <th>URI</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($samples as $sampleIndex => $sample):
                                        if(!$isSearchActive || ($isSearchActive && isset($sample['name']) && stripos($sample['name'], $searchTerm) !== false)):
                                        $isFirst = ($sampleIndex === 0); 
                                        $isLast = ($sampleIndex === $movieCountInCategory - 1);?>
                                        <tr>
                                            <td style="width:80px; text-align:center;">
                                                <?php if(!empty($sample['icono'])):?>
                                                    <img src="<?=htmlspecialchars($sample['icono'])?>" alt="Póster" class="icon" loading="lazy" onerror="this.style.display='none'">
                                                <?php else:?>
                                                    <span class="na">N/A</span>
                                                <?php endif;?>
                                            </td>
                                            <td><?=htmlspecialchars($sample['name'] ?? 'N/A')?></td>
                                            <td style="width:80px;"><?=htmlspecialchars($sample['anio'] ?? 'N/A')?></td>
                                            <td>
                                                <div class="sinopsis-cell" title="<?=htmlspecialchars($sample['sinopsis'] ?? '')?>">
                                                    <?=htmlspecialchars($sample['sinopsis'] ?? 'N/A')?>
                                                </div>
                                            </td>
                                            <td>
                                                <span class="uri-cell" title="<?=htmlspecialchars($sample['uri'])?>">
                                                    <?=htmlspecialchars($sample['uri'])?>
                                                </span>
                                            </td>
                                            <td class="actions">
                                                <a href="?action=move_movie&cat=<?=$catIndex?>&sample=<?=$sampleIndex?>&dir=up#cat<?=$catIndex?>" class="move-btn <?=$isFirst||$isSearchActive?'disabled':''?>">↑</a>
                                                <a href="?action=move_movie&cat=<?=$catIndex?>&sample=<?=$sampleIndex?>&dir=down#cat<?=$catIndex?>" class="move-btn <?=$isLast||$isSearchActive?'disabled':''?>">↓</a>
                                                <a href="?action=edit&cat=<?=$catIndex?>&sample=<?=$sampleIndex?>#form-section" class="edit-btn">Editar</a>
                                                <form method="POST" action="peliculas.php" onsubmit="return confirm('¿Eliminar película: \'<?=addslashes(htmlspecialchars($sample['name']))?>\'?');">
                                                    <input type="hidden" name="action" value="delete">
                                                    <input type="hidden" name="category_index" value="<?=$catIndex?>">
                                                    <input type="hidden" name="sample_index" value="<?=$sampleIndex?>">
                                                    <button type="submit" class="delete-btn">Eliminar</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endif; endforeach;?>
                                </tbody>
                            </table>
                        </div>
                    <?php elseif($showCategoryHeader): ?>
                        <p style="margin-left:15px"><em>No hay películas en esta categoría.</em></p>
                    <?php endif; endif; endforeach;?>
                <?php endif;?>
            </section>
        </div>
        <script>
            document.addEventListener("DOMContentLoaded", () => {
                const hash = window.location.hash;
                if (hash && hash !== "#") {
                    try {
                        const target = document.querySelector(hash);
                        if (target) {
                            setTimeout(() => {
                                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                                if(hash === '#form-section' || hash === '#category-forms-section') {
                                   target.querySelector("form input:not([type=hidden]):not([disabled])")?.focus();
                                }
                            }, 150);
                        }
                    } catch(e) { console.warn("Error scrolling to hash:", e); }
                }
            });
        </script>
    </body>
</html>
<?php } ?>
