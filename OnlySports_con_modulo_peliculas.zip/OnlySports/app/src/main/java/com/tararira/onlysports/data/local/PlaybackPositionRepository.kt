package com.tararira.onlysports.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import com.tararira.onlysports.AppPrefsDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

class PlaybackPositionRepository(context: Context) {

    private val dataStore: DataStore<Preferences> = context.AppPrefsDataStore

    private fun getKeyForUri(uri: String): Preferences.Key<Long> {
        return longPreferencesKey("playback_pos_${uri.hashCode()}")
    }

    suspend fun savePosition(uri: String, position: Long) {
        if (uri.isBlank()) return
        dataStore.edit { preferences ->
            preferences[getKeyForUri(uri)] = position
        }
    }

    suspend fun getPosition(uri: String): Long {
        if (uri.isBlank()) return 0L
        return dataStore.data
            .map { preferences ->
                preferences[getKeyForUri(uri)] ?: 0L
            }
            .first()
    }
}
