package com.tararira.onlysports.data.repository

import android.util.Log
import com.tararira.onlysports.data.model.LoginResponse
import com.tararira.onlysports.data.model.ValidationResponse // Asegúrate de que este import esté
import com.tararira.onlysports.data.remote.ApiService
import retrofit2.HttpException // Para capturar errores HTTP específicos
import java.io.IOException // Para capturar errores de red

class UserRepository(
    private val apiService: ApiService
) {
    private val logTag = "UserRepository"

    /**
     * Intenta iniciar sesión llamando a la API del servidor.
     * @param username El nombre de usuario ingresado.
     * @param password La contraseña ingresada.
     * @return LoginResponse El objeto de respuesta de la API. Null si hay error de red/inesperado.
     */
    suspend fun loginUserApi(username: String, password: String): LoginResponse? {
        Log.i(logTag, ">>> Attempting API login for user: $username")
        return try {
            Log.d(logTag, "Calling apiService.login('$username', [PASSWORD_PROTECTED])...")
            val response = apiService.login(username, password)
            Log.i(logTag, "<<< API login response received: Success=${response.success}, Message='${response.message}', User='${response.username}'")
            response // Devolver la respuesta completa
        } catch (e: HttpException) {
            val errorBody = try { e.response()?.errorBody()?.string() } catch (ex: Exception) { "Could not read error body." }
            Log.e(logTag, "!!! HTTP ERROR ${e.code()} during API login for $username: ${e.message()}. Error body: $errorBody", e)
            LoginResponse(success = false, message = "Error de servidor (${e.code()}) al iniciar sesión.") // Devolver un LoginResponse de error
        } catch (e: IOException) {
            Log.e(logTag, "!!! NETWORK/IO ERROR during API login for $username: ${e.message}", e)
            LoginResponse(success = false, message = "Error de conexión al iniciar sesión.") // Devolver un LoginResponse de error
        } catch (e: Exception) {
            Log.e(logTag, "!!! UNEXPECTED ERROR during API login for $username: ${e.message}", e)
            null // O un LoginResponse de error genérico
        }
    }

    /**
     * Valida una sesión de usuario existente con el servidor.
     * @param username El nombre del usuario cuya sesión se va a validar.
     * @return ValidationResponse La respuesta de la API. (isValid=false si hay error de red o la API lo indica)
     */
    suspend fun validateUserSessionApi(username: String): ValidationResponse {
        Log.i(logTag, ">>> API_VALIDATE: Attempting API session validation for user: $username")
        return try {
            Log.d(logTag, "Calling apiService.validateSession('$username')...")
            // La llamada a Retrofit ya debería deserializar
            val response: ValidationResponse = apiService.validateSession(username)
            Log.i(logTag, "<<< API_VALIDATE: Response received AND parsed: isValid=${response.isValid}, Message='${response.message}', User='${response.username}'")
            response
        } catch (e: kotlinx.serialization.SerializationException) { // Capturar explícitamente
            Log.e(logTag, "!!! API_VALIDATE: JSON PARSING ERROR for ValidationResponse: ${e.message}", e)
            ValidationResponse(isValid = false, message = "Error al procesar respuesta del servidor.")
        } catch (e: HttpException) {
            val errorBody = try { e.response()?.errorBody()?.string() } catch (ex: Exception) { "N/A" }
            Log.e(logTag, "!!! API_VALIDATE: HTTP ERROR ${e.code()} for $username: ${e.message()}. Body: $errorBody", e)
            ValidationResponse(isValid = false, message = "Error de servidor (${e.code()}) al validar sesión.")
        } catch (e: IOException) {
            Log.e(logTag, "!!! API_VALIDATE: NETWORK/IO ERROR for $username: ${e.message}", e)
            ValidationResponse(isValid = false, message = "Error de conexión validando sesión.")
        } catch (t: Throwable) { // Captura más genérica al final
            Log.e(logTag, "!!! API_VALIDATE: UNEXPECTED THROWABLE for $username: ${t.message}", t)
            ValidationResponse(isValid = false, message = "Error inesperado: ${t.message}")
        }
    }
}