package com.tararira.onlysports.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class MovieSample(
    @SerialName("name") val name: String,
    @SerialName("sinopsis") val sinopsis: String?,
    @SerialName("anio") val year: String?,
    @SerialName("uri") val uri: String,
    @SerialName("icono") val iconUrl: String?,
    @SerialName("drm_scheme") val drmScheme: String? = null,
    @SerialName("drm_license_uri") val drmLicenseUri: String? = null
)