package com.tararira.onlysports.worker

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.tararira.onlysports.auth.AuthManager
// Ya no se necesitan ApiService ni LoginResponse para este modo pasivo
// import com.tararira.onlysports.data.model.LoginResponse
// import com.tararira.onlysports.data.remote.ApiService
// import com.tararira.onlysports.data.remote.RetrofitClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class SessionValidationWorker(
    appContext: Context, // Renombrado para claridad
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    private val logTag = "SessionValidationWorker"

    private val authManager: AuthManager by lazy { AuthManager(appContext) }
    // private val apiService: ApiService by lazy { RetrofitClient.apiService } // Ya no se necesita

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        Log.i(logTag, ">>> Starting PASSIVE periodic session timestamp update work <<<")

        try {
            // 1. Obtener estado actual de forma síncrona
            val (isLoggedIn, username) = authManager.getCurrentLoginState()
            val lastValidationTime = authManager.getCurrentValidationTimestamp()
            val currentTime = System.currentTimeMillis()

            Log.d(logTag, "Current state - isLoggedIn: $isLoggedIn, Username: $username, LastValidationTimestamp: $lastValidationTime, CurrentTime: $currentTime")

            // 2. Decidir si la actualización del timestamp es necesaria
            if (!isLoggedIn || username == null) {
                Log.i(logTag, "User is not marked as logged in. Work finished (nothing to update).")
                return@withContext Result.success()
            }

            val timeSinceLastValidation = currentTime - lastValidationTime
            Log.d(logTag, "Time since last timestamp update: $timeSinceLastValidation ms. Interval: ${AuthManager.VALIDATION_INTERVAL_MS} ms.")

            if (timeSinceLastValidation >= AuthManager.VALIDATION_INTERVAL_MS) {
                Log.i(logTag, "Validation interval PASSED for '$username'. Updating local timestamp to keep session 'fresh' (NO SERVER CHECK).")
                authManager.updateLastValidationTimestamp() // Solo actualiza el timestamp local
            } else {
                val hoursRemaining = (AuthManager.VALIDATION_INTERVAL_MS - timeSinceLastValidation) / (60 * 60 * 1000)
                Log.i(logTag, "Validation interval NOT YET passed for '$username'. Approx ${hoursRemaining}h remaining. No action taken.")
            }

            Result.success() // El trabajo siempre es "exitoso" en este modo pasivo
        } catch (e: Exception) {
            Log.e(logTag, "Exception during passive worker execution", e)
            Result.retry() // Reintentar si hubo una excepción inesperada al leer/escribir DataStore
        }
    }
}