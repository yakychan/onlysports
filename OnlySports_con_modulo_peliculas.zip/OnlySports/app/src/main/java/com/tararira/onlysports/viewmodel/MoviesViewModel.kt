package com.tararira.onlysports.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tararira.onlysports.data.model.MovieSample
import com.tararira.onlysports.data.repository.ChannelRepository
import com.tararira.onlysports.data.repository.ChannelRepository.MovieDataResult
import kotlinx.coroutines.flow.*

data class MoviesUiState(
    val categories: Map<String, List<MovieSample>> = emptyMap(),
    val isLoading: Boolean = true,
    val error: String? = null
)

class MoviesViewModel(
    private val channelRepository: ChannelRepository
) : ViewModel() {

    val uiState: StateFlow<MoviesUiState> = channelRepository.movieDataFlow
        .map { result ->
            when (result) {
                is MovieDataResult.Loading -> MoviesUiState(isLoading = true)
                is MovieDataResult.Success -> {
                    val categoriesMap = result.categories.associate {
                        it.categoryName to it.samples
                    }.filterValues { it.isNotEmpty() }
                    MoviesUiState(isLoading = false, categories = categoriesMap)
                }
                is MovieDataResult.Error -> MoviesUiState(isLoading = false, error = result.message)
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = MoviesUiState(isLoading = true)
        )

    init {
        channelRepository.forceRefreshMovies()
    }
}
