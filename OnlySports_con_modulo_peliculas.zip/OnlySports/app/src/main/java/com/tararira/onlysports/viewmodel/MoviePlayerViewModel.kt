package com.tararira.onlysports.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tararira.onlysports.data.model.MovieSample
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

data class MoviePlayerUiState(
    val movie: MovieSample? = null
)

class MoviePlayerViewModel(
    sharedNavViewModel: SharedNavViewModel
) : ViewModel() {

    val uiState: StateFlow<MoviePlayerUiState> = sharedNavViewModel.selectedMovie
        .map { MoviePlayerUiState(movie = it) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = MoviePlayerUiState()
        )
}