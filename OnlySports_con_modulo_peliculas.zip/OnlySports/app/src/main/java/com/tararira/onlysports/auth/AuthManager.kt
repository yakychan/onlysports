package com.tararira.onlysports.auth

import android.content.Context
import android.util.Log
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import com.tararira.onlysports.AppPrefsDataStore // Tu DataStore global
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.io.IOException

class AuthManager(context: Context) {
    private val dataStore = context.applicationContext.AppPrefsDataStore // Usar applicationContext
    private val logTag = "AuthManager"

    companion object {
        // Usar claves con versiones para asegurar que cambios en la estructura fuerzan una lectura inicial vacía
        val IS_LOGGED_IN_KEY = booleanPreferencesKey("auth_is_logged_in_v2")
        val LOGGED_IN_USERNAME_KEY = stringPreferencesKey("auth_logged_in_username_v2")
        val LAST_VALIDATION_TIMESTAMP_KEY = longPreferencesKey("auth_last_validation_ts_v2")

        val VALIDATION_INTERVAL_MS: Long = 23 * 60 * 60 * 1000L // 23 horas
    }

    // --- Flows para observar cambios (sin cambios funcionales) ---
    val isLoggedInFlow: Flow<Boolean> = dataStore.data
        .catch { e ->
            if (e is IOException) { Log.e(logTag, "IOException reading IS_LOGGED_IN_KEY Flow.", e); emit(emptyPreferences()) } else { throw e }
        }
        .map { preferences ->
            val isLoggedIn = preferences[IS_LOGGED_IN_KEY] ?: false
            Log.v(logTag, "isLoggedInFlow emitting: $isLoggedIn (Raw: ${preferences[IS_LOGGED_IN_KEY]})") // Log detallado
            isLoggedIn
        }

    val loggedInUsernameFlow: Flow<String?> = dataStore.data
        .catch { e ->
            if (e is IOException) { Log.e(logTag, "IOException reading LOGGED_IN_USERNAME_KEY Flow.", e); emit(emptyPreferences()) } else { throw e }
        }
        .map { preferences ->
            val username = preferences[LOGGED_IN_USERNAME_KEY]
            Log.v(logTag, "loggedInUsernameFlow emitting: '$username'") // Log detallado
            username
        }

    val lastValidationTimestampFlow: Flow<Long> = dataStore.data
        .catch { e ->
            if (e is IOException) { Log.e(logTag, "IOException reading LAST_VALIDATION_TIMESTAMP_KEY Flow.", e); emit(emptyPreferences()) } else { throw e }
        }
        .map { preferences -> preferences[LAST_VALIDATION_TIMESTAMP_KEY] ?: 0L }

    // --- Funciones para Escribir en DataStore ---
    suspend fun loginUser(username: String, rememberMe: Boolean) {
        Log.i(logTag, ">>> loginUser called. User: '$username', RememberMe: $rememberMe")
        try {
            dataStore.edit { preferences ->
                if (rememberMe) {
                    val currentTime = System.currentTimeMillis()
                    Log.i(logTag, "   RememberMe=true. Setting: LoggedIn=true, User='$username', Timestamp=$currentTime")
                    preferences[IS_LOGGED_IN_KEY] = true
                    preferences[LOGGED_IN_USERNAME_KEY] = username
                    preferences[LAST_VALIDATION_TIMESTAMP_KEY] = currentTime
                } else {
                    Log.i(logTag, "   RememberMe=false. Setting: LoggedIn=false. Clearing data.")
                    preferences[IS_LOGGED_IN_KEY] = false
                    preferences.remove(LOGGED_IN_USERNAME_KEY)
                    preferences.remove(LAST_VALIDATION_TIMESTAMP_KEY)
                }
                // Puedes loggear el estado de las claves DESPUÉS del edit (requiere otra lectura síncrona)
                // Log.d(logTag, "   After edit - IS_LOGGED_IN_KEY is now: ${preferences[IS_LOGGED_IN_KEY]}")
            }
            Log.i(logTag, "<<< loginUser: User login state update operation finished.")
        } catch (e: Exception) {
            Log.e(logTag, "!!! Exception in loginUser while editing DataStore !!!", e)
        }
    }

    suspend fun updateLastValidationTimestamp() {
        val currentTime = System.currentTimeMillis()
        Log.i(logTag, ">>> updateLastValidationTimestamp called. Attempting to set timestamp to: $currentTime")
        try {
            dataStore.edit { preferences ->
                if (preferences[IS_LOGGED_IN_KEY] == true) {
                    Log.d(logTag, "   User is marked as logged in. Updating LAST_VALIDATION_TIMESTAMP_KEY.")
                    preferences[LAST_VALIDATION_TIMESTAMP_KEY] = currentTime
                } else {
                    Log.w(logTag, "   Skipping timestamp update, user not marked as logged in.")
                }
            }
            Log.i(logTag, "<<< updateLastValidationTimestamp: Timestamp update attempt finished.")
        } catch (e: Exception) {
            Log.e(logTag, "!!! Exception in updateLastValidationTimestamp while editing DataStore !!!", e)
        }
    }

    suspend fun logoutUser() {
        Log.i(logTag, ">>> logoutUser called. Clearing all auth preferences.")
        try {
            dataStore.edit { preferences ->
                preferences[IS_LOGGED_IN_KEY] = false
                preferences.remove(LOGGED_IN_USERNAME_KEY)
                preferences.remove(LAST_VALIDATION_TIMESTAMP_KEY)
            }
            Log.i(logTag, "<<< logoutUser: Auth preferences cleared successfully in DataStore.")
        } catch (e: Exception) {
            Log.e(logTag, "!!! Exception in logoutUser while editing DataStore !!!", e)
        }
    }

    // --- Funciones SÍNCRONAS (para Worker o inicio rápido) ---
    // Añadimos logs más detallados aquí
    suspend fun getCurrentLoginState(): Pair<Boolean, String?> {
        Log.i(logTag, ">>> getCurrentLoginState: Attempting to read from DataStore.data.first()...")
        return try {
            val preferences: Preferences = dataStore.data.first() // Esta llamada es la que podría bloquear
            val isLoggedIn = preferences[IS_LOGGED_IN_KEY] ?: false
            val username = preferences[LOGGED_IN_USERNAME_KEY]
            Log.i(logTag, "<<< getCurrentLoginState: Read SUCCESS - isLoggedIn: $isLoggedIn (Raw: ${preferences[IS_LOGGED_IN_KEY]}), Username: '$username' (Raw: '${preferences[LOGGED_IN_USERNAME_KEY]}')")
            Pair(isLoggedIn, username)
        } catch (e: Exception) {
            Log.e(logTag, "!!! Exception in getCurrentLoginState while reading DataStore. Returning (false, null).", e)
            Pair(false, null) // Fallback en caso de error
        }
    }

    suspend fun getCurrentValidationTimestamp(): Long {
        Log.i(logTag, ">>> getCurrentValidationTimestamp: Reading from DataStore.data.first()...")
        return try {
            val preferences = dataStore.data.first() // Lectura
            val timestamp = preferences[LAST_VALIDATION_TIMESTAMP_KEY] ?: 0L
            Log.i(logTag, "<<< getCurrentValidationTimestamp: Read SUCCESS - Timestamp: $timestamp (Raw: ${preferences[LAST_VALIDATION_TIMESTAMP_KEY]})")
            timestamp
        } catch (e: Exception) {
            Log.e(logTag, "!!! Exception in getCurrentValidationTimestamp while reading DataStore. Returning 0L.", e)
            0L // Fallback
        }
    }
}