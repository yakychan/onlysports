package com.tararira.onlysports.util

import android.util.Base64
import android.util.Log
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec
// import java.security.MessageDigest // No se usa actualmente, pero podría ser para generar claves

object EncryptionHelper {

    // --- CONFIGURACIÓN AES - ¡DEBE COINCIDIR CON PHP! ---
    // Clave (Asegúrate de que esta sea la misma que en tu PHP)
    private const val AES_KEY_STRING = "CLAVEAESACA" // 32 caracteres
    // Vector de Inicialización (Asegúrate que sea el mismo que en PHP)
    private const val AES_IV_STRING = "CLAVEAESACA2" // 16 caracteres
    // Algoritmo (PHP 'aes-256-cbc' suele mapear a "AES/CBC/PKCS5Padding" en Android)
    private const val ALGORITHM = "AES/CBC/PKCS5Padding"
    // --- FIN CONFIGURACIÓN ---

    private const val TAG = "EncryptionHelper" // Tag para logs

    // --- Preparación de Clave e IV (usando lazy para eficiencia) ---
    private val secretKey: SecretKeySpec by lazy {
        val keyBytes = AES_KEY_STRING.toByteArray(Charsets.UTF_8)
        // Asegurar la longitud correcta para AES-256 (32 bytes)
        // copyOf tomará los primeros 32 bytes o rellenará con ceros si es más corta.
        // Es MEJOR que AES_KEY_STRING tenga exactamente 32 caracteres.
        val finalKeyBytes = keyBytes.copyOf(32)
        if (keyBytes.size != 32) {
            Log.w(TAG, "AES_KEY_STRING original no tiene 32 bytes (${keyBytes.size} bytes). Se ajustó a 32 bytes. Esto podría causar problemas si no es intencional.")
        }
        SecretKeySpec(finalKeyBytes, "AES")
    }

    private val ivParameterSpec: IvParameterSpec by lazy {
        val ivBytes = AES_IV_STRING.toByteArray(Charsets.UTF_8)
        // Asegurar la longitud correcta para el IV (16 bytes para CBC)
        val finalIvBytes = ivBytes.copyOf(16)
        if (ivBytes.size != 16) {
            Log.w(TAG, "AES_IV_STRING original no tiene 16 bytes (${ivBytes.size} bytes). Se ajustó a 16 bytes. Esto podría causar problemas.")
        }
        IvParameterSpec(finalIvBytes)
    }


    /**
     * Desencripta un String Base64 que contiene datos cifrados con AES.
     * @param base64EncryptedData El string en Base64 a desencriptar.
     * @return El string desencriptado (debería ser un JSON), o null si hay error.
     */
    fun decryptAES(base64EncryptedData: String): String? {
        Log.d(TAG, "Attempting AES decryption...")
        Log.v(TAG, "Using ALGORITHM: $ALGORITHM")
        Log.v(TAG, "Using KEY (hex): ${secretKey.encoded.joinToString("") { "%02x".format(it) }} (length: ${secretKey.encoded.size})")
        Log.v(TAG, "Using IV (hex): ${ivParameterSpec.iv.joinToString("") { "%02x".format(it) }} (length: ${ivParameterSpec.iv.size})")
        Log.v(TAG, "Input Base64 (first 100 chars): ${base64EncryptedData.take(100)}...")

        if (base64EncryptedData.isBlank()) {
            Log.w(TAG, "Input Base64 string is blank. Returning null.")
            return null
        }

        return try {
            val encryptedBytes = Base64.decode(base64EncryptedData, Base64.DEFAULT)
            Log.d(TAG, "Base64 decoded successfully. Encrypted bytes length: ${encryptedBytes.size}")

            val cipher = Cipher.getInstance(ALGORITHM)
            Log.d(TAG, "Cipher instance created for $ALGORITHM. Initializing for DECRYPT_MODE...")
            cipher.init(Cipher.DECRYPT_MODE, secretKey, ivParameterSpec)
            Log.d(TAG, "Cipher initialized. Performing doFinal (decryption)...")

            val decryptedBytes = cipher.doFinal(encryptedBytes)
            val decryptedString = String(decryptedBytes, Charsets.UTF_8)
            Log.i(TAG, "AES Decryption successful. Decrypted string length: ${decryptedString.length}")
            Log.v(TAG, "Decrypted content preview (first 200 chars): ${decryptedString.take(200)}")
            decryptedString
        } catch (e: IllegalArgumentException) {
            Log.e(TAG, "AES Decryption Error: Bad Base64 input. ${e.message}", e)
            null
        } catch (e: javax.crypto.NoSuchPaddingException) {
            Log.e(TAG, "AES Decryption Error: No Such Padding. Check ALGORITHM. ${e.message}", e)
            null
        } catch (e: java.security.NoSuchAlgorithmException) {
            Log.e(TAG, "AES Decryption Error: No Such Algorithm. Check ALGORITHM. ${e.message}", e)
            null
        } catch (e: java.security.InvalidKeyException) {
            Log.e(TAG, "AES Decryption Error: Invalid Key. Key length or format issue? ${e.message}", e)
            null
        } catch (e: java.security.InvalidAlgorithmParameterException) {
            Log.e(TAG, "AES Decryption Error: Invalid Algorithm Parameter. IV length or format issue? ${e.message}", e)
            null
        } catch (e: javax.crypto.IllegalBlockSizeException) {
            Log.e(TAG, "AES Decryption Error: Illegal Block Size. Often due to incorrect IV or corrupted data. ${e.message}", e)
            null
        } catch (e: javax.crypto.BadPaddingException) {
            Log.e(TAG, "AES Decryption Error: Bad Padding. VERY LIKELY incorrect Key, IV, or data corruption, or wrong padding scheme. ${e.message}", e)
            null
        }
        catch (e: Exception) { // Captura genérica para otros errores
            Log.e(TAG, "AES Decryption Error: UNEXPECTED EXCEPTION. ${e.message}", e)
            null
        }
    }
}