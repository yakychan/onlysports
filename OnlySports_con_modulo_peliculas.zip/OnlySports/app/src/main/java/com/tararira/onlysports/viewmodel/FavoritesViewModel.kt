package com.tararira.onlysports.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tararira.onlysports.data.epg.model.EpgProgramme
import com.tararira.onlysports.data.local.FavoritesRepository
import com.tararira.onlysports.data.local.PrefKeys
import com.tararira.onlysports.data.model.ChannelSample
import com.tararira.onlysports.data.repository.ChannelRepository
import com.tararira.onlysports.data.repository.ChannelRepository.ChannelDataResult
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.Duration
import java.time.OffsetDateTime
import java.time.ZoneId

data class FavoritesUiState(
    val favoriteChannels: List<ChannelSample> = emptyList(),
    val currentEpg: Map<String, CurrentEpgInfo> = emptyMap(),
    val isLoading: Boolean = false,
    val error: String? = null
)

class FavoritesViewModel(
    private val channelRepository: ChannelRepository,
    private val favoritesRepository: FavoritesRepository,
    private val parentalControlViewModel: ParentalControlViewModel
) : ViewModel() {

    private val _channelResultFlow: StateFlow<ChannelDataResult> = channelRepository.channelDataFlow

    val uiState: StateFlow<FavoritesUiState> = combine(
        favoritesRepository.favoriteChannelIdsFlow,
        _channelResultFlow,
        channelRepository.epgDataFlow,
        parentalControlViewModel.isCensoringActive
    ) { favoriteIds, channelResult, rawEpgMap, isCensoring ->

        if (favoriteIds.isEmpty()) {
            FavoritesUiState()
        } else {
            val allCategories = if (channelResult is ChannelDataResult.Success) channelResult.categories else emptyList()

            val categoryMap = allCategories.flatMap { category ->
                category.samples.map { sample -> sample.channelId to category.categoryName }
            }.toMap()

            val favoriteChannelsDetails = allCategories.flatMap { it.samples }
                .filter { it.channelId in favoriteIds }

            val filteredFavorites = if(isCensoring) {
                favoriteChannelsDetails.filter {
                    val categoryName = categoryMap[it.channelId]
                    categoryName !in PrefKeys.ADULT_CATEGORY_NAMES
                }
            } else {
                favoriteChannelsDetails
            }

            val epgForFavorites = calculateCurrentAndNextEpgWithProgress(filteredFavorites, rawEpgMap ?: emptyMap())

            FavoritesUiState(
                favoriteChannels = filteredFavorites.distinctBy { it.channelId },
                currentEpg = epgForFavorites,
                isLoading = channelResult is ChannelDataResult.Loading,
                error = if (channelResult is ChannelDataResult.Error) channelResult.message else null
            )
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = FavoritesUiState(isLoading = true)
    )

    private fun calculateCurrentAndNextEpgWithProgress(
        channels: List<ChannelSample>,
        rawEpg: Map<String, List<EpgProgramme>>
    ): Map<String, CurrentEpgInfo> {
        if (channels.isEmpty() || rawEpg.isEmpty()) return emptyMap()
        val currentEpgMap = mutableMapOf<String, CurrentEpgInfo>()
        val now = OffsetDateTime.now(ZoneId.systemDefault())
        val channelIdsToProcess = channels.mapNotNull { it.channelId }.toSet()

        channelIdsToProcess.forEach { channelId ->
            val programsForChannel = rawEpg[channelId]?.sortedBy { it.start }
            val currentProgram = programsForChannel?.find { it.isAiringAt(now) }
            var progress: Float? = null
            var nextProgram: EpgProgramme? = null

            if (currentProgram != null) {
                try {
                    val totalDuration = Duration.between(currentProgram.start, currentProgram.stop)
                    val elapsedDuration = Duration.between(currentProgram.start, now)
                    if (!totalDuration.isZero && !totalDuration.isNegative && !elapsedDuration.isNegative) {
                        progress = (elapsedDuration.toMillis().toFloat() / totalDuration.toMillis().toFloat()).coerceIn(0.0f, 1.0f)
                    }
                } catch (e: Exception) {
                    progress = null
                }
                val currentIndex = programsForChannel.indexOf(currentProgram)
                if (currentIndex != -1 && currentIndex + 1 < programsForChannel.size) {
                    nextProgram = programsForChannel[currentIndex + 1]
                }
            } else {
                nextProgram = programsForChannel?.firstOrNull { !it.start.isBefore(now) }
            }
            currentEpgMap[channelId] = CurrentEpgInfo(currentProgram, progress, nextProgram)
        }
        return currentEpgMap
    }

    fun removeFromFavorites(channelId: String?) {
        if (channelId.isNullOrBlank()) {
            return
        }
        viewModelScope.launch {
            favoritesRepository.removeFavorite(channelId)
        }
    }
}