package com.tararira.onlysports.ui.screens

import android.app.Activity
import android.util.Log
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.tararira.onlysports.R
import com.tararira.onlysports.data.model.ChannelSample
import com.tararira.onlysports.player.PlayerManager
import com.tararira.onlysports.viewmodel.CurrentEpgInfo
import com.tararira.onlysports.viewmodel.PlayerUiState
import com.tararira.onlysports.viewmodel.PlayerViewModel
import com.tararira.onlysports.viewmodel.SharedNavViewModel
import kotlinx.coroutines.delay

private const val DOUBLE_TAP_OK_DELAY_MS = 500L
private const val FATAL_ERROR_RETRY_DELAY_MS = 3500L
private const val EPG_OVERLAY_DURATION_MS = 7000L

@androidx.annotation.OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    uiState: PlayerUiState,
    sharedViewModel: SharedNavViewModel,
    viewModel: PlayerViewModel,
    onPlaybackError: (String?) -> Unit,
    onFatalError: (String?) -> Unit,
    onBackPressed: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val focusRequester = remember { FocusRequester() }
    val view = LocalView.current
    val window = (view.context as? Activity)?.window
    var playerViewRef by remember { mutableStateOf<PlayerView?>(null) }
    var playerManager by remember { mutableStateOf<PlayerManager?>(null) }

    val currentSelectedId by sharedViewModel.selectedChannelId.collectAsState()
    val currentIdList by sharedViewModel.currentChannelIdList.collectAsState()
    var lastChangeDirectionWasNext by remember { mutableStateOf<Boolean?>(null) }
    var showEpgOverlay by remember { mutableStateOf(false) }

    val currentChannelInfo = remember(uiState.channelSamples) {
        uiState.channelSamples.firstOrNull()
    }

    LaunchedEffect(uiState.channelSamples) {
        playerManager?.releasePlayer()
        if (uiState.channelSamples.isNotEmpty()) {
            playerManager = PlayerManager(
                context = context,
                channelSamples = uiState.channelSamples,
                onError = onFatalError,
                onPlaybackError = onPlaybackError,
                onVideoResolutionChanged = { height -> viewModel.updateVideoResolution(height) }
            )
            showEpgOverlay = true
        }
    }

    LaunchedEffect(playerManager) {
        if (playerManager != null) {
            delay(150)
            try { focusRequester.requestFocus() } catch (e: Exception) { Log.e("PlayerScreen", "Error requesting focus", e) }
        }
    }

    LaunchedEffect(showEpgOverlay) {
        if (showEpgOverlay) {
            delay(EPG_OVERLAY_DURATION_MS)
            showEpgOverlay = false
        }
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_PAUSE || event == Lifecycle.Event.ON_STOP) {
                window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            playerManager?.releasePlayer()
            window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    LaunchedEffect(uiState.fatalError) {
        val fatalErrorMsg = uiState.fatalError
        if (fatalErrorMsg != null) {
            Toast.makeText(context, fatalErrorMsg, Toast.LENGTH_LONG).show()
            delay(FATAL_ERROR_RETRY_DELAY_MS)
            val direction = lastChangeDirectionWasNext ?: true
            changeChannel(currentSelectedId, currentIdList, sharedViewModel, direction)
            lastChangeDirectionWasNext = null
        }
    }

    BackHandler {
        sharedViewModel.requestFocusOnLastPlayedChannelInList()
        onBackPressed()
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Color.Black) {
        Box(modifier = Modifier.fillMaxSize()) {
            when {
                uiState.isLoading -> {
                    CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                }
                uiState.fatalError != null -> {
                    Text(
                        uiState.fatalError,
                        color = MaterialTheme.colorScheme.error,
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.titleLarge,
                        modifier = Modifier.align(Alignment.Center).padding(32.dp)
                    )
                }
                uiState.loadingError != null -> {
                    Text(
                        "Error al cargar datos del canal:\n${uiState.loadingError}",
                        color = MaterialTheme.colorScheme.error,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.align(Alignment.Center).padding(16.dp)
                    )
                }
                playerManager != null -> {
                    PlayerViewComposableWithInput(
                        playerManager = playerManager!!,
                        focusRequester = focusRequester,
                        setPlayerViewRef = { playerViewRef = it },
                        onDoubleTapOk = { playerManager?.switchToNextSource() },
                        onChannelUp = {
                            lastChangeDirectionWasNext = false
                            changeChannel(currentSelectedId, currentIdList, sharedViewModel, false)
                            showEpgOverlay = true
                        },
                        onChannelDown = {
                            lastChangeDirectionWasNext = true
                            changeChannel(currentSelectedId, currentIdList, sharedViewModel, true)
                            showEpgOverlay = true
                        }
                    )
                }
            }

            AnimatedVisibility(
                visible = uiState.videoResolution != null,
                modifier = Modifier.align(Alignment.TopEnd).padding(16.dp),
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color.Black.copy(alpha = 0.6f)
                ) {
                    Text(
                        text = uiState.videoResolution ?: "",
                        color = Color.White,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            AnimatedVisibility(
                visible = showEpgOverlay && uiState.fatalError == null,
                modifier = Modifier.align(Alignment.BottomCenter),
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                EpgInfoOverlay(
                    channelInfo = currentChannelInfo,
                    epgInfo = uiState.currentEpgInfo
                )
            }

            if (uiState.playbackError != null && uiState.fatalError == null) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = if (showEpgOverlay) 130.dp else 16.dp)
                        .background(Color.Black.copy(alpha = 0.7f))
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Text(
                        uiState.playbackError,
                        color = Color.White,
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}


private fun changeChannel(currentId: String?, idList: List<String>, sharedViewModel: SharedNavViewModel, goNext: Boolean) {
    if (currentId == null || idList.size <= 1) return
    val currentIndex = idList.indexOf(currentId)
    if (currentIndex == -1) {
        idList.firstOrNull()?.let { sharedViewModel.selectChannel(it) }
        return
    }
    val newIndex = (currentIndex + (if (goNext) 1 else -1) + idList.size) % idList.size
    if (idList[newIndex] != currentId) {
        sharedViewModel.selectChannel(idList[newIndex])
    }
}

@Composable
fun EpgInfoOverlay(channelInfo: ChannelSample?, epgInfo: CurrentEpgInfo?) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 48.dp, vertical = 24.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.6f), Color.Black.copy(alpha = 0.9f))))
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AsyncImage(
                model = ImageRequest.Builder(LocalContext.current)
                    .data(channelInfo?.iconUrl).placeholder(R.drawable.ic_placeholder)
                    .error(R.drawable.ic_placeholder).crossfade(true).build(),
                contentDescription = "Logo ${channelInfo?.name}",
                modifier = Modifier.size(54.dp).clip(RoundedCornerShape(8.dp)),
                contentScale = ContentScale.Fit
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = channelInfo?.name ?: "Cargando...",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold, color = Color.White,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                val currentProgram = epgInfo?.programme
                Text(
                    text = if (currentProgram != null) "${currentProgram.getFormattedTimeRange()} ${currentProgram.title}" else "EPG no disponible",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.95f),
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                val progress = epgInfo?.progress
                if (progress != null) {
                    Spacer(modifier = Modifier.height(5.dp))
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.fillMaxWidth().height(4.dp),
                        color = Color(0xFF00BCD4),
                        trackColor = Color.Gray.copy(alpha = 0.5f)
                    )
                    Spacer(modifier = Modifier.height(5.dp))
                } else {
                    Spacer(modifier = Modifier.height(9.dp))
                }
                val nextProgram = epgInfo?.nextProgramme
                Text(
                    text = if (nextProgram != null) "A continuación: ${nextProgram.getFormattedTimeRange()} ${nextProgram.title}" else " ",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.8f),
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@androidx.annotation.OptIn(UnstableApi::class)
@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun PlayerViewComposableWithInput(
    playerManager: PlayerManager,
    focusRequester: FocusRequester,
    setPlayerViewRef: (PlayerView?) -> Unit,
    onDoubleTapOk: () -> Unit,
    onChannelUp: () -> Unit,
    onChannelDown: () -> Unit
) {
    var lastOkPressTime by remember { mutableStateOf(0L) }
    AndroidView(
        factory = { context ->
            PlayerView(context).apply {
                this.player = playerManager.exoPlayer
                useController = false
                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                isFocusable = true
                isFocusableInTouchMode = true
                setPlayerViewRef(this)
            }
        },
        update = { view ->
            view.player = playerManager.exoPlayer
            setPlayerViewRef(view)
        },
        modifier = Modifier
            .fillMaxSize()
            .focusRequester(focusRequester)
            .focusable()
            .onKeyEvent { keyEvent ->
                if (keyEvent.type == KeyEventType.KeyDown) {
                    when (keyEvent.key) {
                        Key.DirectionCenter, Key.Enter, Key.NumPadEnter -> {
                            val currentTime = System.currentTimeMillis()
                            if (currentTime - lastOkPressTime < DOUBLE_TAP_OK_DELAY_MS) {
                                onDoubleTapOk()
                                lastOkPressTime = 0L
                                true
                            } else {
                                lastOkPressTime = currentTime
                                false
                            }
                        }
                        Key.DirectionUp, Key.ChannelUp -> { onChannelDown(); true }
                        Key.DirectionDown, Key.ChannelDown -> { onChannelUp(); true }
                        Key.DirectionLeft -> { playerManager.cycleSubtitleTrack(); true }
                        Key.DirectionRight -> { playerManager.cycleAudioTrack(true); true }
                        else -> false
                    }
                } else {
                    false
                }
            }
    )
}