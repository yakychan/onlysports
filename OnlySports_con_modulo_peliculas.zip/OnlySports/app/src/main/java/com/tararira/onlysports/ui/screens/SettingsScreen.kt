package com.tararira.onlysports.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tararira.onlysports.data.local.PrefKeys
import com.tararira.onlysports.viewmodel.ParentalControlViewModel
import com.tararira.onlysports.viewmodel.SettingsViewModel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

private enum class PinAction { NONE, DISABLE_CONTROL, CHANGE_PIN }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    settingsViewModel: SettingsViewModel,
    parentalControlViewModel: ParentalControlViewModel,
    onNavigateToDiagnostics: () -> Unit,
    onBackPressed: () -> Unit
) {
    val localContext = LocalContext.current
    val scope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current

    val uiState by settingsViewModel.uiState.collectAsStateWithLifecycle()
    val isParentalControlEnabled by parentalControlViewModel.isEnabled.collectAsStateWithLifecycle()

    var showVerifyDialog by remember { mutableStateOf(false) }
    var pinAction by remember { mutableStateOf(PinAction.NONE) }
    var showChangePinSection by remember { mutableStateOf(false) }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
        onResult = { uri ->
            uri?.let { settingsViewModel.onImportFavorites(localContext.contentResolver, it) }
        }
    )

    LaunchedEffect(Unit) {
        settingsViewModel.toastMessage.collectLatest { message ->
            Toast.makeText(localContext, message, Toast.LENGTH_LONG).show()
        }
    }

    if (showVerifyDialog) {
        VerifyPinDialog(
            action = pinAction,
            onDismiss = { showVerifyDialog = false },
            onPinVerified = {
                showVerifyDialog = false
                when (pinAction) {
                    PinAction.DISABLE_CONTROL -> {
                        parentalControlViewModel.setEnabled(false, "")
                        Toast.makeText(localContext, "Control Parental Desactivado", Toast.LENGTH_SHORT).show()
                    }
                    PinAction.CHANGE_PIN -> {
                        showChangePinSection = true
                    }
                    else -> {}
                }
            },
            parentalControlViewModel = parentalControlViewModel
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Configuración") },
                navigationIcon = { IconButton(onClick = onBackPressed) { Icon(Icons.Filled.ArrowBack, "Atrás") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 32.dp, vertical = 16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (uiState.isLoading) {
                CircularProgressIndicator()
            } else {
                var epgUrl by remember(uiState.epgUrl) { mutableStateOf(uiState.epgUrl) }
                var epgInterval by remember(uiState.epgInterval) { mutableIntStateOf(uiState.epgInterval) }
                var subTextColor by remember(uiState.subTextColor) { mutableStateOf(Color(uiState.subTextColor)) }
                var subBgColor by remember(uiState.subBgColor) { mutableStateOf(Color(uiState.subBgColor)) }
                var subTextSize by remember(uiState.subTextSize) { mutableFloatStateOf(uiState.subTextSize) }

                EpgSettingsSection(
                    url = epgUrl,
                    onUrlChange = { epgUrl = it },
                    interval = epgInterval,
                    onIntervalChange = { epgInterval = it },
                    onSave = {
                        settingsViewModel.saveEpgSettings(epgUrl, epgInterval)
                        focusManager.clearFocus()
                    }
                )

                Divider(modifier = Modifier.padding(vertical = 32.dp))

                ParentalControlSection(
                    isEnabled = isParentalControlEnabled,
                    onEnabledChange = {
                        if (it) {
                            parentalControlViewModel.setEnabled(true, PrefKeys.DEFAULT_PARENTAL_PIN)
                            Toast.makeText(localContext, "Control Parental Activado", Toast.LENGTH_SHORT).show()
                        } else {
                            pinAction = PinAction.DISABLE_CONTROL
                            showVerifyDialog = true
                        }
                    },
                    onChangePinClick = {
                        pinAction = PinAction.CHANGE_PIN
                        showVerifyDialog = true
                    },
                    showChangePinSection = showChangePinSection,
                    onPinChanged = { newPin ->
                        parentalControlViewModel.changePin(newPin)
                        showChangePinSection = false
                        Toast.makeText(localContext, "PIN actualizado correctamente", Toast.LENGTH_SHORT).show()
                    },
                    onCancelChangePin = { showChangePinSection = false }
                )

                Divider(modifier = Modifier.padding(vertical = 32.dp))

                SubtitleSettingsSection(
                    textColor = subTextColor,
                    onTextColorChange = { subTextColor = it },
                    bgColor = subBgColor,
                    onBgColorChange = { subBgColor = it },
                    textSize = subTextSize,
                    onTextSizeChange = { subTextSize = it },
                    onSave = {
                        settingsViewModel.saveSubtitleSettings(subTextColor.toArgb(), subBgColor.toArgb(), subTextSize)
                    }
                )

                Divider(modifier = Modifier.padding(vertical = 32.dp))

                DataManagementSection(
                    onExport = { settingsViewModel.exportFavoritesToLocalFile() },
                    onImport = { importLauncher.launch(arrayOf("application/json")) }
                )

                Divider(modifier = Modifier.padding(vertical = 32.dp))

                ToolsSection(onNavigateToDiagnostics = onNavigateToDiagnostics)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EpgSettingsSection(url: String, onUrlChange: (String) -> Unit, interval: Int, onIntervalChange: (Int) -> Unit, onSave: () -> Unit) {
    var intervalDropdownExpanded by remember { mutableStateOf(false) }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Configuración EPG", style = MaterialTheme.typography.titleLarge)
        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(
            value = url,
            onValueChange = onUrlChange,
            modifier = Modifier.fillMaxWidth(),
            label = { Text("URL del Archivo EPG XML") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Next),
            singleLine = true
        )
        Spacer(modifier = Modifier.height(16.dp))
        ExposedDropdownMenuBox(
            expanded = intervalDropdownExpanded,
            onExpandedChange = { intervalDropdownExpanded = !intervalDropdownExpanded },
        ) {
            OutlinedTextField(
                value = "$interval horas",
                onValueChange = {}, readOnly = true,
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = intervalDropdownExpanded) },
                modifier = Modifier.menuAnchor().fillMaxWidth()
            )
            ExposedDropdownMenu(
                expanded = intervalDropdownExpanded,
                onDismissRequest = { intervalDropdownExpanded = false }
            ) {
                PrefKeys.EPG_INTERVAL_OPTIONS.forEach { option ->
                    DropdownMenuItem(
                        text = { Text("$option horas") },
                        onClick = {
                            onIntervalChange(option)
                            intervalDropdownExpanded = false
                        }
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(24.dp))
        Button(onClick = onSave, modifier = Modifier.fillMaxWidth(0.6f)) { Text("Guardar Config. EPG") }
    }
}

@Composable
private fun ParentalControlSection(isEnabled: Boolean, onEnabledChange: (Boolean) -> Unit, onChangePinClick: () -> Unit, showChangePinSection: Boolean, onPinChanged: (String) -> Unit, onCancelChangePin: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Control Parental", style = MaterialTheme.typography.titleLarge)
        Spacer(modifier = Modifier.height(16.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Activar Control Parental", style = MaterialTheme.typography.titleMedium)
            Switch(checked = isEnabled, onCheckedChange = onEnabledChange)
        }
        AnimatedVisibility(visible = isEnabled) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(16.dp))
                Button(onClick = onChangePinClick, modifier = Modifier.fillMaxWidth(0.6f)) {
                    Text("Cambiar PIN")
                }
            }
        }
        AnimatedVisibility(visible = showChangePinSection && isEnabled) {
            ChangePinSection(onPinChanged = onPinChanged, onCancel = onCancelChangePin)
        }
    }
}

@Composable
private fun SubtitleSettingsSection(
    textColor: Color, onTextColorChange: (Color) -> Unit,
    bgColor: Color, onBgColorChange: (Color) -> Unit,
    textSize: Float, onTextSizeChange: (Float) -> Unit,
    onSave: () -> Unit
) {
    val colorOptions = listOf(Color.White, Color.Yellow, Color.Cyan, Color.Black)
    val backgroundOptions = listOf(Color.Transparent, Color.Black.copy(alpha = 0.5f), Color.Black)

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Configuración de Subtítulos", style = MaterialTheme.typography.titleLarge)
        Spacer(modifier = Modifier.height(16.dp))

        Text("Color del Texto", style = MaterialTheme.typography.titleMedium)
        Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            colorOptions.forEach { color ->
                ColorOption(color = color, isSelected = textColor == color, onClick = { onTextColorChange(color) })
            }
        }

        Text("Color del Fondo", style = MaterialTheme.typography.titleMedium)
        Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            backgroundOptions.forEach { color ->
                ColorOption(color = color, isSelected = bgColor == color, onClick = { onBgColorChange(color) })
            }
        }

        Text("Tamaño del Texto: ${textSize.toInt()}sp", style = MaterialTheme.typography.titleMedium)
        Slider(
            value = textSize,
            onValueChange = onTextSizeChange,
            valueRange = 16f..48f,
            steps = 15
        )

        Spacer(modifier = Modifier.height(24.dp))
        Button(onClick = onSave, modifier = Modifier.fillMaxWidth(0.6f)) {
            Text("Guardar Estilo")
        }
    }
}

@Composable
private fun ColorOption(color: Color, isSelected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(color)
            .border(
                width = 2.dp,
                color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                shape = CircleShape
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (isSelected) {
            val checkColor = if (color == Color.Black) Color.White else Color.Black
            Icon(Icons.Default.Check, contentDescription = "Selected", tint = checkColor)
        }
    }
}

@Composable
private fun DataManagementSection(onExport: () -> Unit, onImport: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Gestión de Datos", style = MaterialTheme.typography.titleLarge)
        Spacer(modifier = Modifier.height(16.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Button(onClick = onExport) { Text("Exportar Favs") }
            Button(onClick = onImport) { Text("Importar Favs") }
        }
    }
}

@Composable
private fun ToolsSection(onNavigateToDiagnostics: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Herramientas", style = MaterialTheme.typography.titleLarge)
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = onNavigateToDiagnostics, modifier = Modifier.fillMaxWidth(0.6f)) {
            Icon(Icons.Filled.NetworkCheck, null, Modifier.size(ButtonDefaults.IconSize))
            Spacer(Modifier.size(ButtonDefaults.IconSpacing))
            Text("Comprobar Canales")
        }
    }
}

@Composable
private fun VerifyPinDialog(
    action: PinAction,
    onDismiss: () -> Unit,
    onPinVerified: () -> Unit,
    parentalControlViewModel: ParentalControlViewModel
) {
    var enteredPin by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val title = if (action == PinAction.DISABLE_CONTROL) "Desactivar Control Parental" else "Cambiar PIN"
    val description = "Por favor, ingrese su PIN actual para continuar."

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                Text(description)
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedTextField(
                    value = enteredPin,
                    onValueChange = { enteredPin = it },
                    label = { Text("PIN Actual") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword, imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = {
                        scope.launch {
                            if (parentalControlViewModel.verifyPinAndUnlock(enteredPin)) {
                                onPinVerified()
                            } else {
                                Toast.makeText(context, "PIN Incorrecto", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }),
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                scope.launch {
                    if (parentalControlViewModel.verifyPinAndUnlock(enteredPin)) {
                        onPinVerified()
                    } else {
                        Toast.makeText(context, "PIN Incorrecto", Toast.LENGTH_SHORT).show()
                    }
                }
            }) {
                Text("Verificar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}

@Composable
private fun ChangePinSection(onPinChanged: (String) -> Unit, onCancel: () -> Unit) {
    var newPin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    val context = LocalContext.current

    Column(
        modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        OutlinedTextField(
            value = newPin,
            onValueChange = { if (it.length <= PrefKeys.MAX_PIN_LENGTH && it.all { c -> c.isDigit() } ) newPin = it },
            label = { Text("Nuevo PIN") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            visualTransformation = PasswordVisualTransformation()
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = confirmPin,
            onValueChange = { if (it.length <= PrefKeys.MAX_PIN_LENGTH && it.all { c -> c.isDigit() } ) confirmPin = it },
            label = { Text("Confirmar Nuevo PIN") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            visualTransformation = PasswordVisualTransformation()
        )
        Spacer(modifier = Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            OutlinedButton(onClick = onCancel) { Text("Cancelar") }
            Button(onClick = {
                if (newPin.length >= PrefKeys.MIN_PIN_LENGTH && newPin == confirmPin) {
                    onPinChanged(newPin)
                } else {
                    Toast.makeText(context, "Los PINs no coinciden o son inválidos", Toast.LENGTH_SHORT).show()
                }
            }) { Text("Guardar Nuevo PIN") }
        }
    }
}