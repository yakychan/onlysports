package com.tararira.onlysports.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class UpdateInfo(
    @SerialName("updateAvailable") val isUpdateAvailable: Boolean = false,
    @SerialName("isMandatory") val isMandatory: Boolean = false,
    @SerialName("latestVersionCode") val latestVersionCode: Int = 0,
    @SerialName("latestVersionName") val latestVersionName: String = "",
    @SerialName("apkUrl") val apkUrl: String = "",
    @SerialName("releaseNotes") val releaseNotes: String = ""
)
