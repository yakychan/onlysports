package com.tararira.onlysports.ui.screens

import android.app.Activity
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.tararira.onlysports.R

private const val BACK_PRESS_EXIT_DELAY = 2000L

@Composable
fun MainScreen(
    onNavigateToChannels: () -> Unit,
    onNavigateToMovies: () -> Unit,
    onNavigateToFavorites: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity
    var backPressedTime by remember { mutableStateOf(0L) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            MainMenuItem(text = "Canales", iconResId = R.drawable.ic_channels, onClick = onNavigateToChannels)
            MainMenuItem(text = "Películas", iconResId = R.drawable.ic_movies, onClick = onNavigateToMovies)
            MainMenuItem(text = "Favoritos", iconResId = R.drawable.ic_favorites, onClick = onNavigateToFavorites)
            MainMenuItem(text = "Configuración", iconResId = R.drawable.ic_settings, onClick = onNavigateToSettings)
        }

        BackHandler(enabled = true) {
            val currentTime = System.currentTimeMillis()
            if (currentTime - backPressedTime < BACK_PRESS_EXIT_DELAY) {
                activity?.finish()
            } else {
                Toast.makeText(context, "Presiona Atrás de nuevo para salir", Toast.LENGTH_SHORT).show()
                backPressedTime = currentTime
            }
        }
    }
}

@Composable
fun MainMenuItem(
    text: String,
    iconResId: Int,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .size(width = 160.dp, height = 140.dp)
            .clickable(onClick = onClick),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                painter = painterResource(id = iconResId),
                contentDescription = text,
                modifier = Modifier.size(56.dp),
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
