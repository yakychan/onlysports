package com.tararira.onlysports.data.repository

import android.content.Context
import android.util.Log
import androidx.datastore.preferences.core.edit
import com.tararira.onlysports.AppPrefsDataStore
import com.tararira.onlysports.data.epg.model.EpgProgramme
import com.tararira.onlysports.data.epg.parser.EpgXmlParser
import com.tararira.onlysports.data.local.PrefKeys
import com.tararira.onlysports.data.model.ChannelCategory
import com.tararira.onlysports.data.model.ChannelSample
import com.tararira.onlysports.data.model.MovieCategory
import com.tararira.onlysports.data.remote.ApiService
import com.tararira.onlysports.util.EncryptionHelper
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class ChannelRepository(
    private val context: Context,
    private val apiService: ApiService
) {
    companion object {
        private const val EPG_FILENAME = "epg_cache.xml"
        private val EPG_CACHE_DURATION_MILLIS = TimeUnit.HOURS.toMillis(PrefKeys.DEFAULT_EPG_REFRESH_INTERVAL_HOURS.toLong())
        private const val CHANNELS_JSON_URL = "http://IP/lista.json"
        private const val MOVIES_JSON_URL = "http://IP/peliculas.json"
    }

    private val logTag = "ChannelRepository"
    private val repositoryScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val _channelDataState = MutableStateFlow<ChannelDataResult>(ChannelDataResult.Loading)
    val channelDataFlow: StateFlow<ChannelDataResult> = _channelDataState.asStateFlow()
    private var allChannelsCache: List<ChannelSample>? = null

    private val _movieDataState = MutableStateFlow<MovieDataResult>(MovieDataResult.Loading)
    val movieDataFlow: StateFlow<MovieDataResult> = _movieDataState.asStateFlow()

    private val _epgDataStateFlow = MutableStateFlow<Map<String, List<EpgProgramme>>?>(null)
    val epgDataFlow: StateFlow<Map<String, List<EpgProgramme>>?> = _epgDataStateFlow.asStateFlow()
    private val isEpgRefreshing = AtomicBoolean(false)
    private val epgParser = EpgXmlParser()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()
    private val jsonParser = Json {
        ignoreUnknownKeys = true
        coerceInputValues = true
        isLenient = true
    }

    sealed class ChannelDataResult {
        object Loading : ChannelDataResult()
        data class Success(val categories: List<ChannelCategory>) : ChannelDataResult()
        data class Error(val message: String) : ChannelDataResult()
    }

    sealed class MovieDataResult {
        object Loading : MovieDataResult()
        data class Success(val categories: List<MovieCategory>) : MovieDataResult()
        data class Error(val message: String) : MovieDataResult()
    }

    init {
        forceRefreshChannels()
        repositoryScope.launch { loadInitialEpgFromFileCache() }
    }

    private suspend fun loadAndDecryptChannels() {
        if (_channelDataState.value !is ChannelDataResult.Loading) {
            _channelDataState.value = ChannelDataResult.Loading
        }
        withContext(Dispatchers.IO) {
            try {
                val responseBody = apiService.getRawEncryptedChannels(CHANNELS_JSON_URL)
                val encryptedBase64String = responseBody.string()
                if (encryptedBase64String.isBlank()) throw IOException("Respuesta vacía para lista de canales.")
                val decryptedJsonString = EncryptionHelper.decryptAES(encryptedBase64String)
                    ?: throw IOException("Fallo al desencriptar la lista de canales.")
                val categories: List<ChannelCategory> = jsonParser.decodeFromString(decryptedJsonString)
                allChannelsCache = categories.flatMap { it.samples }
                _channelDataState.value = ChannelDataResult.Success(categories)
            } catch (e: Exception) {
                _channelDataState.value = ChannelDataResult.Error("Error al cargar canales: ${e.message}")
                allChannelsCache = null
            }
        }
    }

    fun forceRefreshChannels() {
        repositoryScope.launch {
            loadAndDecryptChannels()
        }
    }

    private suspend fun loadAndDecryptMovies() {
        if (_movieDataState.value !is MovieDataResult.Loading) {
            _movieDataState.value = MovieDataResult.Loading
        }
        withContext(Dispatchers.IO) {
            try {
                val responseBody = apiService.getRawEncryptedMovies(MOVIES_JSON_URL)
                val encryptedBase64String = responseBody.string()
                if (encryptedBase64String.isBlank()) throw IOException("Respuesta vacía para lista de películas.")
                val decryptedJsonString = EncryptionHelper.decryptAES(encryptedBase64String)
                    ?: throw IOException("Fallo al desencriptar la lista de películas.")
                val categories: List<MovieCategory> = jsonParser.decodeFromString(decryptedJsonString)
                _movieDataState.value = MovieDataResult.Success(categories)
            } catch (e: Exception) {
                _movieDataState.value = MovieDataResult.Error("Error al cargar películas: ${e.message}")
            }
        }
    }

    fun forceRefreshMovies() {
        repositoryScope.launch {
            loadAndDecryptMovies()
        }
    }

    private suspend fun loadInitialEpgFromFileCache() {
        readEpgFromFile()?.let { parseAndEmitEpg(it) }
    }

    private suspend fun readEpgFromFile(): String? = withContext(Dispatchers.IO) {
        try { File(context.filesDir, EPG_FILENAME).takeIf { it.exists() }?.readText(Charsets.UTF_8) }
        catch (e: IOException) { null }
    }

    private suspend fun saveEpgToFile(xmlString: String): Boolean = withContext(Dispatchers.IO) {
        try { File(context.filesDir, EPG_FILENAME).writeText(xmlString, Charsets.UTF_8); true }
        catch (e: IOException) { false }
    }

    private suspend fun getLastEpgFetchTimestamp(): Long = withContext(Dispatchers.IO) {
        try { context.AppPrefsDataStore.data.map { prefs -> prefs[PrefKeys.EPG_LAST_FETCH_TIMESTAMP_KEY] ?: 0L }.first() }
        catch (e: Exception) { 0L }
    }

    private suspend fun updateLastEpgFetchTimestamp(timestamp: Long) {
        try { context.AppPrefsDataStore.edit { prefs -> prefs[PrefKeys.EPG_LAST_FETCH_TIMESTAMP_KEY] = timestamp } }
        catch (e: Exception) { Log.e(logTag, "Error updating EPG timestamp", e) }
    }

    fun refreshEpgInBackgroundIfNeeded() {
        if (isEpgRefreshing.compareAndSet(false, true)) {
            repositoryScope.launch {
                try {
                    val now = System.currentTimeMillis()
                    val lastFetchTime = getLastEpgFetchTimestamp()
                    val needsRefresh = (now - lastFetchTime >= EPG_CACHE_DURATION_MILLIS) || _epgDataStateFlow.value == null

                    if (needsRefresh) {
                        fetchEpgXml(PrefKeys.DEFAULT_EPG_URL)?.let { fetchedXml ->
                            if (saveEpgToFile(fetchedXml)) {
                                updateLastEpgFetchTimestamp(now)
                            }
                            parseAndEmitEpg(fetchedXml)
                        }
                    } else if (_epgDataStateFlow.value == null) {
                        readEpgFromFile()?.let { parseAndEmitEpg(it) }
                    }
                } catch (e: Exception) {
                    Log.e(logTag, "Error during background EPG refresh check", e)
                } finally {
                    isEpgRefreshing.set(false)
                }
            }
        }
    }

    private suspend fun parseAndEmitEpg(xmlString: String) {
        try {
            val parsedData = withContext(Dispatchers.Default) { epgParser.parse(xmlString) }
            _epgDataStateFlow.value = parsedData
        } catch (e: Exception) {
            _epgDataStateFlow.value = null
        }
    }

    private suspend fun fetchEpgXml(url: String): String? = withContext(Dispatchers.IO) {
        if (url.isBlank()) return@withContext null
        val request = Request.Builder().url(url).build()
        try {
            okHttpClient.newCall(request).execute().use { response ->
                if (response.isSuccessful) response.body?.string() else null
            }
        } catch (e: Exception) { null }
    }

    suspend fun getChannelsById(channelId: String): Result<List<ChannelSample>> {
        val cache = allChannelsCache ?: return Result.failure(IllegalStateException("Cache no inicializado."))
        return Result.success(cache.filter { it.channelId == channelId })
    }

    suspend fun getFavoriteChannelDetails(favoriteIds: Set<String>): Result<List<ChannelSample>> {
        val cache = allChannelsCache ?: return Result.failure(IllegalStateException("Cache no inicializado."))
        val favoriteMap = cache
            .filter { it.channelId in favoriteIds && !it.channelId.isNullOrBlank() }
            .associateBy { it.channelId!! }
        return Result.success(favoriteMap.values.toList())
    }

    suspend fun getFlatUniqueChannels(): Result<List<ChannelSample>> {
        val cache = allChannelsCache
        return if (cache != null) {
            val uniqueList = cache
                .filter { !it.channelId.isNullOrBlank() }
                .distinctBy { it.channelId }
            Result.success(uniqueList)
        } else {
            Result.failure(IllegalStateException("Cache de canales no inicializada o carga en progreso."))
        }
    }
}