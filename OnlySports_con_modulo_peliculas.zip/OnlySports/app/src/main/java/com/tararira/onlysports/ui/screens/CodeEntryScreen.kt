package com.tararira.onlysports.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CodeEntryScreen(
    correctCode: String, // El código secreto real (pasado desde AppNavigation/ViewModel)
    onCodeVerified: () -> Unit, // Lambda a llamar si el código es correcto
    onCancel: () -> Unit // Lambda a llamar para volver atrás (onBackPressed)
) {
    // Estado local para el código ingresado por el usuario
    var enteredCode by remember { mutableStateOf("") }
    // Estado local para mostrar mensaje de error
    var showError by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Acceso Restringido") }, // Título de la pantalla
                navigationIcon = {
                    // Botón para cancelar y volver atrás
                    IconButton(onClick = onCancel) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Cancelar y Volver")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface,
                    navigationIconContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize() // Ocupar toda la pantalla
                .padding(paddingValues) // Respetar padding del Scaffold
                .padding(horizontal = 48.dp, vertical = 32.dp), // Padding adicional
            horizontalAlignment = Alignment.CenterHorizontally, // Centrar contenido horizontalmente
            verticalArrangement = Arrangement.Center // Centrar contenido verticalmente
        ) {
            // Título dentro del contenido
            Text("Ingresar Código", style = MaterialTheme.typography.headlineMedium)
            Spacer(modifier = Modifier.height(24.dp)) // Espacio

            // Campo de texto para ingresar el código
            OutlinedTextField(
                value = enteredCode,
                onValueChange = {
                    // Filtrar para aceptar solo dígitos
                    if (it.all { char -> char.isDigit() }) {
                        enteredCode = it
                        showError = false // Ocultar error al escribir de nuevo
                    }
                },
                label = { Text("Código Numérico") },
                visualTransformation = PasswordVisualTransformation(), // Ocultar caracteres
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), // Teclado numérico
                isError = showError, // Mostrar borde rojo si hay error
                singleLine = true, // Permitir solo una línea
                modifier = Modifier.fillMaxWidth(0.7f) // Ancho del campo de texto
            )

            // Mostrar mensaje de error si aplica
            if (showError) {
                Text(
                    "Código incorrecto. Intente de nuevo.",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            Spacer(modifier = Modifier.height(32.dp)) // Espacio antes de botones

            // Fila para los botones de acción
            Row(
                modifier = Modifier.fillMaxWidth(0.8f), // Ancho de la fila de botones
                horizontalArrangement = Arrangement.SpaceEvenly // Espaciar botones
            ) {
                // Botón Cancelar
                OutlinedButton(onClick = onCancel) {
                    Text("Cancelar")
                }
                // Botón Verificar
                Button(onClick = {
                    // Comprobar si el código ingresado es correcto
                    if (enteredCode == correctCode) {
                        onCodeVerified() // Llamar al callback si es correcto
                    } else {
                        showError = true // Marcar error
                        enteredCode = "" // Limpiar el campo para nuevo intento
                    }
                }) {
                    Text("Verificar")
                }
            }
        }
    }
}