package com.tararira.onlysports.player

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.Log
import androidx.media3.common.util.UnstableApi
import androidx.media3.common.util.Util
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.dash.DashMediaSource
import androidx.media3.exoplayer.drm.DefaultDrmSessionManagerProvider
import androidx.media3.exoplayer.drm.DrmSessionManagerProvider
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.smoothstreaming.SsMediaSource
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.exoplayer.util.EventLogger
import com.tararira.onlysports.data.model.MovieSample
import java.util.Locale

@OptIn(UnstableApi::class)
class MoviePlayerManager(
    private val context: Context,
    private val movie: MovieSample
) : Player.Listener {
    val exoPlayer: ExoPlayer
    private val trackSelector: DefaultTrackSelector
    private var currentSubtitleTrackIndexInternal = -1
    private val logTag = "MoviePlayerManager"

    init {
        trackSelector = DefaultTrackSelector(context)
        exoPlayer = ExoPlayer.Builder(context)
            .setTrackSelector(trackSelector)
            .build().apply {
                addListener(this@MoviePlayerManager)
                addAnalyticsListener(EventLogger(logTag))
                val mediaSource = buildMediaSource(movie)
                setMediaSource(mediaSource)
                playWhenReady = true
                prepare()
            }
    }

    override fun onPlayerError(error: PlaybackException) {
        Log.e(logTag, "Player Error: ${error.message}", error)
        Toast.makeText(context, "Error de reproducción: ${error.errorCodeName}", Toast.LENGTH_LONG).show()
    }

    private fun buildMediaSource(sample: MovieSample): MediaSource {
        val mediaItemBuilder = MediaItem.Builder().setUri(sample.uri)
        val dataSourceFactory = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)

        var drmSessionManagerProvider: DrmSessionManagerProvider? = null
        if (sample.drmScheme != null && sample.drmLicenseUri != null) {
            val drmSchemeUuid = when (sample.drmScheme.lowercase()) {
                "widevine" -> C.WIDEVINE_UUID
                "clearkey" -> C.CLEARKEY_UUID
                else -> null
            }
            if (drmSchemeUuid != null) {
                val drmHttpDataSourceFactory = DefaultHttpDataSource.Factory()
                mediaItemBuilder.setDrmConfiguration(
                    MediaItem.DrmConfiguration.Builder(drmSchemeUuid)
                        .setLicenseUri(sample.drmLicenseUri).build()
                )
                val provider = DefaultDrmSessionManagerProvider()
                provider.setDrmHttpDataSourceFactory(drmHttpDataSourceFactory)
                drmSessionManagerProvider = provider
            }
        }

        val contentType = Util.inferContentType(Uri.parse(sample.uri))
        val mediaSourceFactory: MediaSource.Factory = when (contentType) {
            C.CONTENT_TYPE_DASH -> DashMediaSource.Factory(dataSourceFactory)
            C.CONTENT_TYPE_HLS -> HlsMediaSource.Factory(dataSourceFactory)
            C.CONTENT_TYPE_SS -> SsMediaSource.Factory(dataSourceFactory)
            else -> ProgressiveMediaSource.Factory(dataSourceFactory)
        }

        drmSessionManagerProvider?.let { mediaSourceFactory.setDrmSessionManagerProvider(it) }

        return mediaSourceFactory.createMediaSource(mediaItemBuilder.build())
    }

    fun cycleAudioTrack(forward: Boolean) {
        if (!exoPlayer.isCommandAvailable(Player.COMMAND_GET_TRACKS)) return
        val currentTracks = exoPlayer.currentTracks
        val availableAudioTracks = mutableListOf<Pair<Tracks.Group, Int>>()
        for (group in currentTracks.groups) {
            if (group.type == C.TRACK_TYPE_AUDIO) {
                for (i in 0 until group.length) {
                    if (group.isTrackSupported(i)) availableAudioTracks.add(Pair(group, i))
                }
            }
        }
        if (availableAudioTracks.size <= 1) {
            Toast.makeText(context, "No hay otras pistas de audio disponibles", Toast.LENGTH_SHORT).show()
            return
        }
        var currentSelectedListIndex = availableAudioTracks.indexOfFirst { it.first.isTrackSelected(it.second) }
        if (currentSelectedListIndex == -1) currentSelectedListIndex = 0
        val nextIndex = (currentSelectedListIndex + (if (forward) 1 else -1) + availableAudioTracks.size) % availableAudioTracks.size
        val (nextGroup, nextTrackIndexInGroup) = availableAudioTracks[nextIndex]
        val trackOverride = TrackSelectionOverride(nextGroup.mediaTrackGroup, nextTrackIndexInGroup)
        exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters.buildUpon()
            .clearOverridesOfType(C.TRACK_TYPE_AUDIO)
            .addOverride(trackOverride)
            .build()
        val selectedFormat = nextGroup.getTrackFormat(nextTrackIndexInGroup)
        val language = selectedFormat.language?.let { Locale(it).displayLanguage } ?: "Desconocido"
        val label = selectedFormat.label ?: "Pista ${nextIndex + 1}"
        val trackInfo = if (selectedFormat.label != null) label else "$language (${selectedFormat.channelCount}ch)"
        Toast.makeText(context, "Audio: $trackInfo", Toast.LENGTH_SHORT).show()
    }

    fun cycleSubtitleTrack() {
        if (!exoPlayer.isCommandAvailable(Player.COMMAND_GET_TRACKS)) return
        val textGroups = exoPlayer.currentTracks.groups.filter { it.type == C.TRACK_TYPE_TEXT && it.isSupported }
        if (textGroups.isEmpty() || textGroups.first().length == 0) {
            Toast.makeText(context, "Subtítulos no disponibles", Toast.LENGTH_SHORT).show()
            return
        }

        val textGroup = textGroups.first().mediaTrackGroup
        currentSubtitleTrackIndexInternal++

        if (currentSubtitleTrackIndexInternal >= textGroup.length) {
            currentSubtitleTrackIndexInternal = -1
        }

        val parametersBuilder = exoPlayer.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, currentSubtitleTrackIndexInternal == -1)
            .clearOverridesOfType(C.TRACK_TYPE_TEXT)

        if (currentSubtitleTrackIndexInternal != -1) {
            val trackOverride = TrackSelectionOverride(textGroup, currentSubtitleTrackIndexInternal)
            parametersBuilder.addOverride(trackOverride)
            val format = textGroup.getFormat(currentSubtitleTrackIndexInternal)
            val lang = format.language?.let { Locale(it).displayLanguage } ?: "Pista ${currentSubtitleTrackIndexInternal + 1}"
            Toast.makeText(context, "Subtítulos: ${format.label ?: lang}", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Subtítulos: Desactivados", Toast.LENGTH_SHORT).show()
        }

        exoPlayer.trackSelectionParameters = parametersBuilder.build()
    }

    fun releasePlayer() {
        try {
            exoPlayer.removeListener(this)
            exoPlayer.release()
        } catch (e: Exception) {
            Log.e(logTag, "Exception during player release", e)
        }
    }
}