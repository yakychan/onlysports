package com.tararira.onlysports.navigation

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Login : Screen("login")
    object Main : Screen("main")
    object ChannelList : Screen("channel_list")
    object Movies : Screen("movies")
    object Favorites : Screen("favorites")
    object Settings : Screen("settings")
    object Player : Screen("player/{channelId}") {
        fun createRoute(channelId: String) = "player/$channelId"
    }
    object MoviePlayer : Screen("movie_player")
    object CodeEntry : Screen("code_entry")
    object ChannelDiagnostics : Screen("channel_diagnostics")
    object ParentalPinEntry : Screen("parental_pin_entry/{channelIdToPlay}") {
        fun createRoute(channelId: String) = "parental_pin_entry/$channelId"
    }
}
