package com.tararira.onlysports.data.epg.model

import android.util.Log // Para logs de error
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException

// Representa una entrada <programme> en el XMLTV
data class EpgProgramme(
    val channelId: String,
    val title: String,
    val description: String?,
    val start: OffsetDateTime, // Almacena la hora original con su desfase UTC/Z
    val stop: OffsetDateTime   // Almacena la hora original con su desfase UTC/Z
) {
    companion object {
        // Formateador solo para la hora local (ej: 14:30)
        private val localTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")
        // Zona horaria del dispositivo
        private val deviceZoneId = ZoneId.systemDefault()
        private const val TAG = "EpgProgramme"
    }

    /**
     * Comprueba si el programa está al aire en un momento dado.
     * Compara directamente OffsetDateTime, lo cual es correcto para instantes absolutos.
     */
    fun isAiringAt(dateTime: OffsetDateTime): Boolean {
        // Verifica: dateTime >= start AND dateTime < stop
        return !dateTime.isBefore(start) && dateTime.isBefore(stop)
    }

    /**
     * Devuelve el rango horario (ej: "14:30 - 15:00") formateado
     * en la ZONA HORARIA LOCAL del dispositivo.
     */
    fun getFormattedTimeRange(): String {
        return try {
            // 1. Convertir start y stop al mismo instante pero en la zona horaria local
            val localStart = start.atZoneSameInstant(deviceZoneId)
            val localStop = stop.atZoneSameInstant(deviceZoneId)

            // 2. Formatear usando el formateador HH:mm
            "${localStart.format(localTimeFormatter)} - ${localStop.format(localTimeFormatter)}"
        } catch (e: DateTimeParseException) {
            Log.w(TAG, "Error formateando rango horario para '$title': ${e.message}")
            // Fallback: Mostrar horas originales indicando posible UTC
            "${start.format(localTimeFormatter)} - ${stop.format(localTimeFormatter)} (UTC?)"
        } catch (e: Exception) {
            Log.e(TAG, "Error inesperado en getFormattedTimeRange para '$title'", e)
            "Error hora" // Mensaje genérico de error
        }
    }
}