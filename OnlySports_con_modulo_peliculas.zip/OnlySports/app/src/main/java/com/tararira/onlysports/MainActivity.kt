package com.tararira.onlysports

import android.app.UiModeManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.rememberNavController
import com.tararira.onlysports.data.model.UpdateInfo
import com.tararira.onlysports.data.remote.RetrofitClient
import com.tararira.onlysports.navigation.AppNavigation
import com.tararira.onlysports.ui.theme.OnlySportsAppTheme
import com.tararira.onlysports.util.UpdateHelper
import com.tararira.onlysports.viewmodel.UpdateState
import com.tararira.onlysports.viewmodel.UpdateViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class UpdateViewModelFactory(private val context: Context) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(UpdateViewModel::class.java)) {
            return UpdateViewModel(RetrofitClient.apiService, context.applicationContext) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

class MainActivity : ComponentActivity() {

    private var wakeLock: PowerManager.WakeLock? = null
    private val WAKE_LOCK_TAG = "OnlySports::ScreenLock"
    private val mainActivityScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var isPhoneDevice: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)

        val uiModeManager = getSystemService(UI_MODE_SERVICE) as UiModeManager
        isPhoneDevice = uiModeManager.currentModeType != Configuration.UI_MODE_TYPE_TELEVISION

        if (isPhoneDevice) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            hideSystemBars()
            mainActivityScope.launch { delay(100); hideSystemBars() }
        }

        try {
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = powerManager.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, WAKE_LOCK_TAG)
            wakeLock?.setReferenceCounted(false)
        } catch (e: Exception) { Log.e("MainActivity", "Error creating WakeLock", e) }

        setContent {
            OnlySportsAppTheme {
                val updateViewModel: UpdateViewModel = viewModel(factory = UpdateViewModelFactory(this))

                LaunchedEffect(Unit) {
                    updateViewModel.checkForUpdates()
                }

                val updateState by updateViewModel.updateState.collectAsStateWithLifecycle()

                UpdateDialog(
                    updateState = updateState,
                    onUpdateClick = { updateInfo ->
                        updateViewModel.startDownload(updateInfo)
                    },
                    onInstallClick = { apkUri ->
                        updateViewModel.installUpdate(this, apkUri)
                    },
                    onDismiss = {
                        updateViewModel.dismissUpdate()
                    }
                )

                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    val navController = rememberNavController()
                    AppNavigation(navController = navController, isPhone = isPhoneDevice)
                }
            }
        }
    }

    @Composable
    private fun UpdateDialog(
        updateState: UpdateState,
        onUpdateClick: (UpdateInfo) -> Unit,
        onInstallClick: (Uri) -> Unit,
        onDismiss: () -> Unit
    ) {
        val context = this
        val unknownSourcesLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.StartActivityForResult(),
            onResult = {}
        )

        when (updateState) {
            is UpdateState.UpdateAvailable -> {
                val isMandatory = updateState.info.isMandatory
                AlertDialog(
                    onDismissRequest = { if (!isMandatory) onDismiss() },
                    title = { Text(if (isMandatory) "Actualización Obligatoria" else "Actualización Disponible", fontWeight = FontWeight.Bold) },
                    text = {
                        Text("Hay una nueva versión (v${updateState.info.latestVersionName}) disponible.\n\nNotas de la versión:\n${updateState.info.releaseNotes}")
                    },
                    confirmButton = {
                        Button(onClick = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                if (context.packageManager.canRequestPackageInstalls()) {
                                    onUpdateClick(updateState.info)
                                } else {
                                    val intent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES).apply {
                                        data = Uri.parse("package:${context.packageName}")
                                    }
                                    unknownSourcesLauncher.launch(intent)
                                    Toast.makeText(context, "Por favor, habilita la instalación desde esta fuente.", Toast.LENGTH_LONG).show()
                                }
                            } else {
                                onUpdateClick(updateState.info)
                            }
                        }) {
                            Text("Descargar")
                        }
                    },
                    dismissButton = {
                        if (!isMandatory) {
                            TextButton(onClick = onDismiss) {
                                Text("Más tarde")
                            }
                        }
                    }
                )
            }
            is UpdateState.Downloading -> {
                AlertDialog(
                    onDismissRequest = {},
                    title = { Text("Descargando...", fontWeight = FontWeight.Bold) },
                    text = {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            CircularProgressIndicator(progress = { updateState.progress / 100f })
                            Spacer(modifier = Modifier.height(16.dp))
                            Text("${updateState.progress}%")
                        }
                    },
                    confirmButton = {}
                )
            }
            is UpdateState.DownloadComplete -> {
                AlertDialog(
                    onDismissRequest = {},
                    title = { Text("Descarga Completa", fontWeight = FontWeight.Bold) },
                    text = { Text("La actualización está lista para ser instalada.") },
                    confirmButton = {
                        Button(onClick = { onInstallClick(updateState.apkUri) }) {
                            Text("Instalar")
                        }
                    }
                )
            }
            is UpdateState.Error -> {
                LaunchedEffect(updateState.message) {
                    Toast.makeText(context, updateState.message, Toast.LENGTH_LONG).show()
                    onDismiss()
                }
            }
            else -> {}
        }
    }

    override fun onResume() {
        super.onResume()
        acquireWakeLock()
        if (isPhoneDevice) {
            hideSystemBars()
            mainActivityScope.launch { delay(50); hideSystemBars()}
        }
    }

    override fun onPause() {
        super.onPause()
        releaseWakeLock()
    }

    override fun onDestroy() {
        super.onDestroy()
        releaseWakeLock()
        mainActivityScope.cancel()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && isPhoneDevice) {
            hideSystemBars()
        }
    }

    private fun hideSystemBars() {
        try {
            val windowInsetsController = WindowCompat.getInsetsController(window, window.decorView)
            windowInsetsController.hide(WindowInsetsCompat.Type.systemBars())
            windowInsetsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } catch (e: Exception) { Log.e("MainActivity", "Error hiding system bars", e) }
    }

    private fun acquireWakeLock() {
        try {
            if (wakeLock?.isHeld == false) {
                wakeLock?.acquire()
            }
        } catch (e: Exception) { Log.e("MainActivity", "Error acquiring WakeLock", e) }
    }

    private fun releaseWakeLock() {
        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        } catch (e: Exception) { Log.e("MainActivity", "Error releasing WakeLock", e) }
    }
}