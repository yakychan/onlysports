package com.tararira.onlysports.data.model

import android.annotation.SuppressLint
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@SuppressLint("UnsafeOptInUsageError")
@Serializable
data class ChannelSample(
    @SerialName("channelId") val channelId: String?,
    @SerialName("name") val name: String,
    @SerialName("uri") val uri: String,
    @SerialName("icono") val iconUrl: String?,
    @SerialName("drm_scheme") val drmScheme: String? = null,
    @SerialName("drm_license_uri") val drmLicenseUri: String? = null,
    @SerialName("referer") val referer: String? = null,
    @SerialName("user_agent") val userAgent: String? = null,
    @SerialName("adult") val adult: Boolean? = null
)

@SuppressLint("UnsafeOptInUsageError")
@Serializable
data class PlayableChannelInfo(
    val name: String,
    val iconUrl: String,
    val uris: List<String>,
    val drmScheme: String?,
    val drmLicenseUri: String?
)
