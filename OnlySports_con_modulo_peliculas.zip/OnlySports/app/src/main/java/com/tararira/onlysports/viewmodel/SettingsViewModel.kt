package com.tararira.onlysports.viewmodel

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.os.Environment
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tararira.onlysports.data.local.FavoritesRepository
import com.tararira.onlysports.data.local.SettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class SettingsUiState(
    val epgUrl: String = "",
    val epgInterval: Int = 24,
    val subTextColor: Int = 0,
    val subBgColor: Int = 0,
    val subTextSize: Float = 24f,
    val isLoading: Boolean = true,
)

class SettingsViewModel(
    private val settingsRepository: SettingsRepository,
    private val favoritesRepository: FavoritesRepository,
    private val context: Context
) : ViewModel() {

    private val _toastMessage = MutableSharedFlow<String>()
    val toastMessage: SharedFlow<String> = _toastMessage.asSharedFlow()

    val uiState: StateFlow<SettingsUiState> = combine(
        settingsRepository.epgUrlFlow,
        settingsRepository.epgRefreshIntervalHoursFlow,
        settingsRepository.subtitleTextColorFlow,
        settingsRepository.subtitleBackgroundColorFlow,
        settingsRepository.subtitleTextSizeFlow
    ) { url, interval, textColor, bgColor, textSize ->
        SettingsUiState(
            epgUrl = url,
            epgInterval = interval,
            subTextColor = textColor,
            subBgColor = bgColor,
            subTextSize = textSize,
            isLoading = false
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = SettingsUiState(isLoading = true)
    )

    fun saveEpgSettings(newEpgUrl: String, newEpgInterval: Int) {
        viewModelScope.launch {
            settingsRepository.saveEpgSettings(newEpgUrl, newEpgInterval)
            _toastMessage.emit("Configuración EPG guardada")
        }
    }

    fun saveSubtitleSettings(textColor: Int, backgroundColor: Int, textSize: Float) {
        viewModelScope.launch {
            settingsRepository.saveSubtitleSettings(textColor, backgroundColor, textSize)
            _toastMessage.emit("Estilo de subtítulos guardado")
        }
    }

    fun exportFavoritesToLocalFile() {
        viewModelScope.launch {
            try {
                val jsonString = favoritesRepository.exportFavoritesToJson()
                val path = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)
                val file = File(path, "onlysports_favorites.json")

                withContext(Dispatchers.IO) {
                    file.writeText(jsonString)
                }
                _toastMessage.emit("Favoritos exportados a: ${file.absolutePath}")
            } catch (e: Exception) {
                _toastMessage.emit("Error al exportar favoritos: ${e.message}")
            }
        }
    }

    fun onImportFavorites(contentResolver: ContentResolver, uri: Uri) {
        viewModelScope.launch {
            try {
                val jsonString = withContext(Dispatchers.IO) {
                    contentResolver.openInputStream(uri)?.use { inputStream ->
                        inputStream.bufferedReader().readText()
                    } ?: throw Exception("No se pudo abrir el archivo.")
                }
                val result = favoritesRepository.importFavoritesFromJson(jsonString)
                if (result.isSuccess) {
                    _toastMessage.emit("Favoritos importados correctamente.")
                } else {
                    _toastMessage.emit("Error: El archivo no es válido.")
                }
            } catch (e: Exception) {
                _toastMessage.emit("Error al importar favoritos: ${e.message}")
            }
        }
    }
}