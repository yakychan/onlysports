package com.tararira.onlysports.util

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

class DownloadCompletedReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context?, intent: Intent?) {
        val logTag = "DownloadReceiver"
        if (context == null || intent == null) return

        if (intent.action == DownloadManager.ACTION_DOWNLOAD_COMPLETE) {
            val id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1)
            if (id == -1L) {
                Log.e(logTag, "Download failed: Invalid download ID.")
                return
            }

            val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val query = DownloadManager.Query().setFilterById(id)
            val cursor = downloadManager.query(query)

            if (cursor.moveToFirst()) {
                val statusIndex = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS)
                val status = cursor.getInt(statusIndex)

                if (status == DownloadManager.STATUS_SUCCESSFUL) {
                    Log.d(logTag, "Download successful for ID: $id")
                    val pathIndex = cursor.getColumnIndex(DownloadManager.COLUMN_LOCAL_FILENAME)
                    val downloadedFilePath = cursor.getString(pathIndex)

                    if (downloadedFilePath != null) {
                        val file = File(downloadedFilePath)
                        val fileUri: Uri = try {
                            FileProvider.getUriForFile(
                                context,
                                "${context.packageName}.provider",
                                file
                            )
                        } catch (e: Exception) {
                            Log.e(logTag, "Error getting file URI with FileProvider", e)
                            Toast.makeText(context, "Error al preparar el archivo de instalación.", Toast.LENGTH_LONG).show()
                            return
                        }

                        val installIntent = Intent(Intent.ACTION_VIEW).apply {
                            setDataAndType(fileUri, "application/vnd.android.package-archive")
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }

                        try {
                            context.startActivity(installIntent)
                        } catch (e: Exception) {
                            Log.e(logTag, "Error starting install intent for URI: $fileUri", e)
                            Toast.makeText(context, "No se pudo abrir el instalador de la aplicación.", Toast.LENGTH_LONG).show()
                        }
                    } else {
                        Log.e(logTag, "Download successful but file path is null.")
                    }
                } else {
                    val reasonIndex = cursor.getColumnIndex(DownloadManager.COLUMN_REASON)
                    val reason = cursor.getInt(reasonIndex)
                    Log.e(logTag, "Download failed for ID: $id. Status: $status, Reason: $reason")
                }
            }
            cursor.close()
        }
    }
}