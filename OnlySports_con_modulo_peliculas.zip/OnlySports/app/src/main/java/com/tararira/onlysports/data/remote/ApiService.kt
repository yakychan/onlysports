package com.tararira.onlysports.data.remote

import com.tararira.onlysports.data.model.LoginResponse
import com.tararira.onlysports.data.model.UpdateInfo
import com.tararira.onlysports.data.model.ValidationResponse
import okhttp3.ResponseBody
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query
import retrofit2.http.Url

interface ApiService {
    @GET
    suspend fun getRawEncryptedChannels(@Url url: String): ResponseBody

    @GET
    suspend fun getRawEncryptedMovies(@Url url: String): ResponseBody

    @GET
    suspend fun getEncryptedUserList(@Url url: String): ResponseBody

    @FormUrlEncoded
    @POST("api_login.php")
    suspend fun login(
        @Field("username") username: String,
        @Field("password") password: String
    ): LoginResponse

    @GET("api_validate_session.php")
    suspend fun validateSession(
        @Query("username") username: String
    ): ValidationResponse

    @GET
    suspend fun getUpdateInfo(@Url url: String): UpdateInfo
}
