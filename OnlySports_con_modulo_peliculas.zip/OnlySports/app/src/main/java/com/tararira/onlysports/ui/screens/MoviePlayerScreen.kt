package com.tararira.onlysports.ui.screens

import android.app.Activity
import android.graphics.Typeface
import android.util.Log
import android.util.TypedValue
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import com.tararira.onlysports.data.local.SettingsRepository
import com.tararira.onlysports.player.MoviePlayerManager
import com.tararira.onlysports.viewmodel.MoviePlayerViewModel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@androidx.annotation.OptIn(UnstableApi::class)
@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun MoviePlayerScreen(
    viewModel: MoviePlayerViewModel,
    onBackPressed: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val view = LocalView.current
    val window = (view.context as? Activity)?.window
    val focusRequester = remember { FocusRequester() }

    var playerManager by remember { mutableStateOf<MoviePlayerManager?>(null) }
    var captionStyle by remember { mutableStateOf<CaptionStyleCompat?>(null) }
    var captionSize by remember { mutableStateOf(24f) }

    val settingsRepository = remember { SettingsRepository(context) }
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        coroutineScope.launch {
            captionStyle = CaptionStyleCompat(
                settingsRepository.subtitleTextColorFlow.first(),
                settingsRepository.subtitleBackgroundColorFlow.first(),
                android.graphics.Color.TRANSPARENT,
                CaptionStyleCompat.EDGE_TYPE_DROP_SHADOW,
                android.graphics.Color.BLACK,
                Typeface.DEFAULT_BOLD
            )
            captionSize = settingsRepository.subtitleTextSizeFlow.first()
        }
    }

    LaunchedEffect(uiState.movie) {
        val movie = uiState.movie
        if (movie != null && playerManager == null) {
            playerManager = MoviePlayerManager(context, movie)
        }
    }

    DisposableEffect(Unit) {
        window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose {
            window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            playerManager?.releasePlayer()
        }
    }

    BackHandler {
        onBackPressed()
    }

    Box(
        modifier = Modifier.fillMaxSize().background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        val localPlayerManager = playerManager
        if (localPlayerManager != null) {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        player = localPlayerManager.exoPlayer
                        useController = true
                    }
                },
                update = { playerView ->
                    playerView.player = localPlayerManager.exoPlayer
                    captionStyle?.let { playerView.subtitleView?.setStyle(it) }
                    playerView.subtitleView?.setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, captionSize)

                    try {
                        focusRequester.requestFocus()
                    } catch (e: Exception) {
                        Log.e("MoviePlayerScreen", "Error requesting focus in update block: ${e.message}")
                    }
                },
                modifier = Modifier
                    .fillMaxSize()
                    .focusRequester(focusRequester)
                    .focusable()
                    .onKeyEvent { keyEvent ->
                        if (keyEvent.type == KeyEventType.KeyDown) {
                            when (keyEvent.key) {
                                Key.DirectionLeft -> {
                                    localPlayerManager.cycleSubtitleTrack()
                                    true
                                }
                                Key.DirectionRight -> {
                                    localPlayerManager.cycleAudioTrack(true)
                                    true
                                }
                                else -> false
                            }
                        } else {
                            false
                        }
                    }
            )
        } else {
            if (uiState.movie == null) {
                Text("Error al cargar la película.", color = Color.White, textAlign = TextAlign.Center)
            } else {
                CircularProgressIndicator()
            }
        }
    }
}