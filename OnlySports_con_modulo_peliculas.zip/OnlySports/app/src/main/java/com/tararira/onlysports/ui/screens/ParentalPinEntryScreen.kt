package com.tararira.onlysports.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.tararira.onlysports.data.local.PrefKeys
import com.tararira.onlysports.viewmodel.ParentalControlViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ParentalPinEntryScreen(
    channelIdToPlay: String,
    parentalControlViewModel: ParentalControlViewModel,
    onPinVerified: (String) -> Unit,
    onCancel: () -> Unit
) {
    var enteredPin by remember { mutableStateOf("") }
    var showError by remember { mutableStateOf(false) }
    var showPasswordAsText by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val focusRequester = remember { FocusRequester() }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        focusRequester.requestFocus()
    }

    val verifyPinAction: () -> Unit = {
        scope.launch {
            if (parentalControlViewModel.verifyPinAndUnlock(enteredPin)) {
                onPinVerified(channelIdToPlay)
            } else {
                showError = true
                enteredPin = ""
                Toast.makeText(context, "PIN Incorrecto", Toast.LENGTH_SHORT).show()
            }
            focusManager.clearFocus()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Verificación Parental") },
                navigationIcon = {
                    IconButton(onClick = onCancel) {
                        Icon(Icons.Filled.ArrowBack, "Cancelar")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 48.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("Ingresar PIN Parental", style = MaterialTheme.typography.headlineMedium)
            Spacer(modifier = Modifier.height(24.dp))

            OutlinedTextField(
                value = enteredPin,
                onValueChange = {
                    if (it.length <= PrefKeys.MAX_PIN_LENGTH && it.all { char -> char.isDigit() }) {
                        enteredPin = it
                        showError = false
                    }
                },
                label = { Text("PIN") },
                visualTransformation = if (showPasswordAsText) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.NumberPassword,
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(onDone = { verifyPinAction() }),
                isError = showError,
                singleLine = true,
                trailingIcon = {
                    IconButton(onClick = { showPasswordAsText = !showPasswordAsText }) {
                        Icon(
                            imageVector = if (showPasswordAsText) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                            contentDescription = if (showPasswordAsText) "Ocultar PIN" else "Mostrar PIN"
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth(0.7f).focusRequester(focusRequester)
            )

            if (showError) {
                Text(
                    "PIN incorrecto. Intente de nuevo.",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            Spacer(modifier = Modifier.height(32.dp))
            Row(
                modifier = Modifier.fillMaxWidth(0.8f),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                OutlinedButton(onClick = onCancel) {
                    Text("Cancelar")
                }
                Button(onClick = verifyPinAction) {
                    Text("Verificar")
                }
            }
        }
    }
}