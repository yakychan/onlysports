package com.tararira.onlysports.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tararira.onlysports.data.local.SettingsRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class ParentalControlViewModel(
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val _isEnabled = MutableStateFlow(false)
    val isEnabled: StateFlow<Boolean> = _isEnabled.asStateFlow()

    private val _isUnlocked = MutableStateFlow(false)
    val isUnlocked: StateFlow<Boolean> = _isUnlocked.asStateFlow()

    val isCensoringActive: StateFlow<Boolean> = combine(
        _isEnabled,
        _isUnlocked
    ) { enabled, unlocked ->
        enabled && !unlocked
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    init {
        viewModelScope.launch {
            _isEnabled.value = settingsRepository.getCurrentParentalControlEnabled()
        }
    }

    fun lock() {
        _isUnlocked.value = false
    }

    suspend fun verifyPinAndUnlock(pin: String): Boolean {
        val correctPin = settingsRepository.getCurrentParentalPin()
        val isCorrect = pin == correctPin
        if (isCorrect) {
            _isUnlocked.value = true
        }
        return isCorrect
    }

    fun setEnabled(enabled: Boolean, pinToSave: String) {
        viewModelScope.launch {
            settingsRepository.saveParentalControlSettings(enabled, pinToSave)
            _isEnabled.value = enabled
            if (!enabled) {
                _isUnlocked.value = true
            }
        }
    }

    fun changePin(newPin: String) {
        viewModelScope.launch {
            settingsRepository.saveParentalControlSettings(true, newPin)
        }
    }
}