package com.tararira.onlysports.viewmodel

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tararira.onlysports.data.model.UpdateInfo
import com.tararira.onlysports.data.remote.ApiService
import com.tararira.onlysports.util.UpdateHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed class UpdateState {
    object Idle : UpdateState()
    object Checking : UpdateState()
    data class UpdateAvailable(val info: UpdateInfo) : UpdateState()
    object NoUpdate : UpdateState()
    data class Downloading(val progress: Int) : UpdateState()
    data class DownloadComplete(val apkUri: Uri) : UpdateState()
    data class Error(val message: String) : UpdateState()
}

class UpdateViewModel(
    private val apiService: ApiService,
    private val applicationContext: Context
) : ViewModel() {

    private val _updateState = MutableStateFlow<UpdateState>(UpdateState.Idle)
    val updateState: StateFlow<UpdateState> = _updateState.asStateFlow()

    private val UPDATE_URL = "http://IP/update_info.json"

    fun checkForUpdates() {
        if (_updateState.value is UpdateState.Checking) return
        _updateState.value = UpdateState.Checking

        viewModelScope.launch {
            try {
                val updateInfo = apiService.getUpdateInfo(UPDATE_URL)

                @Suppress("DEPRECATION")
                val currentVersionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    applicationContext.packageManager.getPackageInfo(applicationContext.packageName, PackageManager.PackageInfoFlags.of(0)).longVersionCode.toInt()
                } else {
                    applicationContext.packageManager.getPackageInfo(applicationContext.packageName, 0).versionCode
                }

                if (updateInfo.isUpdateAvailable && updateInfo.latestVersionCode > currentVersionCode) {
                    _updateState.value = UpdateState.UpdateAvailable(updateInfo)
                } else {
                    _updateState.value = UpdateState.NoUpdate
                }
            } catch (e: Exception) {
                _updateState.value = UpdateState.Error("Error al verificar actualizaciones: ${e.message}")
            }
        }
    }

    fun startDownload(updateInfo: UpdateInfo) {
        val downloadId = UpdateHelper.startDownload(applicationContext, updateInfo.apkUrl, updateInfo.latestVersionName)
        if (downloadId != -1L) {
            monitorDownloadProgress(downloadId)
        } else {
            _updateState.value = UpdateState.Error("No se pudo iniciar la descarga.")
        }
    }

    private fun monitorDownloadProgress(downloadId: Long) {
        val downloadManager = applicationContext.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

        viewModelScope.launch(Dispatchers.IO) {
            var isDownloading = true
            while (isActive && isDownloading) {
                val query = DownloadManager.Query().setFilterById(downloadId)
                val cursor = downloadManager.query(query)

                if (cursor.moveToFirst()) {
                    val statusIndex = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS)
                    val status = cursor.getInt(statusIndex)

                    when (status) {
                        DownloadManager.STATUS_RUNNING -> {
                            val totalBytesIndex = cursor.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
                            val downloadedBytesIndex = cursor.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
                            val totalBytes = cursor.getLong(totalBytesIndex)
                            val downloadedBytes = cursor.getLong(downloadedBytesIndex)
                            val progress = if (totalBytes > 0) ((downloadedBytes * 100) / totalBytes).toInt() else 0

                            withContext(Dispatchers.Main) {
                                _updateState.value = UpdateState.Downloading(progress)
                            }
                        }
                        DownloadManager.STATUS_SUCCESSFUL -> {
                            isDownloading = false
                            val uri = downloadManager.getUriForDownloadedFile(downloadId)
                            withContext(Dispatchers.Main) {
                                if (uri != null) {
                                    _updateState.value = UpdateState.DownloadComplete(uri)
                                } else {
                                    _updateState.value = UpdateState.Error("Error al obtener URI del archivo.")
                                }
                            }
                        }
                        DownloadManager.STATUS_FAILED, DownloadManager.STATUS_PAUSED -> {
                            isDownloading = false
                            withContext(Dispatchers.Main) {
                                _updateState.value = UpdateState.Error("La descarga falló o se detuvo.")
                            }
                        }
                    }
                } else {
                    isDownloading = false
                }
                cursor.close()
                if(isDownloading) delay(500)
            }
        }
    }

    fun installUpdate(context: Context, apkUri: Uri) {
        try {
            val installIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(apkUri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(installIntent)
        } catch (e: Exception) {
            _updateState.value = UpdateState.Error("No se pudo iniciar el instalador.")
        }
    }

    fun dismissUpdate() {
        _updateState.value = UpdateState.NoUpdate
    }
}