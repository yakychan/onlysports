package com.tararira.onlysports.data.local

import android.content.Context
import android.util.Log
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import com.tararira.onlysports.AppPrefsDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.io.IOException

class SettingsRepository(context: Context) {

    private val dataStore: DataStore<Preferences> = context.AppPrefsDataStore
    private val logTag = "SettingsRepository"

    val epgUrlFlow: Flow<String> = dataStore.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { preferences -> preferences[PrefKeys.EPG_URL] ?: PrefKeys.DEFAULT_EPG_URL }

    val epgRefreshIntervalHoursFlow: Flow<Int> = dataStore.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { preferences -> preferences[PrefKeys.EPG_REFRESH_INTERVAL_HOURS] ?: PrefKeys.DEFAULT_EPG_REFRESH_INTERVAL_HOURS }

    suspend fun saveEpgSettings(url: String, intervalHours: Int) {
        val validInterval = if (intervalHours in PrefKeys.EPG_INTERVAL_OPTIONS) intervalHours else PrefKeys.DEFAULT_EPG_REFRESH_INTERVAL_HOURS
        try {
            dataStore.edit { preferences ->
                preferences[PrefKeys.EPG_URL] = url
                preferences[PrefKeys.EPG_REFRESH_INTERVAL_HOURS] = validInterval
            }
        } catch (e: Exception) { Log.e(logTag, "Error saving EPG settings", e) }
    }

    val parentalControlEnabledFlow: Flow<Boolean> = dataStore.data
        .map { preferences -> preferences[PrefKeys.PARENTAL_CONTROL_ENABLED] ?: false }

    val parentalPinFlow: Flow<String> = dataStore.data
        .map { preferences -> preferences[PrefKeys.PARENTAL_PIN] ?: PrefKeys.DEFAULT_PARENTAL_PIN }

    val subtitleTextColorFlow: Flow<Int> = dataStore.data
        .map { preferences -> preferences[PrefKeys.SUBTITLE_TEXT_COLOR] ?: PrefKeys.DEFAULT_SUBTITLE_TEXT_COLOR }

    val subtitleBackgroundColorFlow: Flow<Int> = dataStore.data
        .map { preferences -> preferences[PrefKeys.SUBTITLE_BACKGROUND_COLOR] ?: PrefKeys.DEFAULT_SUBTITLE_BACKGROUND_COLOR }

    val subtitleTextSizeFlow: Flow<Float> = dataStore.data
        .map { preferences -> preferences[PrefKeys.SUBTITLE_TEXT_SIZE] ?: PrefKeys.DEFAULT_SUBTITLE_TEXT_SIZE }

    suspend fun saveParentalControlSettings(enabled: Boolean, pin: String) {
        val validPin = pin.filter { it.isDigit() }.take(PrefKeys.MAX_PIN_LENGTH)
        if (enabled && validPin.length < PrefKeys.MIN_PIN_LENGTH) return

        dataStore.edit { preferences ->
            preferences[PrefKeys.PARENTAL_CONTROL_ENABLED] = enabled
            if(validPin.isNotEmpty()) preferences[PrefKeys.PARENTAL_PIN] = validPin
        }
    }

    suspend fun saveSubtitleSettings(textColor: Int, backgroundColor: Int, textSize: Float) {
        dataStore.edit { preferences ->
            preferences[PrefKeys.SUBTITLE_TEXT_COLOR] = textColor
            preferences[PrefKeys.SUBTITLE_BACKGROUND_COLOR] = backgroundColor
            preferences[PrefKeys.SUBTITLE_TEXT_SIZE] = textSize
        }
    }

    suspend fun getCurrentParentalControlEnabled(): Boolean = parentalControlEnabledFlow.first()
    suspend fun getCurrentParentalPin(): String = parentalPinFlow.first()
}