package com.tararira.onlysports.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tararira.onlysports.data.epg.model.EpgProgramme
import com.tararira.onlysports.data.model.ChannelSample
import com.tararira.onlysports.data.repository.ChannelRepository
import com.tararira.onlysports.player.PlayerManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.Duration
import java.time.OffsetDateTime
import java.time.ZoneId

data class PlayerUiState(
    val channelSamples: List<ChannelSample> = emptyList(),
    val isLoading: Boolean = true,
    val loadingError: String? = null,
    val fatalError: String? = null,
    val playbackError: String? = null,
    val currentEpgInfo: CurrentEpgInfo? = null,
    val videoResolution: String? = null
)

class PlayerViewModel(
    private val sharedNavViewModel: SharedNavViewModel,
    private val channelRepository: ChannelRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(PlayerUiState())
    val uiState: StateFlow<PlayerUiState> = _uiState.asStateFlow()

    private val rawEpgDataFlow: StateFlow<Map<String, List<EpgProgramme>>?> = channelRepository.epgDataFlow
    private var resolutionJob: Job? = null

    init {
        observeSharedChannelId()
    }

    private fun observeSharedChannelId() {
        viewModelScope.launch {
            sharedNavViewModel.selectedChannelId
                .filterNotNull()
                .distinctUntilChanged()
                .collectLatest { id ->
                    loadChannelDataAndEpg(id)
                }
        }
    }

    private fun loadChannelDataAndEpg(channelId: String) {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isLoading = true,
                    loadingError = null,
                    fatalError = null,
                    playbackError = null,
                    channelSamples = emptyList(),
                    currentEpgInfo = null,
                    videoResolution = null
                )
            }

            val samplesResult = channelRepository.getChannelsById(channelId)
            val currentEpg = calculateSingleCurrentEpgInfo(channelId, rawEpgDataFlow.value)

            if (samplesResult.isSuccess) {
                val samples = samplesResult.getOrThrow()
                if (samples.isNotEmpty()) {
                    _uiState.update {
                        it.copy(
                            channelSamples = samples,
                            isLoading = false,
                            currentEpgInfo = currentEpg
                        )
                    }
                } else {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            loadingError = "Canal '$channelId' no encontrado o sin fuentes.",
                            currentEpgInfo = currentEpg
                        )
                    }
                }
            } else {
                val error = samplesResult.exceptionOrNull()
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        loadingError = "Error al cargar datos: ${error?.message ?: "Desconocido"}",
                        currentEpgInfo = currentEpg
                    )
                }
            }
        }
    }

    fun updateVideoResolution(height: Int) {
        resolutionJob?.cancel()
        resolutionJob = viewModelScope.launch {
            val resolutionText = if (height > 0) "${height}p" else null
            _uiState.update { it.copy(videoResolution = resolutionText) }
            if (resolutionText != null) {
                delay(4000)
                if (_uiState.value.videoResolution == resolutionText) {
                    _uiState.update { it.copy(videoResolution = null) }
                }
            }
        }
    }

    private fun calculateSingleCurrentEpgInfo(
        channelId: String?,
        rawEpg: Map<String, List<EpgProgramme>>?
    ): CurrentEpgInfo? {
        if (channelId == null || rawEpg == null) return null
        val programsForChannel = rawEpg[channelId]?.sortedBy { it.start } ?: return null
        val now = OffsetDateTime.now(ZoneId.systemDefault())
        val currentProgram = programsForChannel.find { it.isAiringAt(now) }
        var progress: Float? = null
        var nextProgram: EpgProgramme? = null
        if (currentProgram != null) {
            try {
                val totalDuration = Duration.between(currentProgram.start, currentProgram.stop)
                val elapsedDuration = Duration.between(currentProgram.start, now)
                if (!totalDuration.isZero && !totalDuration.isNegative && !elapsedDuration.isNegative) {
                    progress = (elapsedDuration.toMillis().toFloat() / totalDuration.toMillis().toFloat()).coerceIn(0.0f, 1.0f)
                }
            } catch (e: Exception) { progress = null }
            val currentIndex = programsForChannel.indexOf(currentProgram)
            if (currentIndex != -1 && currentIndex + 1 < programsForChannel.size) {
                nextProgram = programsForChannel[currentIndex + 1]
            }
        } else {
            nextProgram = programsForChannel.firstOrNull { !it.start.isBefore(now) }
        }
        return CurrentEpgInfo(currentProgram, progress, nextProgram)
    }

    fun setPlaybackError(errorMessage: String?) {
        _uiState.update { it.copy(playbackError = errorMessage) }
    }

    fun setFatalError(errorMessage: String?) {
        _uiState.update { it.copy(fatalError = errorMessage, isLoading = false, playbackError = null) }
    }
}