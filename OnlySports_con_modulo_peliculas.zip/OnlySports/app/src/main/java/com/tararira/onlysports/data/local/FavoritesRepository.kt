package com.tararira.onlysports.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import com.tararira.onlysports.AppPrefsDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class FavoritesRepository(context: Context) {

    private val dataStore: DataStore<Preferences> = context.AppPrefsDataStore

    companion object {
        private val FAVORITE_CHANNEL_IDS = stringSetPreferencesKey("favorite_channel_ids")
        private val json = Json { prettyPrint = true }
    }

    val favoriteChannelIdsFlow: Flow<Set<String>> = dataStore.data
        .map { preferences ->
            preferences[FAVORITE_CHANNEL_IDS] ?: emptySet()
        }

    suspend fun addFavorite(channelId: String) {
        dataStore.edit { preferences ->
            val currentFavorites = preferences[FAVORITE_CHANNEL_IDS] ?: emptySet()
            preferences[FAVORITE_CHANNEL_IDS] = currentFavorites + channelId
        }
    }

    suspend fun removeFavorite(channelId: String) {
        dataStore.edit { preferences ->
            val currentFavorites = preferences[FAVORITE_CHANNEL_IDS] ?: emptySet()
            preferences[FAVORITE_CHANNEL_IDS] = currentFavorites - channelId
        }
    }

    suspend fun toggleFavorite(channelId: String) {
        dataStore.edit { preferences ->
            val currentFavorites = preferences[FAVORITE_CHANNEL_IDS] ?: emptySet()
            if (currentFavorites.contains(channelId)) {
                preferences[FAVORITE_CHANNEL_IDS] = currentFavorites - channelId
            } else {
                preferences[FAVORITE_CHANNEL_IDS] = currentFavorites + channelId
            }
        }
    }

    suspend fun exportFavoritesToJson(): String {
        val favorites = favoriteChannelIdsFlow.first()
        return json.encodeToString(favorites)
    }

    suspend fun importFavoritesFromJson(jsonString: String): Result<Unit> {
        return try {
            val newFavorites: Set<String> = Json.decodeFromString(jsonString)
            dataStore.edit { preferences ->
                preferences[FAVORITE_CHANNEL_IDS] = newFavorites
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}