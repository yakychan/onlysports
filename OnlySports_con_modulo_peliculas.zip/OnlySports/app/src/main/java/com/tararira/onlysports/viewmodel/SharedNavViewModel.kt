package com.tararira.onlysports.viewmodel

import androidx.lifecycle.ViewModel
import com.tararira.onlysports.data.model.MovieSample
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

class SharedNavViewModel : ViewModel() {

    private val _selectedChannelId = MutableStateFlow<String?>(null)
    val selectedChannelId = _selectedChannelId.asStateFlow()

    private val _currentChannelIdList = MutableStateFlow<List<String>>(emptyList())
    val currentChannelIdList = _currentChannelIdList.asStateFlow()

    private val _lastPlayedChannelId = MutableStateFlow<String?>(null)

    private val _channelToFocusAfterReturnInList = MutableStateFlow<String?>(null)
    val channelToFocusAfterReturnInList = _channelToFocusAfterReturnInList.asStateFlow()

    private val _selectedMovie = MutableStateFlow<MovieSample?>(null)
    val selectedMovie = _selectedMovie.asStateFlow()

    fun selectChannel(channelId: String?) {
        _selectedChannelId.value = channelId
        if (channelId != null) {
            _lastPlayedChannelId.value = channelId
        }
    }

    fun selectMovie(movie: MovieSample) {
        _selectedMovie.value = movie
    }

    fun updateChannelIdList(ids: List<String>) {
        _currentChannelIdList.value = ids
    }

    fun requestFocusOnLastPlayedChannelInList() {
        _channelToFocusAfterReturnInList.value = _lastPlayedChannelId.value
    }

    fun consumeFocusRequestForList() {
        _channelToFocusAfterReturnInList.value = null
    }
}