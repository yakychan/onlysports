package com.tararira.onlysports.util

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.util.Log
import android.widget.Toast
import java.io.File

object UpdateHelper {

    fun startDownload(context: Context, apkUrl: String, versionName: String): Long {
        val logTag = "UpdateHelper"
        try {
            val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val fileName = "OnlySports_v${versionName}.apk"

            val destinationDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            if (destinationDir == null) {
                Toast.makeText(context, "No se puede acceder al almacenamiento externo.", Toast.LENGTH_LONG).show()
                return -1L
            }

            if (!destinationDir.exists()) {
                destinationDir.mkdirs()
            }

            val destinationFile = File(destinationDir, fileName)
            if (destinationFile.exists()) {
                destinationFile.delete()
            }

            val request = DownloadManager.Request(Uri.parse(apkUrl))
                .setTitle("Descargando Actualización")
                .setDescription(fileName)
                .setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, fileName)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setMimeType("application/vnd.android.package-archive")
                .setAllowedOverMetered(true)

            val downloadId = downloadManager.enqueue(request)
            Log.d(logTag, "Download enqueued with ID: $downloadId")
            return downloadId
        } catch (e: Exception) {
            Log.e(logTag, "Error initiating download.", e)
            Toast.makeText(context, "Error al iniciar descarga: ${e.message}", Toast.LENGTH_LONG).show()
            return -1L
        }
    }
}