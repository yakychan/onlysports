package com.tararira.onlysports.navigation

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.tararira.onlysports.auth.AuthManager
import com.tararira.onlysports.data.local.FavoritesRepository
import com.tararira.onlysports.data.local.SettingsRepository
import com.tararira.onlysports.data.remote.RetrofitClient
import com.tararira.onlysports.data.repository.ChannelRepository
import com.tararira.onlysports.data.repository.UserRepository
import com.tararira.onlysports.ui.screens.ChannelDiagnosticsScreen
import com.tararira.onlysports.ui.screens.ChannelListScreen
import com.tararira.onlysports.ui.screens.CodeEntryScreen
import com.tararira.onlysports.ui.screens.FavoritesScreen
import com.tararira.onlysports.ui.screens.MainScreen
import com.tararira.onlysports.ui.screens.MoviePlayerScreen
import com.tararira.onlysports.ui.screens.MoviesScreen
import com.tararira.onlysports.ui.screens.ParentalPinEntryScreen
import com.tararira.onlysports.ui.screens.PlayerScreen
import com.tararira.onlysports.ui.screens.SettingsScreen
import com.tararira.onlysports.ui.screens.SplashScreen
import com.tararira.onlysports.viewmodel.ChannelDiagnosticsViewModel
import com.tararira.onlysports.viewmodel.ChannelViewModel
import com.tararira.onlysports.viewmodel.FavoritesViewModel
import com.tararira.onlysports.viewmodel.InitialAuthViewModel
import com.tararira.onlysports.viewmodel.MoviePlayerViewModel
import com.tararira.onlysports.viewmodel.MoviesViewModel
import com.tararira.onlysports.viewmodel.ParentalControlViewModel
import com.tararira.onlysports.viewmodel.PlayerViewModel
import com.tararira.onlysports.viewmodel.SettingsViewModel
import com.tararira.onlysports.viewmodel.SharedNavViewModel
import kotlinx.coroutines.delay

class ParentalControlViewModelFactory(private val sr: SettingsRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ParentalControlViewModel::class.java)) {
            return ParentalControlViewModel(sr) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

class SettingsViewModelFactory(
    private val sr: SettingsRepository,
    private val fr: FavoritesRepository,
    private val context: Context
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(SettingsViewModel::class.java)) {
            return SettingsViewModel(sr, fr, context) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

class MoviesViewModelFactory(private val cr: ChannelRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MoviesViewModel::class.java)) {
            return MoviesViewModel(cr) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

class MoviePlayerViewModelFactory(
    private val snvm: SharedNavViewModel
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MoviePlayerViewModel::class.java)) {
            return MoviePlayerViewModel(snvm) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

@Composable
fun AppNavigation(
    navController: NavHostController,
    isPhone: Boolean
) {
    val context = LocalContext.current.applicationContext

    val settingsRepository = remember { SettingsRepository(context) }
    val channelRepository = remember { ChannelRepository(context, RetrofitClient.apiService) }
    val authManager = remember { AuthManager(context) }
    val userRepository = remember { UserRepository(RetrofitClient.apiService) }

    val sharedNavViewModel: SharedNavViewModel = viewModel()
    val parentalControlViewModel: ParentalControlViewModel = viewModel(factory = ParentalControlViewModelFactory(settingsRepository))

    val initialAuthViewModel: InitialAuthViewModel = viewModel(
        factory = InitialAuthViewModelFactory(authManager, userRepository)
    )

    val authValidationState by initialAuthViewModel.authState.collectAsStateWithLifecycle()
    var showSplashScreenVisual by remember { mutableStateOf(true) }

    LaunchedEffect(key1 = Unit) {
        delay(1000)
        showSplashScreenVisual = false
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) {
                parentalControlViewModel.lock()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    if (showSplashScreenVisual) {
        SplashScreen()
    } else {
        when (authValidationState) {
            is InitialAuthViewModel.AuthState.Loading -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
            is InitialAuthViewModel.AuthState.Authenticated -> {
                NavHost(navController = navController, startDestination = Screen.Main.route) {
                    addAppScreens(navController, context, settingsRepository, channelRepository, sharedNavViewModel, parentalControlViewModel)
                }
            }
            else -> {
                NavHost(navController = navController, startDestination = Screen.Main.route) {
                    addAppScreens(navController, context, settingsRepository, channelRepository, sharedNavViewModel, parentalControlViewModel)
                }
            }
        }
    }
}


private fun NavGraphBuilder.addAppScreens(
    navController: NavHostController,
    context: Context,
    settingsRepository: SettingsRepository,
    channelRepository: ChannelRepository,
    sharedNavViewModel: SharedNavViewModel,
    parentalControlViewModel: ParentalControlViewModel
) {
    composable(Screen.Main.route) {
        MainScreen(
            onNavigateToChannels = { navController.navigate(Screen.ChannelList.route) },
            onNavigateToMovies = { navController.navigate(Screen.Movies.route) },
            onNavigateToFavorites = { navController.navigate(Screen.Favorites.route) },
            onNavigateToSettings = { navController.navigate(Screen.Settings.route) }
        )
    }

    composable(Screen.ChannelList.route) {
        val favoritesRepository = remember { FavoritesRepository(context) }
        val viewModel: ChannelViewModel = viewModel(factory = ChannelViewModelFactory(channelRepository, favoritesRepository, parentalControlViewModel))
        val uiState by viewModel.uiState.collectAsStateWithLifecycle()
        val uniqueIds by viewModel.uniqueOrderedChannelIds.collectAsStateWithLifecycle()

        ChannelListScreen(
            uiState = uiState,
            sharedViewModel = sharedNavViewModel,
            onChannelClick = { channel ->
                val channelId = channel.channelId
                if (!channelId.isNullOrBlank()) {
                    sharedNavViewModel.updateChannelIdList(uniqueIds)
                    sharedNavViewModel.selectChannel(channelId)
                    navController.navigate(Screen.Player.createRoute(channelId))
                } else {
                    Toast.makeText(context, "ID de canal inválido.", Toast.LENGTH_SHORT).show()
                }
            },
            onFavoriteClick = { id -> viewModel.toggleFavorite(id) },
            onBackPressed = { navController.popBackStack() }
        )
    }

    composable(Screen.Movies.route) {
        val moviesViewModel: MoviesViewModel = viewModel(factory = MoviesViewModelFactory(channelRepository))
        val uiState by moviesViewModel.uiState.collectAsStateWithLifecycle()
        MoviesScreen(
            uiState = uiState,
            sharedViewModel = sharedNavViewModel,
            onMovieClick = {
                navController.navigate(Screen.MoviePlayer.route)
            },
            onBackPressed = { navController.popBackStack() }
        )
    }

    composable(Screen.MoviePlayer.route) {
        val moviePlayerViewModel: MoviePlayerViewModel = viewModel(
            factory = MoviePlayerViewModelFactory(sharedNavViewModel)
        )
        MoviePlayerScreen(
            viewModel = moviePlayerViewModel,
            onBackPressed = { navController.popBackStack() }
        )
    }

    composable(Screen.Favorites.route) {
        val favoritesRepository = remember { FavoritesRepository(context) }
        val viewModel: FavoritesViewModel = viewModel(factory = FavoritesViewModelFactory(channelRepository, favoritesRepository, parentalControlViewModel))
        val uiState by viewModel.uiState.collectAsStateWithLifecycle()
        val favoriteIds = remember(uiState.favoriteChannels) {
            uiState.favoriteChannels.mapNotNull { it.channelId }
        }

        FavoritesScreen(
            uiState = uiState,
            onChannelClick = { channel ->
                val channelId = channel.channelId
                if (!channelId.isNullOrBlank()) {
                    sharedNavViewModel.updateChannelIdList(favoriteIds)
                    sharedNavViewModel.selectChannel(channelId)
                    navController.navigate(Screen.Player.createRoute(channelId))
                } else {
                    Toast.makeText(context, "ID de canal inválido.", Toast.LENGTH_SHORT).show()
                }
            },
            onRemoveFavoriteClick = { id -> viewModel.removeFromFavorites(id) },
            onBackPressed = { navController.popBackStack() }
        )
    }

    composable(Screen.Settings.route) {
        val favoritesRepository = remember { FavoritesRepository(context) }
        val settingsViewModel: SettingsViewModel = viewModel(
            factory = SettingsViewModelFactory(settingsRepository, favoritesRepository, context)
        )
        SettingsScreen(
            settingsViewModel = settingsViewModel,
            parentalControlViewModel = parentalControlViewModel,
            onNavigateToDiagnostics = { navController.navigate(Screen.CodeEntry.route) },
            onBackPressed = { navController.popBackStack() }
        )
    }

    composable(Screen.CodeEntry.route) {
        val diagnosticsViewModel: ChannelDiagnosticsViewModel = viewModel(factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = ChannelDiagnosticsViewModel(channelRepository) as T
        })
        CodeEntryScreen(
            correctCode = diagnosticsViewModel.secretCode,
            onCodeVerified = {
                navController.navigate(Screen.ChannelDiagnostics.route) {
                    popUpTo(Screen.CodeEntry.route) { inclusive = true }
                }
            },
            onCancel = { navController.popBackStack() }
        )
    }

    composable(Screen.ChannelDiagnostics.route) {
        val diagnosticsViewModel: ChannelDiagnosticsViewModel = viewModel(factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = ChannelDiagnosticsViewModel(channelRepository) as T
        })
        ChannelDiagnosticsScreen(
            viewModel = diagnosticsViewModel,
            onBackPressed = { navController.popBackStack() }
        )
    }

    composable(
        route = Screen.ParentalPinEntry.route,
        arguments = listOf(navArgument("channelIdToPlay") { type = NavType.StringType })
    ) { backStackEntry ->
        val channelId = backStackEntry.arguments?.getString("channelIdToPlay")
        if (channelId != null) {
            ParentalPinEntryScreen(
                channelIdToPlay = channelId,
                parentalControlViewModel = parentalControlViewModel,
                onPinVerified = { verifiedChannelId ->
                    sharedNavViewModel.selectChannel(verifiedChannelId)
                    navController.navigate(Screen.Player.createRoute(verifiedChannelId)) {
                        popUpTo(Screen.ParentalPinEntry.route) { inclusive = true }
                    }
                },
                onCancel = { navController.popBackStack() }
            )
        } else {
            Toast.makeText(context, "Error: ID de canal no encontrado para PIN.", Toast.LENGTH_LONG).show()
            navController.popBackStack()
        }
    }

    composable(
        route = Screen.Player.route,
        arguments = listOf(navArgument("channelId") { type = NavType.StringType })
    ) {
        val playerViewModel: PlayerViewModel = viewModel(
            factory = PlayerViewModelSimpleFactory(sharedNavViewModel, channelRepository)
        )
        val uiState by playerViewModel.uiState.collectAsStateWithLifecycle()

        PlayerScreen(
            uiState = uiState,
            sharedViewModel = sharedNavViewModel,
            viewModel = playerViewModel,
            onPlaybackError = { playerViewModel.setPlaybackError(it) },
            onFatalError = { error -> playerViewModel.setFatalError(error ?: "Error fatal desconocido") },
            onBackPressed = {
                navController.popBackStack()
            }
        )
    }
}

class InitialAuthViewModelFactory(
    private val authManager: AuthManager,
    private val userRepository: UserRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(InitialAuthViewModel::class.java)) {
            return InitialAuthViewModel(authManager, userRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class for InitialAuthViewModelFactory: ${modelClass.name}")
    }
}

class PlayerViewModelSimpleFactory(private val snvm:SharedNavViewModel,private val cr:ChannelRepository):ViewModelProvider.Factory{@Suppress("UNCHECKED_CAST")override fun <T:ViewModel> create(c:Class<T>):T{if(c.isAssignableFrom(PlayerViewModel::class.java))return PlayerViewModel(snvm,cr)as T;throw IllegalArgumentException("Unknown VM class for PlayerViewModel: ${c.name}")}}
class ChannelViewModelFactory(private val cr:ChannelRepository,private val fr:FavoritesRepository, private val pcVM: ParentalControlViewModel):ViewModelProvider.Factory{@Suppress("UNCHECKED_CAST")override fun <T:ViewModel> create(modelClass: Class<T>):T{if(modelClass.isAssignableFrom(ChannelViewModel::class.java))return ChannelViewModel(cr,fr,pcVM)as T;throw IllegalArgumentException("Unknown VM class for ChannelViewModel: ${modelClass.name}")}}
class FavoritesViewModelFactory(private val cr:ChannelRepository,private val fr:FavoritesRepository, private val pcVM: ParentalControlViewModel):ViewModelProvider.Factory{@Suppress("UNCHECKED_CAST")override fun <T:ViewModel> create(modelClass: Class<T>):T{if(modelClass.isAssignableFrom(FavoritesViewModel::class.java))return FavoritesViewModel(cr,fr,pcVM)as T;throw IllegalArgumentException("Unknown VM class for FavoritesViewModel: ${modelClass.name}")}}