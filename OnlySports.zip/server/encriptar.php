<?php
// ****** ACTIVAR ERRORES PARA DEBUG ******
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// ****** FIN ACTIVAR ERRORES ******

// --- CONFIGURACIÓN DE ENCRIPTACIÓN (¡IDÉNTICA A user.php y Android!) ---
define('AES_KEY', 'ACAVALACLAVEAESIGUALQUEENLAAPP'); // La misma clave
define('AES_IV', 'ACAVALASEGUNDACLAVEIGUALQUEENLAAPP');                 // El mismo IV
define('AES_METHOD', 'aes-256-cbc');             // El mismo método
// -----------------------------------------------------------------------

$inputFile = './lista.json'; // Tu JSON original en texto plano
$outputFile = './lista_encriptada.json'; // Nombre para el archivo encriptado

// --- Función de Encriptación (solo necesitamos esta) ---
function encryptData($data) {
    $jsonString = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($jsonString === false) throw new Exception("Error JSON Encode: " . json_last_error_msg());
    $encrypted = openssl_encrypt($jsonString, AES_METHOD, AES_KEY, OPENSSL_RAW_DATA, AES_IV);
    if ($encrypted === false) throw new Exception("Error OpenSSL Encrypt: " . openssl_error_string());
    return base64_encode($encrypted);
}
// --- Fin Función ---

echo "<h1>Encriptador de $inputFile</h1>";

if (!file_exists($inputFile) || !is_readable($inputFile)) {
    die("<p style='color:red;'>Error: No se puede leer el archivo de entrada '$inputFile'.</p>");
}

$plainJsonContent = file_get_contents($inputFile);
if ($plainJsonContent === false) {
     die("<p style='color:red;'>Error: Fallo al leer el contenido de '$inputFile'.</p>");
}

$plainData = json_decode($plainJsonContent, true);
if (json_last_error() !== JSON_ERROR_NONE) {
     die("<p style='color:red;'>Error: El contenido de '$inputFile' no es JSON válido: " . json_last_error_msg() . "</p>");
}
 if (!is_array($plainData)) {
     die("<p style='color:red;'>Error: El JSON en '$inputFile' no contiene un array principal.</p>");
}

echo "<p>Contenido JSON leído correctamente desde '$inputFile'.</p>";

try {
    echo "<p>Intentando encriptar los datos...</p>";
    $encryptedBase64 = encryptData($plainData);
    echo "<p>Encriptación completada. Intentando guardar en '$outputFile'...</p>";

    if (file_put_contents($outputFile, $encryptedBase64, LOCK_EX) !== false) {
        echo "<p style='color:green; font-weight:bold;'>¡ÉXITO! Datos encriptados guardados en '$outputFile'.</p>";
        echo "<p>Ahora puedes renombrar '$outputFile' a '$inputFile' si estás listo para reemplazar el original.</p>";
        echo "<textarea rows='10' cols='80' readonly>" . htmlspecialchars($encryptedBase64) . "</textarea>";
    } else {
         echo "<p style='color:red;'>Error: No se pudo escribir en el archivo de salida '$outputFile'. Verifica los permisos.</p>";
    }

} catch (Exception $e) {
    echo "<p style='color:red;'>Error durante la encriptación/guardado: " . htmlspecialchars($e->getMessage()) . "</p>";
}

?>
