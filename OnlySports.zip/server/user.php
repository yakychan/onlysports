<?php
session_start(); // Iniciar sesión para recordar el login del panel

// --- CONFIGURACIÓN ---
define('JSON_FILE_PATH', './users.json'); // Ruta al archivo JSON (misma carpeta por defecto) - AJUSTA SI ES NECESARIO
define('PANEL_PASSWORD', 'claveparaelpanel#'); // ¡CAMBIAR ESTO Y PROTEGERLO MEJOR!

// --- Clave AES y IV (¡DEBEN SER IDÉNTICAS A LAS DE ANDROID!) ---
define('AES_KEY', 'ACAVALACLAVEAESIGUALQUEENLAAPP'); // ¡CAMBIAR ESTO! (16, 24 o 32 bytes)
define('AES_IV', 'ACAVALASEGUNDACLAVEIGUALQUEENLAAPP');      // ¡CAMBIAR ESTO! (Usualmente 16 bytes para CBC/GCM)
define('AES_METHOD', 'aes-256-cbc'); // ¡DEBE COINCIDIR CON ANDROID! (Ej: aes-128-cbc, aes-256-gcm)
// Nota: PKCS5Padding/PKCS7Padding es a menudo el predeterminado para CBC en PHP openssl.
// --- FIN CONFIGURACIÓN ---


// ------ LÓGICA PARA SERVIR EL JSON ENCRIPTADO ------
if (isset($_GET['get']) && $_GET['get'] === 'json') {
    // Cambiar el Content-Type para indicar que es texto (o application/octet-stream si prefieres)
    header('Content-Type: text/plain; charset=utf-8');

    if (!file_exists(JSON_FILE_PATH)) {
        http_response_code(404); // Not Found
        // Devolver un JSON vacío encriptado podría ser más robusto para el cliente
        // que simplemente un error de texto. Encriptamos `{"users":[]}`
        try {
            // Estructura vacía
            $emptyData = ['users' => []];
            // Encriptar y codificar
            $jsonString = json_encode($emptyData);
            $encrypted = openssl_encrypt($jsonString, AES_METHOD, AES_KEY, OPENSSL_RAW_DATA, AES_IV);
            if ($encrypted !== false) {
                echo base64_encode($encrypted);
            } else {
                 // Si falla la encriptación del vacío (raro), devolver error.
                 http_response_code(500);
                 echo "Error: No se pudo encriptar la estructura vacía.";
            }
        } catch (Exception $e) {
             http_response_code(500);
             echo "Error: Excepción al procesar estructura vacía.";
        }
    } else {
        // Leer el contenido existente (ya encriptado y en base64)
        $base64EncryptedData = file_get_contents(JSON_FILE_PATH);
        if ($base64EncryptedData === false) {
            http_response_code(500); // Internal Server Error
            echo "Error: No se pudo leer el archivo de usuarios.";
        } else {
            // Simplemente devolver el contenido crudo
            echo $base64EncryptedData;
        }
    }
    exit; // MUY IMPORTANTE: Terminar el script aquí para no imprimir el HTML
}
// ------ FIN LÓGICA PARA SERVIR JSON ------


// --- Funciones de Cifrado/Descifrado ---
// (Estas son usadas por el *panel*, no por la lógica ?get=json de arriba)
function encryptData($data) {
    $jsonString = json_encode($data, JSON_PRETTY_PRINT);
    if ($jsonString === false) {
        throw new Exception("Error codificando datos a JSON: " . json_last_error_msg());
    }
    $encrypted = openssl_encrypt($jsonString, AES_METHOD, AES_KEY, OPENSSL_RAW_DATA, AES_IV);
    if ($encrypted === false) {
        throw new Exception("Error de encriptación OpenSSL: " . openssl_error_string());
    }
    return base64_encode($encrypted);
}

function decryptData($base64EncryptedData) {
    $encrypted = base64_decode($base64EncryptedData);
    if ($encrypted === false) {
        throw new Exception("Error decodificando Base64.");
    }
    // Intentar desencriptar
    $decryptedJson = openssl_decrypt($encrypted, AES_METHOD, AES_KEY, OPENSSL_RAW_DATA, AES_IV);
     if ($decryptedJson === false) {
        // Intentar sin OPENSSL_RAW_DATA como fallback (menos probable que funcione si se usó al encriptar)
         $decryptedJson = openssl_decrypt($encrypted, AES_METHOD, AES_KEY, 0, AES_IV);
         if ($decryptedJson === false) {
             throw new Exception("Error de desencriptación OpenSSL: " . openssl_error_string());
         }
    }
    $data = json_decode($decryptedJson, true); // true para array asociativo
    if ($data === null && json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception("Error decodificando JSON desencriptado: " . json_last_error_msg() . ". ¿Clave/IV/Método correctos o archivo corrupto?");
    }
    // Asegurar estructura base si el JSON estaba mal formado o vacío
    if (!isset($data['users']) || !is_array($data['users'])) {
        $data = ['users' => []];
    }
    return $data;
}


// --- Funciones de Lectura/Escritura del Archivo ---
function loadUserData() {
    if (!file_exists(JSON_FILE_PATH)) {
        return ['users' => []];
    }
    $base64EncryptedData = file_get_contents(JSON_FILE_PATH);
    if ($base64EncryptedData === false) {
        throw new Exception("No se pudo leer el archivo JSON: " . JSON_FILE_PATH);
    }
    // Si el archivo está vacío, retornar estructura vacía
    if (empty(trim($base64EncryptedData))) {
         return ['users' => []];
    }
    // Intentar desencriptar
    try {
        return decryptData($base64EncryptedData);
    } catch (Exception $e) {
        // Si falla la desencriptación (clave mal, corrupto), lanzar excepción clara
        error_log("Error al cargar/desencriptar " . JSON_FILE_PATH . ": " . $e->getMessage()); // Loggear el error
        throw new Exception("Error crítico al procesar el archivo de usuarios. Verifique la configuración de cifrado o el archivo. Detalles: " . $e->getMessage());
    }
}

function saveUserData($data) {
    // Validar que $data tiene la estructura esperada antes de encriptar
    if (!isset($data['users']) || !is_array($data['users'])) {
         throw new Exception("Formato de datos inválido para guardar.");
    }
    try {
        $base64EncryptedData = encryptData($data);
        // Usar bloqueo exclusivo para escritura segura
        if (file_put_contents(JSON_FILE_PATH, $base64EncryptedData, LOCK_EX) === false) {
            throw new Exception("No se pudo escribir en el archivo JSON: " . JSON_FILE_PATH);
        }
    } catch (Exception $e) {
        error_log("Error al guardar datos de usuario en " . JSON_FILE_PATH . ": " . $e->getMessage()); // Loggear el error
        throw new Exception("Error al guardar datos de usuario: " . $e->getMessage());
    }
}


// --- Lógica de Autenticación del Panel ---
$isPanelAuthenticated = isset($_SESSION['panel_logged_in']) && $_SESSION['panel_logged_in'] === true;
$loginError = '';
$actionMessage = ''; // Mensajes de estado para el usuario del panel

// --- Procesamiento de Formularios POST (SOLO PARA EL PANEL HTML) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // --- Intento de Login al panel ---
    if (isset($_POST['login_password'])) {
        if (hash_equals(PANEL_PASSWORD, $_POST['login_password'])) { // Usar hash_equals para comparación segura
            $_SESSION['panel_logged_in'] = true;
            $isPanelAuthenticated = true;
            header("Location: " . $_SERVER['PHP_SELF']); // Redirigir para limpiar POST
            exit;
        } else {
            $loginError = "Contraseña del panel incorrecta.";
        }
    }
    // --- Logout del panel ---
    elseif (isset($_POST['logout']) && $isPanelAuthenticated) { // Asegurar que esté autenticado para logout
        session_unset();
        session_destroy();
        $isPanelAuthenticated = false;
        header("Location: " . $_SERVER['PHP_SELF']); // Redirigir
        exit;
    }
    // --- Acciones CRUD (solo si está autenticado en el panel) ---
    elseif ($isPanelAuthenticated && isset($_POST['action'])) {
        // Intentar cargar datos existentes, manejar error si falla
        try {
            $userData = loadUserData(); // Carga y desencripta
            $users = $userData['users']; // Obtiene el array de usuarios
        } catch (Exception $e) {
             $actionMessage = "Error al cargar datos existentes: " . $e->getMessage();
             // Resetear $users para evitar más errores si la carga falló
             $users = [];
             // Forzar logout del panel si no se pueden cargar los datos? Podría ser una opción.
             // session_unset(); session_destroy(); $isPanelAuthenticated = false;
        }

        // Solo proceder con acciones si no hubo error al cargar
        if (empty($actionMessage)) {
            try {
                switch ($_POST['action']) {
                    case 'add_user':
                        $username = trim($_POST['username'] ?? '');
                        $password = $_POST['password'] ?? '';

                        if (empty($username) || empty($password)) {
                           throw new Exception("Usuario y contraseña son requeridos.");
                        }
                        if (strlen($username) > 50) { // Limitar longitud
                             throw new Exception("Nombre de usuario demasiado largo (máx 50).");
                        }

                        $userExists = false;
                        foreach ($users as $user) {
                            if (strcasecmp($user['username'], $username) === 0) {
                                $userExists = true;
                                break;
                            }
                        }
                        if ($userExists) {
                            throw new Exception("El nombre de usuario '$username' ya existe.");
                        }

                        $passwordHash = password_hash($password, PASSWORD_DEFAULT);
                        if ($passwordHash === false) {
                             throw new Exception("Error al generar el hash de la contraseña.");
                        }

                        $users[] = ['username' => $username, 'passwordHash' => $passwordHash];
                        $userData['users'] = $users; // Actualizar el contenedor
                        saveUserData($userData); // Guarda y re-encripta
                        $actionMessage = "Usuario '$username' añadido correctamente.";
                        break;

                    case 'delete_user':
                        $usernameToDelete = $_POST['username'] ?? '';
                         if (empty($usernameToDelete)) {
                           throw new Exception("Nombre de usuario a eliminar no especificado.");
                        }

                        $initialCount = count($users);
                        $users = array_filter($users, function($user) use ($usernameToDelete) {
                            return strcasecmp($user['username'], $usernameToDelete) !== 0;
                        });

                        if (count($users) === $initialCount) {
                             throw new Exception("Usuario '$usernameToDelete' no encontrado para eliminar.");
                        }

                        $users = array_values($users); // Reindexar
                        $userData['users'] = $users;
                        saveUserData($userData);
                        $actionMessage = "Usuario '$usernameToDelete' eliminado correctamente.";
                        break;

                     case 'change_password':
                        $usernameToChange = trim($_POST['username'] ?? '');
                        $newPassword = $_POST['new_password'] ?? '';

                        if (empty($usernameToChange) || empty($newPassword)) {
                           throw new Exception("Usuario y nueva contraseña son requeridos.");
                        }

                        $userIndex = -1;
                        foreach ($users as $index => $user) {
                             if (strcasecmp($user['username'], $usernameToChange) === 0) {
                                $userIndex = $index;
                                break;
                            }
                        }

                        if ($userIndex === -1) {
                             throw new Exception("Usuario '$usernameToChange' no encontrado para cambiar contraseña.");
                        }

                        $newPasswordHash = password_hash($newPassword, PASSWORD_DEFAULT);
                        if ($newPasswordHash === false) {
                             throw new Exception("Error al generar el hash de la nueva contraseña.");
                        }

                        $users[$userIndex]['passwordHash'] = $newPasswordHash;
                        $userData['users'] = $users;
                        saveUserData($userData);
                        $actionMessage = "Contraseña para '$usernameToChange' cambiada correctamente.";
                        break;

                    default:
                         $actionMessage = "Acción desconocida.";
                         break;
                }
                 // Recargar datos después de la acción exitosa (opcional, bueno para refrescar)
                 // $userData = loadUserData();
                 // $displayUsers = $userData['users'];
                 // usort($displayUsers, fn($a, $b) => strcasecmp($a['username'], $b['username']));

            } catch (Exception $e) {
                $actionMessage = "Error procesando acción: " . $e->getMessage();
            }
        } // fin if (empty($actionMessage))
    } // fin elseif ($isPanelAuthenticated && isset($_POST['action']))
} // fin if ($_SERVER['REQUEST_METHOD'] === 'POST')

// --- Cargar datos para mostrar en el panel (si está autenticado) ---
$displayUsers = [];
if ($isPanelAuthenticated) {
    try {
        $userData = loadUserData(); // Carga y desencripta
        $displayUsers = $userData['users'];
        // Ordenar alfabéticamente para mostrar
        usort($displayUsers, function($a, $b) {
            return strcasecmp($a['username'], $b['username']);
        });
    } catch (Exception $e) {
        // Mostrar error persistente si la carga inicial falla
        $actionMessage = "ERROR AL CARGAR DATOS: " . $e->getMessage() . " - No se pueden mostrar ni modificar usuarios.";
    }
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Control de Usuarios</title>
    <style>
        /* Estilos (sin cambios respecto al anterior) */
        body { font-family: sans-serif; line-height: 1.6; padding: 20px; background-color: #f4f4f4; color: #333; }
        .container { max-width: 800px; margin: auto; background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h1, h2, h3 { color: #333; border-bottom: 1px solid #eee; padding-bottom: 10px; margin-top: 25px; margin-bottom: 15px; }
        h1 { margin-top: 0; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input[type="text"], input[type="password"] { width: 95%; padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px; max-width: 300px; }
        button { background-color: #5cb85c; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; font-size: 1em; margin-right: 5px; }
        button:hover { background-color: #4cae4c; }
        button.delete { background-color: #d9534f; }
        button.delete:hover { background-color: #c9302c; }
        button.logout { background-color: #f0ad4e; float: right; margin-left: 10px;}
        button.logout:hover { background-color: #ec971f; }
        .error { color: #d9534f; margin-bottom: 15px; border: 1px solid #d9534f; padding: 10px; border-radius: 4px; background-color: #f2dede; }
        .message { color: #3c763d; margin: 15px 0; border: 1px solid #d6e9c6; padding: 10px; border-radius: 4px; background-color: #dff0d8; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { text-align: left; padding: 12px; border-bottom: 1px solid #eee; }
        th { background-color: #f9f9f9; }
        tr:hover { background-color: #f1f1f1; }
        .action-form { display: inline-block; margin-left: 5px; vertical-align: middle; }
        .password-change-form input[type="password"] { width: 150px; padding: 8px; margin: 0 5px 0 0; display: inline-block; }
        .password-change-form button { padding: 8px 15px; }
        .form-section { border: 1px solid #eee; padding: 20px; margin-bottom: 30px; border-radius: 5px; background: #fafafa; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Panel de Control de Usuarios</h1>

        <?php if (!$isPanelAuthenticated): ?>
            <!-- --- FORMULARIO DE LOGIN DEL PANEL --- -->
            <div class="form-section">
                <h2>Iniciar Sesión en Panel</h2>
                <?php if ($loginError): ?>
                    <p class="error"><?php echo htmlspecialchars($loginError); ?></p>
                <?php endif; ?>
                <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
                    <label for="login_password">Contraseña del Panel:</label>
                    <input type="password" id="login_password" name="login_password" required>
                    <button type="submit">Entrar</button>
                </form>
            </div>
        <?php else: ?>
            <!-- --- PANEL AUTENTICADO --- -->
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" style="display: inline;">
                <button type="submit" name="logout" class="logout">Cerrar Sesión del Panel</button>
            </form>
            <h2>Gestión de Usuarios</h2>

            <?php if ($actionMessage): ?>
                 <p class="<?php echo strpos($actionMessage, 'Error') === 0 || strpos($actionMessage, 'ERROR') === 0 ? 'error' : 'message'; ?>">
                     <?php echo htmlspecialchars($actionMessage); ?>
                 </p>
            <?php endif; ?>

            <!-- Formulario para Añadir Usuario -->
            <div class="form-section">
                <h3>Añadir Nuevo Usuario</h3>
                <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
                    <input type="hidden" name="action" value="add_user">
                    <div>
                        <label for="add_username">Nombre de Usuario:</label>
                        <input type="text" id="add_username" name="username" required maxlength="50">
                    </div>
                    <div>
                        <label for="add_password">Contraseña:</label>
                        <input type="password" id="add_password" name="password" required>
                    </div>
                    <button type="submit">Añadir Usuario</button>
                </form>
            </div>

             <!-- Lista de Usuarios -->
             <div class="form-section">
                 <h3>Usuarios Existentes (<?php echo count($displayUsers); ?>)</h3>
                 <?php if (!empty($displayUsers)): ?>
                 <table>
                     <thead>
                         <tr>
                             <th>Nombre de Usuario</th>
                             <th>Acciones</th>
                         </tr>
                     </thead>
                     <tbody>
                         <?php foreach ($displayUsers as $user): ?>
                         <tr>
                             <td><?php echo htmlspecialchars($user['username']); ?></td>
                             <td>
                                 <!-- Formulario para Eliminar Usuario -->
                                 <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" class="action-form" onsubmit="return confirm('¿Estás seguro de que quieres eliminar a <?php echo htmlspecialchars(addslashes($user['username'])); ?>?');">
                                     <input type="hidden" name="action" value="delete_user">
                                     <input type="hidden" name="username" value="<?php echo htmlspecialchars($user['username']); ?>">
                                     <button type="submit" class="delete">Eliminar</button>
                                 </form>
                                 <!-- Formulario para Cambiar Contraseña -->
                                 <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" class="action-form password-change-form">
                                     <input type="hidden" name="action" value="change_password">
                                     <input type="hidden" name="username" value="<?php echo htmlspecialchars($user['username']); ?>">
                                     <input type="password" name="new_password" placeholder="Nueva Contraseña" required>
                                     <button type="submit">Cambiar Pass</button>
                                 </form>
                             </td>
                         </tr>
                         <?php endforeach; ?>
                     </tbody>
                 </table>
                 <?php elseif (strpos($actionMessage, 'ERROR AL CARGAR DATOS') === false): // No mostrar "No hay usuarios" si hubo error al cargar ?>
                 <p>No hay usuarios registrados.</p>
                 <?php endif; ?>
             </div>

        <?php endif; // Fin del bloque autenticado ?>
    </div> <!-- Fin container -->
</body>
</html>
