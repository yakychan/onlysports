<?php
// --- Permitir CORS si la API se llama desde un origen diferente (Navegador, etc.) ---
// header("Access-Control-Allow-Origin: *"); // ¡Sé específico en producción!
// header("Access-Control-Allow-Methods: POST, OPTIONS");
// header("Access-Control-Allow-Headers: Content-Type");

// --- Responder a solicitudes OPTIONS (preflight de CORS) ---
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit;
}

// --- Forzar método POST ---
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); // Method Not Allowed
    echo json_encode(['success' => false, 'message' => 'Método no permitido. Use POST.']);
    exit;
}

// --- CONFIGURACIÓN (Duplicada - Mejor en 'config_auth.php') ---
define('JSON_FILE_PATH', 'users.json');
define('AES_KEY', 'ACAVALACLAVEAESIGUALQUEENLAAPP'); // ¡CAMBIAR!
define('AES_IV', 'ACAVALASEGUNDACLAVEIGUALQUEENLAAPP');      // ¡CAMBIAR!
define('AES_METHOD', 'aes-256-cbc');             // ¡VERIFICAR!
// --- FIN CONFIGURACIÓN ---

// --- Funciones Necesarias (Duplicadas - Mejor en 'config_auth.php') ---
function decryptData($base64EncryptedData) {
    $encrypted = base64_decode($base64EncryptedData);
    if ($encrypted === false) throw new Exception("Error Base64");
    $decryptedJson = openssl_decrypt($encrypted, AES_METHOD, AES_KEY, OPENSSL_RAW_DATA, AES_IV);
    if ($decryptedJson === false) throw new Exception("Error Desencriptación OpenSSL: " . openssl_error_string());
    $data = json_decode($decryptedJson, true);
    if ($data === null && json_last_error() !== JSON_ERROR_NONE) throw new Exception("Error JSON Decode: " . json_last_error_msg());
    if (!isset($data['users']) || !is_array($data['users'])) $data = ['users' => []];
    return $data;
}

function loadUserData() {
    if (!file_exists(JSON_FILE_PATH)) return ['users' => []];
    $base64EncryptedData = file_get_contents(JSON_FILE_PATH);
    if ($base64EncryptedData === false) throw new Exception("No se pudo leer archivo");
    if (empty(trim($base64EncryptedData))) return ['users' => []];
    try {
        return decryptData($base64EncryptedData);
    } catch (Exception $e) {
        error_log("API Login Error: Fallo al cargar/desencriptar " . JSON_FILE_PATH . ": " . $e->getMessage());
        throw new Exception("Error interno del servidor al procesar datos."); // Mensaje genérico al cliente
    }
}
// --- FIN Funciones Necesarias ---


// --- Respuesta por defecto ---
$response = ['success' => false, 'message' => 'Error desconocido.'];
http_response_code(500); // Default a error interno

try {
    // --- Obtener datos POST ---
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($username) || empty($password)) {
        http_response_code(400); // Bad Request
        $response = ['success' => false, 'message' => 'Usuario y contraseña requeridos.'];
    } else {
        // --- Cargar y desencriptar datos ---
        $userData = loadUserData();
        $users = $userData['users'];

        // --- Buscar usuario (case-insensitive) ---
        $foundUser = null;
        foreach ($users as $user) {
            if (strcasecmp($user['username'], $username) === 0) {
                $foundUser = $user;
                break;
            }
        }

        // --- Verificar usuario y contraseña ---
        if ($foundUser && isset($foundUser['passwordHash'])) {
            // Usar password_verify para comparar la contraseña enviada con el hash almacenado
            if (password_verify($password, $foundUser['passwordHash'])) {
                // ¡Éxito!
                http_response_code(200); // OK
                $response = [
                    'success' => true,
                    'username' => $foundUser['username'] // Devolver nombre de usuario confirmado
                ];
            } else {
                // Contraseña incorrecta
                http_response_code(401); // Unauthorized
                $response = ['success' => false, 'message' => 'Usuario o contraseña incorrectos.'];
            }
        } else {
            // Usuario no encontrado
            http_response_code(401); // Unauthorized
            $response = ['success' => false, 'message' => 'Usuario o contraseña incorrectos.'];
        }
    }

} catch (Exception $e) {
    // Capturar errores de carga/desencriptación u otros
    error_log("API Login Exception: " . $e->getMessage()); // Loggear error real
    $response = ['success' => false, 'message' => $e->getMessage()]; // Devolver mensaje de error genérico o específico
    // Mantener código 500 o ajustar según el error
}

// --- Enviar respuesta JSON ---
header('Content-Type: application/json; charset=utf-8');
echo json_encode($response);
exit;

?>
