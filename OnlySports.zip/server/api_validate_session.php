<?php
// Idealmente, usa un archivo de configuración compartido para constantes y funciones
// require_once 'config_auth.php'; // Si moviste las constantes y decryptData

// --- CONFIGURACIÓN (Duplicada si no usas config_auth.php) ---
define('JSON_FILE_PATH', './users.json'); // Ruta a tu archivo de usuarios
define('AES_KEY', 'ACAVALACLAVEAESIGUALQUEENLAAPP');
define('AES_IV', 'ACAVALASEGUNDACLAVEIGUALQUEENLAAPP');
define('AES_METHOD', 'aes-256-cbc');
// --- FIN CONFIGURACIÓN ---

// --- Funciones Necesarias (Duplicadas si no usas config_auth.php) ---
function decryptData($base64EncryptedData) { /* ... (tu función decryptData) ... */ $encrypted = base64_decode($base64EncryptedData); if ($encrypted === false) throw new Exception("Error Base64"); $decryptedJson = openssl_decrypt($encrypted, AES_METHOD, AES_KEY, OPENSSL_RAW_DATA, AES_IV); if ($decryptedJson === false) { $decryptedJson = openssl_decrypt($encrypted, AES_METHOD, AES_KEY, 0, AES_IV); if ($decryptedJson === false) throw new Exception("Error Desencriptación OpenSSL: " . openssl_error_string()); } $data = json_decode($decryptedJson, true); if ($data === null && json_last_error() !== JSON_ERROR_NONE) throw new Exception("Error JSON Decode: " . json_last_error_msg()); if (!isset($data['users']) || !is_array($data['users'])) $data = ['users' => []]; return $data; }
function loadUserData() { /* ... (tu función loadUserData) ... */ if (!file_exists(JSON_FILE_PATH)) return ['users' => []]; $base64EncryptedData = file_get_contents(JSON_FILE_PATH); if ($base64EncryptedData === false) throw new Exception("No se pudo leer archivo"); if (empty(trim($base64EncryptedData))) return ['users' => []]; try { return decryptData($base64EncryptedData); } catch (Exception $e) { error_log("API Validate Error: Fallo al cargar/desencriptar " . JSON_FILE_PATH . ": " . $e->getMessage()); throw new Exception("Error interno del servidor."); } }
// --- FIN Funciones Necesarias ---

header('Content-Type: application/json; charset=utf-8');
$response = ['valid' => false, 'message' => 'Usuario no especificado o inválido.'];
http_response_code(400); // Bad Request por defecto

// Esperamos el username vía GET (o POST si lo prefieres)
$usernameToValidate = trim($_GET['username'] ?? '');

if (!empty($usernameToValidate)) {
    try {
        $userData = loadUserData();
        $users = $userData['users'];
        $userIsValid = false;

        foreach ($users as $user) {
            if (isset($user['username']) && strcasecmp($user['username'], $usernameToValidate) === 0) {
                // Aquí podrías añadir más chequeos, ej. si el usuario está activo, no bloqueado, etc.
                // Por ahora, si existe, es válido para la sesión.
                $userIsValid = true;
                break;
            }
        }

        if ($userIsValid) {
            http_response_code(200);
            $response = ['valid' => true, 'username' => $usernameToValidate, 'message' => 'Sesión válida.'];
        } else {
            http_response_code(401); // Unauthorized o Not Found
            $response = ['valid' => false, 'message' => 'Usuario no encontrado o sesión inválida.'];
        }

    } catch (Exception $e) {
        error_log("API Validate Exception: " . $e->getMessage());
        http_response_code(500); // Internal Server Error
        $response = ['valid' => false, 'message' => 'Error del servidor durante la validación.'];
    }
}

echo json_encode($response);
exit;
?>
