package com.tararira.onlysports.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class ChannelCategory(
    @SerialName("name") val categoryName: String,
    @SerialName("samples") val samples: List<ChannelSample>
)