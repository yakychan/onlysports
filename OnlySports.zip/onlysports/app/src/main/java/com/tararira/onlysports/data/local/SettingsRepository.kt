package com.tararira.onlysports.data.local

import android.content.Context
import android.util.Log
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import com.tararira.onlysports.AppPrefsDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

class SettingsRepository(context: Context) {

    private val dataStore: DataStore<Preferences> = context.AppPrefsDataStore
    private val logTag = "SettingsRepository"

    // Flow para URL del EPG
    val epgUrlFlow: Flow<String> = dataStore.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { preferences -> preferences[PrefKeys.EPG_URL] ?: PrefKeys.DEFAULT_EPG_URL }

    // Flow para Intervalo de Refresco EPG (en horas)
    val epgRefreshIntervalHoursFlow: Flow<Int> = dataStore.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { preferences -> preferences[PrefKeys.EPG_REFRESH_INTERVAL_HOURS] ?: PrefKeys.DEFAULT_EPG_REFRESH_INTERVAL_HOURS }

    // Función para Guardar Configuración EPG
    suspend fun saveEpgSettings(url: String, intervalHours: Int) {
        val validInterval = if (intervalHours in PrefKeys.EPG_INTERVAL_OPTIONS) intervalHours else PrefKeys.DEFAULT_EPG_REFRESH_INTERVAL_HOURS
        try {
            dataStore.edit { preferences ->
                Log.d(logTag, "Saving EPG Settings - URL: $url, Interval: $validInterval hrs")
                preferences[PrefKeys.EPG_URL] = url
                preferences[PrefKeys.EPG_REFRESH_INTERVAL_HOURS] = validInterval
            }
        } catch (e: Exception) { Log.e(logTag, "Error saving EPG settings", e) }
    }
}