package com.tararira.onlysports

import android.app.UiModeManager
import android.content.Context
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.os.Bundle
import android.os.PowerManager
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.navigation.compose.rememberNavController
import com.tararira.onlysports.navigation.AppNavigation
import com.tararira.onlysports.ui.theme.OnlySportsAppTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private var wakeLock: PowerManager.WakeLock? = null
    private val WAKE_LOCK_TAG = "OnlySports::ScreenLock"
    private val mainActivityScope = CoroutineScope(Dispatchers.Main + SupervisorJob()) // Scope para delays
    private var isPhoneDevice: Boolean = false // Guardar estado

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)

        // Determinar tipo de dispositivo
        val uiModeManager = getSystemService(UI_MODE_SERVICE) as UiModeManager
        isPhoneDevice = uiModeManager.currentModeType != Configuration.UI_MODE_TYPE_TELEVISION

        if (isPhoneDevice) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            // Intentar ocultar barras inmediatamente
            hideSystemBars()
            // Y programar otro intento por si la ventana no estaba lista
            mainActivityScope.launch {
                delay(100) // Pequeño delay
                hideSystemBars()
            }
        }

        // Inicializar WakeLock
        try {
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            // Probar con BRIGHT para asegurar que no se atenúe
            wakeLock = powerManager.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, WAKE_LOCK_TAG)
            wakeLock?.setReferenceCounted(false)
            Log.d("MainActivity", "WakeLock created: $wakeLock")
        } catch (e: Exception) { Log.e("MainActivity", "Error creating WakeLock", e) }


        setContent {
            OnlySportsAppTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    val navController = rememberNavController()
                    AppNavigation(navController = navController, isPhone = isPhoneDevice)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        Log.d("MainActivity", "onResume called.")
        // Adquirir WakeLock si es necesario
        acquireWakeLock()
        // Volver a intentar poner pantalla completa en teléfonos al volver a la app
        if (isPhoneDevice) {
            hideSystemBars()
            mainActivityScope.launch { delay(50); hideSystemBars()} // Con delay por si acaso
        }
    }

    override fun onPause() {
        super.onPause()
        Log.d("MainActivity", "onPause called.")
        // Liberar WakeLock
        releaseWakeLock()
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("MainActivity", "onDestroy called.")
        releaseWakeLock() // Asegurar liberación final
        mainActivityScope.cancel() // Cancelar corrutinas pendientes
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        Log.d("MainActivity", "onWindowFocusChanged: hasFocus=$hasFocus")
        // Reaplicar pantalla completa si se recupera foco y es teléfono
        if (hasFocus && isPhoneDevice) {
            hideSystemBars()
        }
    }

    // --- Funciones Helper ---
    private fun hideSystemBars() {
        try {
            Log.d("MainActivity", "Attempting to hide system bars...")
            val windowInsetsController = WindowCompat.getInsetsController(window, window.decorView)
            windowInsetsController.hide(WindowInsetsCompat.Type.systemBars())
            windowInsetsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            Log.d("MainActivity", "System bars hide requested.")
        } catch (e: Exception) { Log.e("MainActivity", "Error hiding system bars", e) }
    }

    private fun acquireWakeLock() {
        try {
            if (wakeLock?.isHeld == false) {
                Log.i("MainActivity", "Acquiring WakeLock...")
                wakeLock?.acquire()
            } else { Log.d("MainActivity", "WakeLock already held or null.") }
        } catch (e: Exception) { Log.e("MainActivity", "Error acquiring WakeLock", e) }
    }

    private fun releaseWakeLock() {
        try {
            if (wakeLock?.isHeld == true) {
                Log.i("MainActivity", "Releasing WakeLock...")
                wakeLock?.release()
            } else { Log.d("MainActivity", "WakeLock not held or null, no release needed.") }
        } catch (e: Exception) { Log.e("MainActivity", "Error releasing WakeLock", e) }
    }
}