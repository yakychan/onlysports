package com.tararira.onlysports.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tararira.onlysports.data.epg.model.EpgProgramme
import com.tararira.onlysports.data.model.ChannelSample
import com.tararira.onlysports.data.repository.ChannelRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.Duration
import java.time.OffsetDateTime
import java.time.ZoneId

// Estado de la UI para la pantalla del reproductor
data class PlayerUiState(
    val channelSamples: List<ChannelSample> = emptyList(),
    val isLoading: Boolean = true,
    val loadingError: String? = null,
    val fatalError: String? = null,
    val playbackError: String? = null,
    val currentEpgInfo: CurrentEpgInfo? = null
)

class PlayerViewModel(
    private val sharedNavViewModel: SharedNavViewModel,
    private val channelRepository: ChannelRepository
) : ViewModel() {

    private val logTag = "PlayerViewModel" // Tag para logs
    private val _uiState = MutableStateFlow(PlayerUiState())
    val uiState: StateFlow<PlayerUiState> = _uiState.asStateFlow()

    private val rawEpgDataFlow: StateFlow<Map<String, List<EpgProgramme>>?> = channelRepository.epgDataFlow

    init {
        Log.d(logTag, "--- PlayerViewModel Initializing ---")
        observeSharedChannelId()
    }

    private fun observeSharedChannelId() {
        viewModelScope.launch {
            Log.d(logTag, "Observing SharedNavViewModel for selectedChannelId...")
            sharedNavViewModel.selectedChannelId
                .filterNotNull()
                .collectLatest { id ->
                    Log.i(logTag, ">>> Selected Channel ID changed to: '$id'. Triggering data load.") // Log más visible
                    loadChannelDataAndEpg(id)
                }
        }
    }

    private fun loadChannelDataAndEpg(channelId: String) {
        Log.i(logTag, ">>> loadChannelDataAndEpg called with ID: '$channelId'") // Log más visible
        viewModelScope.launch {
            Log.d(logTag, "Updating UI state: isLoading=true, clearing errors/samples...")
            _uiState.update {
                it.copy(
                    isLoading = true,
                    loadingError = null,
                    fatalError = null,
                    playbackError = null,
                    channelSamples = emptyList(),
                    currentEpgInfo = null
                )
            }

            Log.d(logTag, "Fetching samples for channel ID '$channelId' from repository...")
            val samplesResult = channelRepository.getChannelsById(channelId)

            Log.d(logTag, "Calculating EPG info for '$channelId'...")
            val currentEpg = calculateSingleCurrentEpgInfo(channelId, rawEpgDataFlow.value)
            Log.d(logTag,"Calculated EPG for $channelId: Current='${currentEpg?.programme?.title ?: "N/A"}', Next='${currentEpg?.nextProgramme?.title ?: "N/A"}'")

            if (samplesResult.isSuccess) {
                val samples = samplesResult.getOrThrow()
                // --- LOG AÑADIDO: Número de samples ---
                Log.i(logTag, "Successfully loaded ${samples.size} samples for channel ID '$channelId'.")
                // --- FIN LOG AÑADIDO ---
                if (samples.isNotEmpty()) {
                    Log.d(logTag, "Updating UI state: isLoading=false, samples loaded, EPG set.")
                    _uiState.update {
                        it.copy(
                            channelSamples = samples,
                            isLoading = false,
                            currentEpgInfo = currentEpg
                        )
                    }
                } else {
                    Log.w(logTag, "Channel ID '$channelId' loaded successfully, but sample list is empty.")
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            loadingError = "Canal '$channelId' no encontrado o sin fuentes.", // Mensaje más específico
                            currentEpgInfo = currentEpg
                        )
                    }
                }
            } else {
                val error = samplesResult.exceptionOrNull()
                Log.e(logTag, "Failed to load channel data for ID '$channelId': ${error?.message}", error)
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        loadingError = "Error al cargar datos: ${error?.message ?: "Desconocido"}",
                        currentEpgInfo = currentEpg // Aún podemos mostrar EPG si se calculó
                    )
                }
            }
            Log.d(logTag, "<<< loadChannelDataAndEpg finished for ID: '$channelId'")
        }
    }


    private fun calculateSingleCurrentEpgInfo(
        channelId: String?,
        rawEpg: Map<String, List<EpgProgramme>>?
    ): CurrentEpgInfo? {
        if (channelId == null || rawEpg == null) {
            Log.v(logTag, "calculateSingleCurrentEpgInfo returning null (null channelId or rawEpg).")
            return null
        }
        val programsForChannel = rawEpg[channelId]?.sortedBy { it.start }
        if (programsForChannel.isNullOrEmpty()){
            Log.v(logTag, "calculateSingleCurrentEpgInfo: No EPG programs found for '$channelId'.")
            return CurrentEpgInfo(null, null, null)
        }

        val now = OffsetDateTime.now(ZoneId.systemDefault())
        val currentProgram = programsForChannel.find { it.isAiringAt(now) }
        var progress: Float? = null
        var nextProgram: EpgProgramme? = null

        if (currentProgram != null) {
            // ... (cálculo de progreso como estaba) ...
            try {
                val totalDuration = Duration.between(currentProgram.start, currentProgram.stop)
                val elapsedDuration = Duration.between(currentProgram.start, now)
                if (!totalDuration.isZero && !totalDuration.isNegative && !elapsedDuration.isNegative) {
                    progress = (elapsedDuration.toMillis().toFloat() / totalDuration.toMillis().toFloat()).coerceIn(0.0f, 1.0f)
                }
            } catch (e: Exception) {
                Log.w(logTag, "Error calculating EPG progress for '$channelId': ${e.message}")
                progress = null
            }
            val currentIndex = programsForChannel.indexOf(currentProgram)
            if (currentIndex != -1 && currentIndex + 1 < programsForChannel.size) {
                nextProgram = programsForChannel[currentIndex + 1]
            }
        } else {
            nextProgram = programsForChannel.firstOrNull { !it.start.isBefore(now) }
        }
        Log.v(logTag, "calculateSingleCurrentEpgInfo for '$channelId': Found Current='${currentProgram?.title}', Next='${nextProgram?.title}', Progress=$progress")
        return CurrentEpgInfo(currentProgram, progress, nextProgram)
    }

    fun setPlaybackError(errorMessage: String?) {
        // Log más detallado, indicando si se limpia o se establece un error
        if (errorMessage == null) {
            Log.d(logTag, "Clearing playback error state.")
        } else {
            Log.w(logTag, "Setting playback error state: '$errorMessage'")
        }
        _uiState.update { it.copy(playbackError = errorMessage) }
    }

    fun setFatalError(errorMessage: String?) {
        Log.e(logTag, ">>> Setting FATAL error state: '$errorMessage'") // Log más visible
        // Asegurar que isLoading se ponga a false y playbackError se limpie al ocurrir un error fatal
        _uiState.update { it.copy(fatalError = errorMessage, isLoading = false, playbackError = null) }
    }

    override fun onCleared() {
        super.onCleared()
        Log.d(logTag,"--- PlayerViewModel cleared. ---")
    }
}