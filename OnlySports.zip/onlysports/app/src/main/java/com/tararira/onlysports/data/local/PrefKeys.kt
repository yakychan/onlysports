package com.tararira.onlysports.data.local

import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey

object PrefKeys {

    // --- Clave para Favoritos ---
    val FAVORITE_CHANNEL_IDS = stringSetPreferencesKey("favorite_channel_ids")

    // --- Claves para Configuración EPG ---
    val EPG_URL = stringPreferencesKey("epg_url") // Clave para URL EPG
    val EPG_REFRESH_INTERVAL_HOURS = intPreferencesKey("epg_refresh_interval_hours") // Clave para Intervalo EPG
    val EPG_LAST_FETCH_TIMESTAMP_KEY = longPreferencesKey("epg_last_fetch_timestamp") // Clave para Timestamp

    // --- Valores por defecto y constantes para EPG ---
    const val DEFAULT_EPG_URL = "https://www.open-epg.com/files/argentina4.xml" // URL por defecto EPG
    const val DEFAULT_EPG_REFRESH_INTERVAL_HOURS = 24 // Intervalo por defecto (horas)
    val EPG_INTERVAL_OPTIONS = listOf(6, 12, 24, 48) // Opciones para la UI

    // --- Clave para URL JSON (Fija, pero puede definirse aquí) ---
    const val DEFAULT_JSON_URL = "LALISTADECANALESVAAQUI" // URL JSON por defecto/fija
}