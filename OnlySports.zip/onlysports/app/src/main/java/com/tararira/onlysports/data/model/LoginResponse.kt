package com.tararira.onlysports.data.model

import android.annotation.SuppressLint
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@SuppressLint("UnsafeOptInUsageError")
@Serializable
data class LoginResponse(
    @SerialName("success") val success: Boolean,
    @SerialName("message") val message: String? = null, // Mensaje de error opcional
    @SerialName("username") val username: String? = null // Nombre de usuario si éxito
)
