package com.tararira.onlysports.navigation

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Login : Screen("login")
    object Main : Screen("main")
    object ChannelList : Screen("channel_list")
    object Favorites : Screen("favorites")
    object Settings : Screen("settings")
    object Player : Screen("player")
    object CodeEntry : Screen("code_entry")
    object ChannelDiagnostics : Screen("channel_diagnostics")
}