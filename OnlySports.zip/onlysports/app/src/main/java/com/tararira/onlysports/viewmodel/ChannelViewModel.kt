package com.tararira.onlysports.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tararira.onlysports.data.epg.model.EpgProgramme
import com.tararira.onlysports.data.local.FavoritesRepository
import com.tararira.onlysports.data.model.ChannelCategory
import com.tararira.onlysports.data.model.ChannelSample
import com.tararira.onlysports.data.repository.ChannelRepository
import com.tararira.onlysports.data.repository.ChannelRepository.ChannelDataResult
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.Duration
import java.time.OffsetDateTime
import java.time.ZoneId

data class CurrentEpgInfo(
    val programme: EpgProgramme?,
    val progress: Float?,
    val nextProgramme: EpgProgramme?
)

data class ChannelListUiState(
    val categories: Map<String, List<ChannelSample>> = emptyMap(),
    val currentEpg: Map<String, CurrentEpgInfo> = emptyMap(),
    val favoriteChannelIds: Set<String> = emptySet(),
    val isLoadingChannels: Boolean = true,
    val error: String? = null
)

@OptIn(ExperimentalCoroutinesApi::class)
class ChannelViewModel(
    private val channelRepository: ChannelRepository,
    private val favoritesRepository: FavoritesRepository
) : ViewModel() {

    private val logTag = "ChannelViewModel"

    private val _rawEpgData: StateFlow<Map<String, List<EpgProgramme>>?> = channelRepository.epgDataFlow
    private val _favoritesFlow: Flow<Set<String>> = favoritesRepository.favoriteChannelIdsFlow
    private val _channelResultFlow: StateFlow<ChannelDataResult> = channelRepository.channelDataFlow

    private val _isLoadingChannelsFlow: StateFlow<Boolean> = _channelResultFlow
        .map {
            Log.d(logTag, "ChannelResultFlow changed: ${it::class.simpleName}. Mapping isLoading...")
            it is ChannelDataResult.Loading
        }
        .distinctUntilChanged()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), true)

    private val _errorFlow: StateFlow<String?> = _channelResultFlow
        .map {
            Log.d(logTag, "ChannelResultFlow changed: ${it::class.simpleName}. Mapping error...")
            if (it is ChannelDataResult.Error) it.message else null
        }
        .distinctUntilChanged()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), null)

    private val _categoriesFlow: StateFlow<List<ChannelCategory>> = _channelResultFlow
        .mapLatest { result ->
            Log.d(logTag, "ChannelResultFlow changed: ${result::class.simpleName}. Mapping categories...")
            if (result is ChannelDataResult.Success) {
                Log.i(logTag, "Mapping SUCCESS to ${result.categories.size} categories.")
                result.categories
            } else {
                Log.d(logTag, "Mapping NON-SUCCESS to empty category list.")
                emptyList()
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    private val _currentEpgWithProgressFlow = combine(_categoriesFlow, _rawEpgData) { categoriesList, rawEpgMap ->
        calculateCurrentAndNextEpgWithProgress(categoriesList, rawEpgMap ?: emptyMap())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyMap())


    val uiState: StateFlow<ChannelListUiState> = combine(
        _categoriesFlow,
        _currentEpgWithProgressFlow,
        _favoritesFlow,
        _isLoadingChannelsFlow,
        _errorFlow
    ) { categoriesList, currentEpgMap, favoriteIds, isLoading, errorMsg ->
        Log.i(logTag, ">>> Combining for UI STATE <<<")
        Log.d(logTag, "  isLoading: $isLoading")
        Log.d(logTag, "  errorMsg: $errorMsg")
        Log.d(logTag, "  categoriesList size: ${categoriesList.size}")
        Log.d(logTag, "  favoriteIds size: ${favoriteIds.size}")

        val categoriesMapForUi = categoriesList.associate { category ->
            val uniqueDisplaySamples = (category.samples ?: emptyList())
                .filter { !it.channelId.isNullOrBlank() }
                .distinctBy { it.channelId }
            category.categoryName to uniqueDisplaySamples
        }.filterValues { it.isNotEmpty() }
        Log.d(logTag, "  Processed categoriesMapForUi size: ${categoriesMapForUi.size}")

        ChannelListUiState(categoriesMapForUi, currentEpgMap, favoriteIds, isLoading, errorMsg)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = ChannelListUiState(isLoadingChannels = true)
    )

    val uniqueOrderedChannelIds: StateFlow<List<String>> = _categoriesFlow
        .map { categoriesList ->
            categoriesList.sortedBy { it.categoryName }
                .flatMap { it.samples ?: emptyList() }
                .filter { !it.channelId.isNullOrBlank() }
                .distinctBy { it.channelId }
                .mapNotNull { it.channelId }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    init {
        Log.i(logTag, ">>> ChannelViewModel Initialized <<<")
        refreshEpg()
        viewModelScope.launch {
            channelRepository.channelDataFlow.collect { result ->
                Log.i(logTag, "Observed ChannelDataResult in ViewModel: ${result::class.simpleName}")
                if (result is ChannelDataResult.Error) {
                    Log.e(logTag, "ChannelDataResult is Error: ${result.message}")
                } else if (result is ChannelDataResult.Success) {
                    Log.i(logTag, "ChannelDataResult is Success with ${result.categories.size} categories.")
                }
            }
        }
    }

    fun forceRefreshChannels() {
        Log.i(logTag, ">>> forceRefreshChannels called. Delegating to repository.")
        channelRepository.forceRefreshChannels()
    }

    fun refreshEpg() {
        Log.d(logTag, "Requesting EPG refresh check from repository.")
        channelRepository.refreshEpgInBackgroundIfNeeded()
    }

    private fun calculateCurrentAndNextEpgWithProgress(
        categories: List<ChannelCategory>,
        rawEpg: Map<String, List<EpgProgramme>>
    ): Map<String, CurrentEpgInfo> {
        if (categories.isEmpty() && rawEpg.isEmpty()) { Log.v(logTag, "EPG Calc: No categories AND no raw EPG."); return emptyMap() }
        if (categories.isEmpty()) { Log.v(logTag, "EPG Calc: No categories to process."); return emptyMap() }
        if (rawEpg.isEmpty()) { Log.v(logTag, "EPG Calc: No raw EPG data available."); return emptyMap() }

        val currentEpgMap = mutableMapOf<String, CurrentEpgInfo>()
        val now = OffsetDateTime.now(ZoneId.systemDefault())
        val displayedChannelIds = categories.flatMap { it.samples ?: emptyList() }.mapNotNull { it.channelId }.toSet()
        Log.v(logTag, "EPG Calc for ${displayedChannelIds.size} unique channel IDs.")

        displayedChannelIds.forEach { channelId ->
            val programsForChannel = rawEpg[channelId]?.sortedBy { it.start }
            val currentProgram = programsForChannel?.find { it.isAiringAt(now) }
            var progress: Float? = null
            var nextProgram: EpgProgramme? = null

            if (currentProgram != null) {
                try {
                    val totalDuration = Duration.between(currentProgram.start, currentProgram.stop)
                    val elapsedDuration = Duration.between(currentProgram.start, now)
                    if (!totalDuration.isZero && !totalDuration.isNegative && !elapsedDuration.isNegative) {
                        progress = (elapsedDuration.toMillis().toFloat() / totalDuration.toMillis().toFloat()).coerceIn(0.0f, 1.0f)
                    }
                } catch (e: Exception) {
                    Log.w(logTag, "EPG Progress Error for '$channelId': ${e.message}")
                    progress = null
                }
                val currentIndex = programsForChannel.indexOf(currentProgram)
                if (currentIndex != -1 && currentIndex + 1 < programsForChannel.size) {
                    nextProgram = programsForChannel[currentIndex + 1]
                }
            } else {
                nextProgram = programsForChannel?.firstOrNull { !it.start.isBefore(now) }
            }
            currentEpgMap[channelId] = CurrentEpgInfo(currentProgram, progress, nextProgram)
        }
        return currentEpgMap
    }

    fun toggleFavorite(channelId: String?) {
        if (channelId.isNullOrBlank()) {Log.w(logTag,"toggleFavorite with null/blank ID."); return}
        Log.d(logTag,"Toggling fav for: $channelId");viewModelScope.launch{try{favoritesRepository.toggleFavorite(channelId);Log.d(logTag,"Fav toggled for $channelId.")}catch(e:Exception){Log.e(logTag,"Error toggling fav $channelId",e)}}
    }

    override fun onCleared() {
        super.onCleared()
        Log.i(logTag, ">>> ChannelViewModel cleared. <<<")
    }
}