package com.tararira.onlysports.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tararira.onlysports.data.model.ChannelSample
import com.tararira.onlysports.data.repository.ChannelRepository
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.TimeUnit

// --- Data classes para el estado ---
enum class ChannelCheckStatus { PENDING, CHECKING, OK, PARTIAL, ERROR }

data class ChannelDiagnosticInfo(
    val channelSample: ChannelSample, // Referencia al sample único mostrado
    val status: ChannelCheckStatus = ChannelCheckStatus.PENDING,
    val errorMessage: String? = null
)

data class ChannelDiagnosticsUiState(
    val channelChecks: List<ChannelDiagnosticInfo> = emptyList(),
    val isChecking: Boolean = false,
    val progress: Float = 0f,
    val error: String? = null // Error al cargar la lista inicial
)
// --- Fin Data classes ---

class ChannelDiagnosticsViewModel(
    private val channelRepository: ChannelRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChannelDiagnosticsUiState())
    val uiState: StateFlow<ChannelDiagnosticsUiState> = _uiState.asStateFlow()

    private val logTag = "ChannelDiagnosticsVM"
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()
    private var checkJob: Job? = null

    // Código secreto (¡CAMBIAR Y PROTEGER!)
    val secretCode = "12345678"

    // Carga la lista inicial de canales únicos
    private suspend fun initializeChannelList(): List<ChannelDiagnosticInfo> {
        Log.d(logTag, "Initializing channel list for diagnostics...")
        // Asegúrate que ChannelRepository tenga esta función o una similar
        val result = channelRepository.getFlatUniqueChannels() // Obtiene lista plana única
        return if (result.isSuccess) {
            val uniqueChannels = result.getOrNull() ?: emptyList()
            Log.d(logTag, "Loaded ${uniqueChannels.size} unique channels for initial list.")
            uniqueChannels.map { ChannelDiagnosticInfo(it) } // Mapea a estado inicial
        } else {
            val errorMsg = "Error al cargar lista inicial: ${result.exceptionOrNull()?.message}"
            Log.e(logTag, errorMsg, result.exceptionOrNull())
            _uiState.update { it.copy(error = errorMsg, isChecking = false) }
            emptyList()
        }
    }

    // Inicia el proceso de comprobación
    fun startChannelCheck() {
        if (_uiState.value.isChecking) return // Evitar múltiples
        checkJob?.cancel() // Cancelar anterior

        checkJob = viewModelScope.launch {
            val initialList = initializeChannelList()
            if (initialList.isEmpty() && _uiState.value.error == null) {
                Log.w(logTag, "Initial list empty, check aborted.")
                _uiState.update { it.copy(isChecking = false) }
                return@launch
            }
            _uiState.update { it.copy(channelChecks = initialList, isChecking = true, progress = 0f, error = null) }
            Log.i(logTag, "Starting check process for ${initialList.size} channels...")

            var checkedCount = 0
            val totalChannelsToDisplay = initialList.size.toFloat().coerceAtLeast(1f)

            initialList.forEachIndexed { index, initialInfo ->
                if (!isActive) return@forEachIndexed

                val channelId = initialInfo.channelSample.channelId
                if (channelId.isNullOrBlank()) {
                    updateItemStatus(index, ChannelCheckStatus.ERROR, "ID Inválido")
                    checkedCount++; _uiState.update { it.copy(progress = checkedCount / totalChannelsToDisplay) }; delay(10)
                    return@forEachIndexed
                }

                updateItemStatus(index, ChannelCheckStatus.CHECKING); delay(10)

                val allSourcesResult = channelRepository.getChannelsById(channelId)

                if (allSourcesResult.isFailure || allSourcesResult.getOrNull().isNullOrEmpty()) {
                    updateItemStatus(index, ChannelCheckStatus.ERROR, "Error fuentes")
                } else {
                    val sources = allSourcesResult.getOrThrow()
                    Log.d(logTag, "Checking ${sources.size} sources for $channelId...")
                    var anyOk = false; var allOk = true; var firstError: String? = null

                    sources.forEach { source ->
                        val sourceOk = checkUri(source.uri)
                        if (!sourceOk) { allOk = false; if (firstError == null) firstError = "Fallo URI"; Log.w(logTag, "  -> FAILED: ${source.uri.take(50)}...") }
                        else { anyOk = true; Log.i(logTag, "  -> OK: ${source.uri.take(50)}...") }
                        delay(50); if (!isActive) return@forEach
                    }

                    val finalStatus = when { anyOk && !allOk -> ChannelCheckStatus.PARTIAL; anyOk -> ChannelCheckStatus.OK; else -> ChannelCheckStatus.ERROR }
                    val errMsg = if (finalStatus == ChannelCheckStatus.ERROR) firstError ?: "Todos fallaron" else if (finalStatus == ChannelCheckStatus.PARTIAL) "Alguna fuente falló" else null
                    Log.d(logTag, "-> Result for ID $channelId: $finalStatus")
                    updateItemStatus(index, finalStatus, errMsg)
                }

                checkedCount++
                _uiState.update { it.copy(progress = checkedCount / totalChannelsToDisplay) }
                delay(100) // Delay entre canales
            }
            Log.i(logTag, "Channel check process finished.")
            _uiState.update { it.copy(isChecking = false) }
        }
    }

    // Cancela la comprobación
    fun cancelChannelCheck() {
        if (_uiState.value.isChecking) {
            Log.d(logTag, "Cancelling channel check job...")
            checkJob?.cancel()
            _uiState.update { it.copy(isChecking = false, progress = 0f) }
        }
    }

    // Actualiza el estado de un item
    private fun updateItemStatus(index: Int, status: ChannelCheckStatus, message: String? = null) {
        viewModelScope.launch(Dispatchers.Main.immediate) {
            _uiState.update { current ->
                current.channelChecks.toMutableList().also {
                    if (index in it.indices) it[index] = it[index].copy(status = status, errorMessage = message)
                }.let { current.copy(channelChecks = it) }
            }
        }
    }

    // Comprueba URI con HEAD request
    private suspend fun checkUri(urlString: String?): Boolean {
        if (urlString.isNullOrBlank()) return false
        return withContext(Dispatchers.IO) {
            try { httpClient.newCall(Request.Builder().head().url(urlString).build()).execute().use { it.isSuccessful } }
            catch (e: Exception) { false } // Capturar cualquier excepción
        }
    }

    // Limpiar job al destruir ViewModel
    override fun onCleared() {
        super.onCleared(); checkJob?.cancel()
        Log.d(logTag,"ViewModel cleared, check job cancelled.")
    }
}