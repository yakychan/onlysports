package com.tararira.onlysports.ui.screens

import android.app.Activity
import android.util.Log
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.tararira.onlysports.R
import com.tararira.onlysports.data.model.ChannelSample
import com.tararira.onlysports.player.PlayerManager
import com.tararira.onlysports.viewmodel.CurrentEpgInfo
import com.tararira.onlysports.viewmodel.PlayerUiState
import com.tararira.onlysports.viewmodel.SharedNavViewModel
import kotlinx.coroutines.delay

private const val DOUBLE_TAP_OK_DELAY_MS = 500L
private const val FATAL_ERROR_RETRY_DELAY_MS = 3500L
private const val EPG_OVERLAY_DURATION_MS = 7000L

@androidx.annotation.OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    uiState: PlayerUiState,
    sharedViewModel: SharedNavViewModel,
    onPlaybackError: (String?) -> Unit,
    onFatalError: (String?) -> Unit,
    onBackPressed: () -> Unit
) {
    val context = LocalContext.current
    var playerManager by remember { mutableStateOf<PlayerManager?>(null) }
    val lifecycleOwner = LocalLifecycleOwner.current
    val focusRequester = remember { FocusRequester() }
    val view = LocalView.current
    val window = (view.context as? Activity)?.window
    var playerViewRef by remember { mutableStateOf<PlayerView?>(null) }

    val currentSelectedId by sharedViewModel.selectedChannelId.collectAsStateWithLifecycle()
    val currentIdList by sharedViewModel.currentChannelIdList.collectAsStateWithLifecycle()
    var lastChangeDirectionWasNext by remember { mutableStateOf<Boolean?>(null) }

    var showEpgOverlay by remember { mutableStateOf(false) }
    val currentChannelInfo = remember(uiState.channelSamples) {
        uiState.channelSamples.firstOrNull()
    }
    val currentEpgInfo = uiState.currentEpgInfo

    LaunchedEffect(uiState.channelSamples) {
        if (uiState.channelSamples.isNotEmpty()) {
            playerManager?.releasePlayer(); playerManager = null
            try {
                playerManager = PlayerManager(
                    context = context.applicationContext,
                    channelSamples = uiState.channelSamples,
                    onError = onFatalError,
                    onPlaybackError = onPlaybackError
                )
                showEpgOverlay = true
            } catch (e: Exception) {
                onFatalError("Error al inicializar reproductor: ${e.message}")
                playerManager = null
            }
        } else {
            playerManager?.releasePlayer()
            playerManager = null
        }
    }

    LaunchedEffect(playerManager) {
        if (playerManager != null) {
            delay(150)
            try {
                focusRequester.requestFocus()
            } catch (e: Exception) {
                Log.e("PlayerScreen", "Error requesting focus to PlayerViewComposable", e)
            }
        }
    }

    LaunchedEffect(showEpgOverlay) {
        if (showEpgOverlay) {
            delay(EPG_OVERLAY_DURATION_MS)
            showEpgOverlay = false
        }
    }

    DisposableEffect(lifecycleOwner, window) {
        val lifecycleObserver = LifecycleEventObserver { _, event -> }
        lifecycleOwner.lifecycle.addObserver(lifecycleObserver)

        var playerListener: Player.Listener? = null
        val currentManagerAtEffectStart = playerManager

        if (currentManagerAtEffectStart != null) {
            playerListener = object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    if (isPlaying) {
                        window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    } else {
                        window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    }
                }
            }
            currentManagerAtEffectStart.exoPlayer.addListener(playerListener)
            if (currentManagerAtEffectStart.exoPlayer.isPlaying) {
                window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            } else {
                window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        } else {
            window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }

        onDispose {
            lifecycleOwner.lifecycle.removeObserver(lifecycleObserver)
            if (playerListener != null && currentManagerAtEffectStart != null) {
                try {
                    currentManagerAtEffectStart.exoPlayer.removeListener(playerListener)
                } catch (e: Exception) {
                    Log.e("PlayerScreen", "Error removing player listener on dispose", e)
                }
            }
            val managerToRelease = playerManager
            managerToRelease?.releasePlayer()
            window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            if (playerManager == managerToRelease) {
                playerManager = null
            }
        }
    }

    LaunchedEffect(uiState.fatalError, currentSelectedId, currentIdList) {
        val fatalErrorMsg = uiState.fatalError
        if (fatalErrorMsg != null) {
            Toast.makeText(context, fatalErrorMsg, Toast.LENGTH_LONG).show()
            delay(FATAL_ERROR_RETRY_DELAY_MS)

            val directionOfLastError = lastChangeDirectionWasNext

            if (directionOfLastError != null) {
                changeChannel(currentSelectedId, currentIdList, sharedViewModel, goNext = directionOfLastError)
            } else {
                if (currentIdList.size > 1 && currentSelectedId != null) {
                    changeChannel(currentSelectedId, currentIdList, sharedViewModel, goNext = true)
                } else if (currentIdList.size == 1 && currentSelectedId != null) {
                    sharedViewModel.requestFocusOnLastPlayedChannelInList()
                    onBackPressed()
                }
                else {
                    sharedViewModel.requestFocusOnLastPlayedChannelInList()
                    onBackPressed()
                }
            }
            lastChangeDirectionWasNext = null
        }
    }

    BackHandler {
        sharedViewModel.requestFocusOnLastPlayedChannelInList()
        playerManager?.releasePlayer()
        playerManager = null
        onBackPressed()
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Color.Black) {
        Box(modifier = Modifier.fillMaxSize()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                when {
                    uiState.fatalError != null -> {
                        Text(uiState.fatalError, color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center, style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(32.dp))
                    }
                    uiState.loadingError != null -> {
                        Text("Error al cargar datos del canal:\n${uiState.loadingError}", color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center, modifier = Modifier.padding(16.dp))
                    }
                    uiState.isLoading || playerManager == null -> {
                        CircularProgressIndicator()
                    }
                    playerManager != null -> {
                        PlayerViewComposableWithInput(
                            playerManager = playerManager!!,
                            focusRequester = focusRequester,
                            setPlayerViewRef = { playerViewRef = it },
                            onDoubleTapOk = {
                                playerViewRef?.hideController()
                                playerManager?.switchToNextSource()
                            },
                            onChannelUp = { // Original: onChannelDown -> Siguiente canal en la lista
                                lastChangeDirectionWasNext = true // fue DOWN (siguiente)
                                changeChannel(currentSelectedId, currentIdList, sharedViewModel, true)
                                showEpgOverlay = true
                            },
                            onChannelDown = { // Original: onChannelUp -> Canal anterior en la lista
                                lastChangeDirectionWasNext = false // fue UP (anterior)
                                changeChannel(currentSelectedId, currentIdList, sharedViewModel, false)
                                showEpgOverlay = true
                            }
                        )
                    }
                }
            }

            AnimatedVisibility(
                visible = showEpgOverlay && uiState.fatalError == null,
                modifier = Modifier.align(Alignment.BottomCenter),
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                EpgInfoOverlay(
                    channelInfo = currentChannelInfo,
                    epgInfo = currentEpgInfo
                )
            }

            if (uiState.playbackError != null && uiState.fatalError == null) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = if (showEpgOverlay) 90.dp else 16.dp)
                        .background(Color.Black.copy(alpha = 0.7f))
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Text(
                        uiState.playbackError,
                        color = Color.White,
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}


private fun changeChannel(currentId: String?, idList: List<String>, sharedViewModel: SharedNavViewModel, goNext: Boolean) {
    if (currentId == null) {
        return
    }
    if (idList.size <= 1 && idList.firstOrNull() == currentId) {
        return
    }
    if (idList.isEmpty()){
        return
    }

    val currentIndex = idList.indexOf(currentId)
    if (currentIndex == -1) {
        idList.firstOrNull()?.let {
            sharedViewModel.selectChannel(it)
        }
        return
    }

    val newIndex = if (goNext) {
        (currentIndex + 1) % idList.size
    } else {
        (currentIndex - 1 + idList.size) % idList.size
    }

    if (idList.size > 1 && idList[newIndex] != currentId) {
        val newChannelId = idList[newIndex]
        sharedViewModel.selectChannel(newChannelId)
    } else if (idList.size == 1) {
    } else {
    }
}

@Composable
fun EpgInfoOverlay(
    channelInfo: ChannelSample?,
    epgInfo: CurrentEpgInfo?
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 48.dp, vertical = 24.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.6f), Color.Black.copy(alpha = 0.9f))))
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AsyncImage(
                model = ImageRequest.Builder(LocalContext.current)
                    .data(channelInfo?.iconUrl)
                    .placeholder(R.drawable.ic_placeholder)
                    .error(R.drawable.ic_placeholder)
                    .crossfade(true)
                    .build(),
                contentDescription = "Logo ${channelInfo?.name}",
                modifier = Modifier
                    .size(54.dp)
                    .clip(RoundedCornerShape(8.dp)),
                contentScale = ContentScale.Fit
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = channelInfo?.name ?: "Cargando...",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                val currentProgram = epgInfo?.programme
                Text(
                    text = if (currentProgram != null) "${currentProgram.getFormattedTimeRange()} ${currentProgram.title}" else "EPG no disponible",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.95f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                val progress = epgInfo?.progress
                if (progress != null) {
                    Spacer(modifier = Modifier.height(5.dp))
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(4.dp),
                        color = Color(0xFF00BCD4),
                        trackColor = Color.Gray.copy(alpha = 0.5f)
                    )
                    Spacer(modifier = Modifier.height(5.dp))
                } else {
                    Spacer(modifier = Modifier.height(9.dp))
                }
                val nextProgram = epgInfo?.nextProgramme
                Text(
                    text = if (nextProgram != null) "A continuación: ${nextProgram.getFormattedTimeRange()} ${nextProgram.title}" else " ",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.8f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@androidx.annotation.OptIn(UnstableApi::class)
@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun PlayerViewComposableWithInput(
    playerManager: PlayerManager,
    focusRequester: FocusRequester,
    setPlayerViewRef: (PlayerView?) -> Unit,
    onDoubleTapOk: () -> Unit,
    onChannelUp: () -> Unit,
    onChannelDown: () -> Unit
) {
    var lastOkPressTime by remember { mutableStateOf(0L) }

    DisposableEffect(Unit) {
        onDispose {
            setPlayerViewRef(null)
        }
    }

    AndroidView(
        factory = { context ->
            PlayerView(context).apply {
                this.player = playerManager.exoPlayer
                useController = false
                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                isFocusable = true
                isFocusableInTouchMode = true
                setPlayerViewRef(this)
            }
        },
        update = { view ->
            view.player = playerManager.exoPlayer
            view.useController = false
            view.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            setPlayerViewRef(view)
        },
        modifier = Modifier
            .fillMaxSize()
            .focusRequester(focusRequester)
            .focusable()
            .onKeyEvent { keyEvent ->
                if (keyEvent.type == KeyEventType.KeyDown) {
                    when (keyEvent.key) {
                        Key.DirectionCenter, Key.Enter, Key.NumPadEnter -> {
                            val currentTime = System.currentTimeMillis()
                            if (currentTime - lastOkPressTime < DOUBLE_TAP_OK_DELAY_MS) {
                                onDoubleTapOk()
                                lastOkPressTime = 0L
                                true
                            } else {
                                lastOkPressTime = currentTime
                                false
                            }
                        }
                        Key.DirectionUp, Key.ChannelUp -> {
                            onChannelUp() // Esto es para ir al canal ANTERIOR en la lista (goNext = false)
                            true
                        }
                        Key.DirectionDown, Key.ChannelDown -> {
                            onChannelDown() // Esto es para ir al canal SIGUIENTE en la lista (goNext = true)
                            true
                        }
                        Key.DirectionLeft -> {
                            playerManager.cycleSubtitleTrack()
                            true
                        }
                        Key.DirectionRight -> {
                            playerManager.cycleAudioTrack(forward = true)
                            true
                        }
                        else -> {
                            false
                        }
                    }
                } else {
                    false
                }
            }
    )
}