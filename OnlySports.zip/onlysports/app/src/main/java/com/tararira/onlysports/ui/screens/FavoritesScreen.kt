package com.tararira.onlysports.ui.screens

// Imports necesarios
import android.util.Log
import androidx.compose.foundation.focusable // Importar focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items // Asegúrate que este import esté
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue // Para collectIsFocusedAsState
import androidx.compose.runtime.remember // Para MutableInteractionSource
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
// Asumiendo que ChannelItem está en el mismo paquete (ui.screens) o importado correctamente
// import com.tararira.onlysports.ui.screens.ChannelItem
import com.tararira.onlysports.data.model.ChannelSample
import com.tararira.onlysports.viewmodel.CurrentEpgInfo
import com.tararira.onlysports.viewmodel.FavoritesUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FavoritesScreen(
    uiState: FavoritesUiState,
    onChannelClick: (ChannelSample) -> Unit,
    onRemoveFavoriteClick: (String?) -> Unit,
    onBackPressed: () -> Unit
) {
    LaunchedEffect(uiState) {
        Log.d("FavoritesScreen", "Recomposing. isLoading: ${uiState.isLoading}, channels: ${uiState.favoriteChannels.size}, epgKeys: ${uiState.currentEpg.keys.size}, error: ${uiState.error}")
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Favoritos") },
                navigationIcon = {
                    IconButton(onClick = onBackPressed) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Atrás")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface,
                    navigationIconContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when {
                uiState.isLoading -> { // Mostrar loading si está cargando
                    CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                }
                uiState.error != null -> { // Mostrar error si existe
                    Text(
                        text = "Error al cargar favoritos:\n${uiState.error}",
                        color = MaterialTheme.colorScheme.error,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.align(Alignment.Center).padding(16.dp)
                    )
                }
                uiState.favoriteChannels.isEmpty() -> { // Si no está cargando y no hay error, pero la lista está vacía
                    Text(
                        text = "No tienes canales favoritos.",
                        color = MaterialTheme.colorScheme.onBackground,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.align(Alignment.Center).padding(16.dp)
                    )
                }
                else -> { // Si hay canales, y no está cargando ni hay error
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(vertical = 0.dp), // El padding y divider están en ChannelItem
                        verticalArrangement = Arrangement.spacedBy(0.dp)
                    ) {
                        items(
                            items = uiState.favoriteChannels,
                            key = { channel -> channel.channelId ?: channel.name } // Usar name como fallback para key
                        ) { channel ->
                            val epgInfo: CurrentEpgInfo? = uiState.currentEpg[channel.channelId]
                            Log.v("FavoritesScreen", "Rendering ${channel.name}, EPG found: ${epgInfo != null}")

                            // --- MANEJO DE FOCO PARA CADA ITEM ---
                            val interactionSource = remember { MutableInteractionSource() }
                            val isItemFocused by interactionSource.collectIsFocusedAsState()
                            // --- FIN MANEJO DE FOCO ---

                            ChannelItem( // Esta es la llamada a tu composable ChannelItem
                                channel = channel,
                                isFavorite = true, // Siempre es favorito aquí
                                currentEpgInfo = epgInfo,
                                onChannelClick = onChannelClick,
                                onFavoriteClick = {
                                    Log.d("FavoritesScreen", "Remove favorite clicked for ${channel.channelId}")
                                    onRemoveFavoriteClick(channel.channelId)
                                },
                                isFocused = isItemFocused, // <--- PASAR ESTADO DE FOCO
                                modifier = Modifier.focusable(interactionSource = interactionSource) // Hacerlo focusable
                            )
                            // El Divider ahora está DENTRO de ChannelItem, por lo que no se necesita aquí.
                        }
                    }
                }
            }
        }
    }
}