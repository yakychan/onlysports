package com.tararira.onlysports.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme // Aún puedes usar la tipografía
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
// import androidx.compose.ui.graphics.Color // No necesario si se usa desde el tema
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.tararira.onlysports.R
import com.tararira.onlysports.ui.theme.SplashBackground // Importa el color definido
import com.tararira.onlysports.ui.theme.SplashContentLight // Importa el color para el contenido

@Composable
fun SplashScreen() {
    Surface(
        modifier = Modifier.fillMaxSize(),
        // Usa el color definido en Color.kt
        color = SplashBackground // <--- CAMBIO AQUÍ
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(id = R.drawable.logo),
                contentDescription = "App Logo",
                modifier = Modifier.size(150.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = stringResource(id = R.string.app_name),
                style = MaterialTheme.typography.headlineMedium,
                // Usa el color de contenido definido en Color.kt
                color = SplashContentLight // <--- CAMBIO AQUÍ
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Bienvenido",
                style = MaterialTheme.typography.titleLarge,
                // Usa el color de contenido definido en Color.kt
                color = SplashContentLight // <--- CAMBIO AQUÍ
            )
        }
    }
}