package com.tararira.onlysports.ui.screens

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.NetworkCheck // Icono diagnóstico
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.tararira.onlysports.data.local.PrefKeys
import com.tararira.onlysports.data.local.SettingsRepository
import com.tararira.onlysports.viewmodel.SettingsViewModel
import com.tararira.onlysports.viewmodel.SettingsUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    // --- Recibe lambda para navegar a Diagnóstico ---
    onNavigateToDiagnostics: () -> Unit,
    onBackPressed: () -> Unit
) {

    val context = LocalContext.current.applicationContext
    // Crear ViewModel usando Factory inline
    val viewModel: SettingsViewModel = viewModel(
        factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                // La factory crea el SettingsRepository que necesita el VM
                return SettingsViewModel(SettingsRepository(context)) as T
            }
        }
    )
    val uiState by viewModel.uiState.collectAsState()
    val localContextForToast = LocalContext.current // Para mostrar Toast

    // Estados locales para inputs, inicializados desde uiState
    var epgUrlInputState by remember(uiState.epgUrl) { mutableStateOf(uiState.epgUrl) }
    var selectedIntervalHoursState by remember(uiState.selectedIntervalHours) { mutableIntStateOf(uiState.selectedIntervalHours) }
    var intervalDropdownExpanded by remember { mutableStateOf(false) }

    // Efecto para mostrar Toast de guardado
    LaunchedEffect(uiState.showSavedMessage) {
        if (uiState.showSavedMessage) {
            Toast.makeText(localContextForToast, "Configuración EPG guardada", Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Configuración") },
                navigationIcon = { IconButton(onClick = onBackPressed) { Icon(Icons.Filled.ArrowBack, "Atrás") } },
                colors = TopAppBarDefaults.topAppBarColors( containerColor = MaterialTheme.colorScheme.surface )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(
            modifier = Modifier.fillMaxSize().padding(paddingValues).padding(32.dp).verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (uiState.isLoading) {
                CircularProgressIndicator() // Muestra carga inicial
            } else {
                // --- Sección Configuración EPG ---
                Text("Configuración EPG", style = MaterialTheme.typography.titleLarge)
                Spacer(modifier = Modifier.height(16.dp))
                Text("URL del Archivo EPG XML:", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = epgUrlInputState,
                    onValueChange = { epgUrlInputState = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("http://... o https://...") },
                    placeholder = { Text(PrefKeys.DEFAULT_EPG_URL.ifEmpty { "URL del XMLTV" }) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(24.dp))
                Text("Actualizar EPG cada:", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(8.dp))
                ExposedDropdownMenuBox(
                    expanded = intervalDropdownExpanded,
                    onExpandedChange = { intervalDropdownExpanded = !intervalDropdownExpanded },
                    modifier = Modifier.fillMaxWidth(0.7f) // Ancho dropdown
                ) {
                    OutlinedTextField( // Campo de texto no editable
                        value = "$selectedIntervalHoursState horas", // Muestra selección local
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = intervalDropdownExpanded) },
                        modifier = Modifier.menuAnchor() // Necesario para vincular
                    )
                    ExposedDropdownMenu(
                        expanded = intervalDropdownExpanded,
                        onDismissRequest = { intervalDropdownExpanded = false } // Cerrar si se toca fuera
                    ) {
                        // Crear item por cada opción de intervalo
                        PrefKeys.EPG_INTERVAL_OPTIONS.forEach { interval ->
                            DropdownMenuItem(
                                text = { Text("$interval horas") },
                                onClick = {
                                    selectedIntervalHoursState = interval // Actualizar estado local
                                    intervalDropdownExpanded = false // Cerrar menú
                                }
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text("(Intervalo de actualización en segundo plano)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f), textAlign = TextAlign.Center)
                Spacer(modifier = Modifier.height(32.dp)) // Más espacio antes de guardar
                // --- Botón Guardar Cambios EPG ---
                Button(
                    onClick = {
                        // Guardar los valores locales actuales usando el ViewModel
                        viewModel.saveEpgSettings(epgUrlInputState, selectedIntervalHoursState)
                    },
                    modifier = Modifier.fillMaxWidth(0.6f) // Ancho botón
                ) {
                    Text("Guardar Config. EPG")
                }
                // --- Fin Sección EPG ---


                // --- Sección Diagnóstico ---
                Divider(modifier = Modifier.padding(vertical = 48.dp)) // Separador grande
                Text("Herramientas", style = MaterialTheme.typography.titleLarge)
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = onNavigateToDiagnostics, // <-- Llamar a la lambda para navegar
                    modifier = Modifier.fillMaxWidth(0.6f)
                ) {
                    Icon(Icons.Filled.NetworkCheck, null, Modifier.size(ButtonDefaults.IconSize))
                    Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                    Text("Comprobar Canales")
                }
                // --- Fin Sección Diagnóstico ---

            } // Fin else (no isLoading)
        } // Fin Column
    } // Fin Scaffold
}

// Quitar helper getFileNameFromUri si no se usa M3U local