package com.tararira.onlysports.ui.screens

import android.content.Context
import android.util.Log // Importar Log
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.tararira.onlysports.R
import com.tararira.onlysports.auth.AuthManager
import com.tararira.onlysports.data.remote.ApiService
import com.tararira.onlysports.data.remote.RetrofitClient
import com.tararira.onlysports.data.repository.UserRepository
import com.tararira.onlysports.viewmodel.LoginViewModel
import kotlinx.coroutines.flow.collectLatest

class LoginViewModelFactory(
    private val userRepository: UserRepository,
    private val authManager: AuthManager
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(LoginViewModel::class.java)) {
            return LoginViewModel(userRepository, authManager) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class for LoginViewModelFactory")
    }
}


@OptIn(ExperimentalMaterial3Api::class, ExperimentalComposeUiApi::class)
@Composable
fun LoginScreen(
    onLoginSuccess: () -> Unit
) {
    val context = LocalContext.current.applicationContext
    val apiService = RetrofitClient.apiService
    val userRepository = remember { UserRepository(apiService) }
    val authManager = remember { AuthManager(context) }

    val loginViewModel: LoginViewModel = viewModel(
        factory = LoginViewModelFactory(userRepository, authManager)
    )

    val uiState = loginViewModel.uiState
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val localContextForToast = LocalContext.current
    val logTag = "LoginScreen" // Tag para Logcat

    // Efecto para escuchar el resultado del login desde el ViewModel
    LaunchedEffect(key1 = Unit) {
        Log.d(logTag, "LaunchedEffect started, collecting loginResultFlow...")
        loginViewModel.loginResultFlow.collectLatest { result ->
            keyboardController?.hide()
            when (result) {
                is LoginViewModel.LoginResult.Success -> {
                    Log.i(logTag, "Received LoginResult.Success. Calling onLoginSuccess callback.")
                    // Toast.makeText(localContextForToast, "Login exitoso!", Toast.LENGTH_SHORT).show() // Opcional
                    onLoginSuccess()
                }
                is LoginViewModel.LoginResult.Error -> {
                    Log.w(logTag, "Received LoginResult.Error: ${result.message}")
                    Toast.makeText(localContextForToast, result.message, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 48.dp, vertical = 32.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("Bienvenido", style = MaterialTheme.typography.headlineMedium)
            Spacer(modifier = Modifier.height(16.dp))

            Image(
                painter = painterResource(id = R.drawable.logo),
                contentDescription = "Logo de la App",
                modifier = Modifier.size(120.dp)
            )
            Spacer(modifier = Modifier.height(32.dp))

            OutlinedTextField(
                value = loginViewModel.usernameInput,
                onValueChange = { loginViewModel.usernameInput = it },
                label = { Text("Usuario") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Text,
                    imeAction = ImeAction.Next
                ),
                keyboardActions = KeyboardActions(
                    onNext = { focusManager.moveFocus(FocusDirection.Down) }
                ),
                modifier = Modifier.fillMaxWidth(0.8f),
                isError = uiState.errorMessage?.contains("Usuario") == true
            )
            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = loginViewModel.passwordInput,
                onValueChange = { loginViewModel.passwordInput = it },
                label = { Text("Contraseña") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(
                    onDone = {
                        keyboardController?.hide()
                        if (!uiState.isLoading) {
                            Log.d(logTag,"Keyboard Done action -> triggering login click")
                            loginViewModel.onLoginClicked()
                        }
                    }
                ),
                modifier = Modifier.fillMaxWidth(0.8f),
                isError = uiState.errorMessage?.contains("contraseña") == true
            )
            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(0.8f),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Start
            ) {
                Checkbox(
                    checked = loginViewModel.rememberMeChecked,
                    onCheckedChange = { loginViewModel.rememberMeChecked = it }
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Recordar sesión", modifier = Modifier.clickable { loginViewModel.rememberMeChecked = !loginViewModel.rememberMeChecked })
            }
            Spacer(modifier = Modifier.height(24.dp))

            if (uiState.isLoading) {
                Log.d(logTag, "Displaying CircularProgressIndicator (isLoading=true)")
                CircularProgressIndicator(modifier = Modifier.size(48.dp))
            } else {
                Log.d(logTag, "Displaying Login Button (isLoading=false)")
                Button(
                    onClick = {
                        keyboardController?.hide()
                        Log.d(logTag,"Login Button onClick -> triggering login click")
                        loginViewModel.onLoginClicked()
                    },
                    modifier = Modifier
                        .fillMaxWidth(0.8f)
                        .height(48.dp)
                ) {
                    Text("Iniciar Sesión")
                }
            }

            // Mostrar mensaje de error de validación del ViewModel (si no se emitió al flow)
            uiState.errorMessage?.let {
                Log.w(logTag, "Displaying error message from uiState: $it")
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = it,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(0.8f)
                )
            }
        }
    }
}