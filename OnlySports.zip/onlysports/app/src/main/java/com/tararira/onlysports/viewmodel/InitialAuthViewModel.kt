package com.tararira.onlysports.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import com.tararira.onlysports.auth.AuthManager
import com.tararira.onlysports.data.repository.UserRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class InitialAuthViewModel(
    private val authManager: AuthManager,
    private val userRepository: UserRepository
) : ViewModel() {

    private val _authState = MutableStateFlow<AuthState>(AuthState.Loading)
    val authState: StateFlow<AuthState> = _authState.asStateFlow()
    private val logTag = "InitialAuthViewModel"

    sealed class AuthState {
        object Loading : AuthState()
        object Authenticated : AuthState()
        object Unauthenticated : AuthState()
        data class Error(val message: String) : AuthState()
    }

    init {
        Log.i(logTag, "!!!!!!!!!! IAViewModel: INIT - Bypassing login. Setting state to Authenticated. !!!!!!!!!!")
        _authState.value = AuthState.Authenticated
        Log.i(logTag, "!!!!!!!!!! IAViewModel: INIT - AuthState is now: ${_authState.value::class.simpleName} !!!!!!!!!!")
    }

    // La función original validateInitialSession() y otras lógicas de validación
    // podrían comentarse o eliminarse si ya no son necesarias.
    // Por ahora, solo modificamos el init para el bypass.

    override fun onCleared() {
        super.onCleared()
        Log.i(logTag, "ViewModel cleared.")
    }
}