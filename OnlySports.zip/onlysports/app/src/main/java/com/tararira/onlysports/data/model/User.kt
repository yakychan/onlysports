package com.tararira.onlysports.data.model

import android.annotation.SuppressLint
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@SuppressLint("UnsafeOptInUsageError")
@Serializable
data class UserCredentials(
    @SerialName("username") val username: String,
    // Almacenamos el hash generado por password_hash() de PHP
    @SerialName("passwordHash") val passwordHash: String,
    // PHP password_hash con PASSWORD_DEFAULT incluye el algo y la salt dentro del propio hash,
    // por lo que no necesitamos un campo 'salt' separado aquí si usamos esa función en PHP.
    // @SerialName("salt") val salt: String // <-- No necesario si PHP usa password_hash() moderno
)

@SuppressLint("UnsafeOptInUsageError")
@Serializable
data class UserListContainer(
    // La clave raíz en tu JSON ("users" según el script PHP)
    @SerialName("users") val users: List<UserCredentials>
)