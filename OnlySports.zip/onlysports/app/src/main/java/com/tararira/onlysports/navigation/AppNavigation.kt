package com.tararira.onlysports.navigation

import android.content.Context
import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.layout.Box // Asegurar import
import androidx.compose.foundation.layout.fillMaxSize // Asegurar import
import androidx.compose.material3.CircularProgressIndicator // Asegurar import
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment // Asegurar import
import androidx.compose.ui.Modifier // Asegurar import
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
// import androidx.lifecycle.viewModelScope // No se usa directamente aquí
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.tararira.onlysports.auth.AuthManager
import com.tararira.onlysports.data.local.FavoritesRepository
import com.tararira.onlysports.data.local.SettingsRepository
import com.tararira.onlysports.data.remote.ApiService
import com.tararira.onlysports.data.remote.RetrofitClient
import com.tararira.onlysports.data.repository.ChannelRepository
import com.tararira.onlysports.data.repository.UserRepository
import com.tararira.onlysports.ui.screens.*
import com.tararira.onlysports.viewmodel.* // Asegura que InitialAuthViewModel está importado
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// Screen sealed class (Debe estar en /navigation/Screen.kt)
// Si no, descomenta la de abajo y borra la del archivo Screen.kt
/*
sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Login : Screen("login")
    object Main : Screen("main")
    object ChannelList : Screen("channel_list")
    object Favorites : Screen("favorites")
    object Settings : Screen("settings")
    object Player : Screen("player")
    object CodeEntry : Screen("code_entry")
    object ChannelDiagnostics : Screen("channel_diagnostics")
}
*/


@Composable
fun AppNavigation(
    navController: NavHostController,
    isPhone: Boolean
) {
    val context = LocalContext.current.applicationContext
    val logTag = "AppNavigation"

    // --- Repositorios y Gestores ---
    val apiService = RetrofitClient.apiService
    val settingsRepository = remember { SettingsRepository(context) }
    val channelRepository = remember {
        Log.i(logTag, ">>> CREATING SHARED ChannelRepository INSTANCE <<<")
        ChannelRepository(context, apiService)
    }
    val favoritesRepository = remember { FavoritesRepository(context) }
    val authManager = remember { AuthManager(context) }
    val userRepository = remember { UserRepository(apiService) }

    // --- ViewModels ---
    val sharedNavViewModel: SharedNavViewModel = viewModel()
    val initialAuthViewModel: InitialAuthViewModel = viewModel(
        factory = InitialAuthViewModelFactory(authManager, userRepository) // Usar la factory definida al final
    )
    val diagnosticsViewModel: ChannelDiagnosticsViewModel = viewModel(
        factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                Log.d(logTag, "Creating ChannelDiagnosticsViewModel using SHARED ChannelRepository.")
                return ChannelDiagnosticsViewModel(channelRepository) as T
            }
        }
    )

    val authValidationState by initialAuthViewModel.authState.collectAsStateWithLifecycle()
    var showSplashScreenVisual by remember { mutableStateOf(true) } // Para controlar la duración visual

    LaunchedEffect(key1 = Unit) {
        Log.d(logTag, "Splash Visual LaunchedEffect: Waiting 2000ms...")
        delay(2000) // Duración mínima del splash visual
        showSplashScreenVisual = false
        Log.d(logTag, "Splash visual finished. Current authValidationState: ${authValidationState::class.simpleName}")
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    var lastOnResumeValidationTime by remember { mutableLongStateOf(0L) }
    val minIntervalBetweenResumeValidationsMs = 5 * 60 * 1000L // 5 minutos

    DisposableEffect(lifecycleOwner, authValidationState) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                Log.i(logTag, "Lifecycle.Event.ON_RESUME detected.")
                val currentTime = System.currentTimeMillis()

                // --- ESTA LLAMADA DEBE ESTAR COMENTADA MIENTRAS InitialAuthViewModel NO LA TENGA PÚBLICA ---
                if (!showSplashScreenVisual &&
                    authValidationState !is InitialAuthViewModel.AuthState.Loading &&
                    (currentTime - lastOnResumeValidationTime > minIntervalBetweenResumeValidationsMs || lastOnResumeValidationTime == 0L )) {

                    Log.i(logTag, "ON_RESUME: Conditions met. Attempting to call initialAuthViewModel.validateInitialSession().")
                    lastOnResumeValidationTime = currentTime
                    // initialAuthViewModel.validateInitialSession() // <--- COMENTAR ESTA LÍNEA PARA LA PRUEBA MÍNIMA
                } else {
                    Log.d(logTag, "ON_RESUME: Skipping re-validation (o función no disponible en VM de prueba). showSplashVisual=$showSplashScreenVisual, AuthState=${authValidationState::class.simpleName}, TimeSinceLastResumeValidation=${currentTime - lastOnResumeValidationTime}ms")
                }
                // --- FIN COMENTARIO ---
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            Log.d(logTag, "LifecycleObserver for ON_RESUME removed.")
        }
    }

    if (showSplashScreenVisual) {
        Log.d(logTag, "Displaying SplashScreen (showSplashScreenVisual is true)")
        SplashScreen()
    } else {
        when (authValidationState) {
            is InitialAuthViewModel.AuthState.Loading -> {
                Log.d(logTag, "Auth state is Loading (after visual splash). Displaying CircularProgressIndicator.")
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
            is InitialAuthViewModel.AuthState.Authenticated -> {
                Log.i(logTag, "Auth state is Authenticated. Starting NavHost with Main.")
                NavHost(navController = navController, startDestination = Screen.Main.route) {
                    addAppScreens(navController,sharedNavViewModel,authManager,diagnosticsViewModel,channelRepository,favoritesRepository,settingsRepository,context)
                }
            }
            else -> { // Unauthenticated o Error
                if (authValidationState is InitialAuthViewModel.AuthState.Error) {
                    Log.e(logTag, "Auth state is Error: ${(authValidationState as InitialAuthViewModel.AuthState.Error).message}")
                }
                Log.i(logTag, "Auth state is Unauthenticated or Error. Starting NavHost with Login.")
                NavHost(navController = navController, startDestination = Screen.Login.route) {
                    addAppScreens(navController,sharedNavViewModel,authManager,diagnosticsViewModel,channelRepository,favoritesRepository,settingsRepository,context)
                }
            }
        }
    }
    Log.d(logTag, "========== AppNavigation Composable END (Recomposition) ==========")
}


// --- Función auxiliar addAppScreens ---
private fun NavGraphBuilder.addAppScreens(
    navController: NavHostController,
    sharedNavViewModel: SharedNavViewModel,
    authManager: AuthManager,
    diagnosticsViewModel: ChannelDiagnosticsViewModel,
    channelRepository: ChannelRepository,
    favoritesRepository: FavoritesRepository,
    settingsRepository: SettingsRepository,
    context: Context
) {
    val logTagFunc = "AppNavigationScreens"

    composable(Screen.Login.route) {
        Log.i(logTagFunc, "NavHost: Defining Composable for -> LoginScreen")
        LoginScreen(
            onLoginSuccess = {
                Log.i(logTagFunc, "Login SUCCESS. Navigating to Main, popping Login.")
                navController.navigate(Screen.Main.route) {
                    popUpTo(Screen.Login.route) { inclusive = true }
                    launchSingleTop = true
                }
            }
        )
    }

    composable(Screen.Main.route) {
        Log.i(logTagFunc, "NavHost: Defining Composable for -> MainScreen")
        MainScreen(
            onNavigateToChannels = { navController.navigate(Screen.ChannelList.route) },
            onNavigateToFavorites = { navController.navigate(Screen.Favorites.route) },
            onNavigateToSettings = { navController.navigate(Screen.Settings.route) }
        )
    }

    composable(Screen.ChannelList.route) {
        Log.i(logTagFunc, "NavHost: Defining Composable for -> ChannelListScreen")
        val viewModel: ChannelViewModel = viewModel(
            factory = ChannelViewModelFactory(channelRepository, favoritesRepository)
        )
        val uiState by viewModel.uiState.collectAsStateWithLifecycle()
        val uniqueIds by viewModel.uniqueOrderedChannelIds.collectAsStateWithLifecycle()

        ChannelListScreen(
            uiState = uiState,
            sharedViewModel = sharedNavViewModel,
            onChannelClick = { channel ->
                val id = channel.channelId
                if (!id.isNullOrBlank()) {
                    Log.d(logTagFunc, "ChannelList: Clicked ${channel.name}, ID: $id. Navigating to Player.")
                    sharedNavViewModel.updateChannelIdList(uniqueIds)
                    sharedNavViewModel.selectChannel(id)
                    navController.navigate(Screen.Player.route)
                } else {
                    Log.w(logTagFunc, "ChannelList: Clicked channel with invalid ID.")
                    Toast.makeText(context, "ID de canal inválido.", Toast.LENGTH_SHORT).show()
                }
            },
            onFavoriteClick = { id -> viewModel.toggleFavorite(id) },
            onBackPressed = { navController.popBackStack() }
        )
    }

    composable(Screen.Favorites.route) {
        Log.i(logTagFunc, "NavHost: Defining Composable for -> FavoritesScreen")
        val viewModel: FavoritesViewModel = viewModel(
            factory = FavoritesViewModelFactory(channelRepository, favoritesRepository)
        )
        val uiState by viewModel.uiState.collectAsStateWithLifecycle()
        val favoriteIds = remember(uiState.favoriteChannels) {
            uiState.favoriteChannels.mapNotNull { it.channelId }
        }

        FavoritesScreen(
            uiState = uiState,
            onChannelClick = { channel ->
                val id = channel.channelId
                if (!id.isNullOrBlank()) {
                    Log.d(logTagFunc, "Favorites: Clicked ${channel.name}, ID: $id. Navigating to Player.")
                    sharedNavViewModel.updateChannelIdList(favoriteIds)
                    sharedNavViewModel.selectChannel(id)
                    navController.navigate(Screen.Player.route)
                } else {
                    Log.w(logTagFunc, "Favorites: Clicked channel with invalid ID.")
                    Toast.makeText(context, "ID de canal inválido.", Toast.LENGTH_SHORT).show()
                }
            },
            onRemoveFavoriteClick = { id -> viewModel.removeFromFavorites(id) },
            onBackPressed = { navController.popBackStack() }
        )
    }

    composable(Screen.Settings.route) {
        Log.i(logTagFunc, "NavHost: Defining Composable for -> SettingsScreen")
        SettingsScreen(
            onNavigateToDiagnostics = { navController.navigate(Screen.CodeEntry.route) },
            onBackPressed = { navController.popBackStack() }
        )
    }

    composable(Screen.CodeEntry.route) {
        Log.i(logTagFunc, "NavHost: Defining Composable for -> CodeEntryScreen")
        CodeEntryScreen(
            correctCode = diagnosticsViewModel.secretCode,
            onCodeVerified = {
                navController.navigate(Screen.ChannelDiagnostics.route) {
                    popUpTo(Screen.CodeEntry.route) { inclusive = true }
                }
            },
            onCancel = { navController.popBackStack() }
        )
    }

    composable(Screen.ChannelDiagnostics.route) {
        Log.i(logTagFunc, "NavHost: Defining Composable for -> ChannelDiagnosticsScreen")
        ChannelDiagnosticsScreen(
            viewModel = diagnosticsViewModel,
            onBackPressed = { navController.popBackStack() }
        )
    }

    composable(Screen.Player.route) {
        Log.i(logTagFunc, "NavHost: Defining Composable for -> PlayerScreen")
        val playerViewModel: PlayerViewModel = viewModel(
            factory = PlayerViewModelSimpleFactory(sharedNavViewModel, channelRepository)
        )
        val uiState by playerViewModel.uiState.collectAsStateWithLifecycle()
        PlayerScreen(
            uiState = uiState,
            sharedViewModel = sharedNavViewModel,
            onPlaybackError = { playerViewModel.setPlaybackError(it) },
            onFatalError = { error -> playerViewModel.setFatalError(error ?: "Error fatal desconocido") },
            onBackPressed = {
                navController.popBackStack()
            }
        )
    }
}

// --- ViewModel Factories (Completas) ---
class InitialAuthViewModelFactory(
    private val authManager: AuthManager,
    private val userRepository: UserRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(InitialAuthViewModel::class.java)) {
            return InitialAuthViewModel(authManager, userRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class for InitialAuthViewModelFactory: ${modelClass.name}")
    }
}

class PlayerViewModelSimpleFactory(private val snvm:SharedNavViewModel,private val cr:ChannelRepository):ViewModelProvider.Factory{@Suppress("UNCHECKED_CAST")override fun <T:ViewModel> create(c:Class<T>):T{if(c.isAssignableFrom(PlayerViewModel::class.java))return PlayerViewModel(snvm,cr)as T;throw IllegalArgumentException("Unknown VM class for PlayerViewModel: ${c.name}")}}
class ChannelViewModelFactory(private val cr:ChannelRepository,private val fr:FavoritesRepository):ViewModelProvider.Factory{@Suppress("UNCHECKED_CAST")override fun <T:ViewModel> create(modelClass: Class<T>):T{if(modelClass.isAssignableFrom(ChannelViewModel::class.java))return ChannelViewModel(cr,fr)as T;throw IllegalArgumentException("Unknown VM class for ChannelViewModel: ${modelClass.name}")}}
class FavoritesViewModelFactory(private val cr:ChannelRepository,private val fr:FavoritesRepository):ViewModelProvider.Factory{@Suppress("UNCHECKED_CAST")override fun <T:ViewModel> create(modelClass: Class<T>):T{if(modelClass.isAssignableFrom(FavoritesViewModel::class.java))return FavoritesViewModel(cr,fr)as T;throw IllegalArgumentException("Unknown VM class for FavoritesViewModel: ${modelClass.name}")}}