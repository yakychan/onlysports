package com.tararira.onlysports

import android.app.Application
import android.content.Context
import android.util.Log
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.work.*
import com.tararira.onlysports.worker.SessionValidationWorker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import java.util.concurrent.TimeUnit

private const val USER_PREFERENCES_NAME = "onlysports_app_prefs"

val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

val Context.AppPrefsDataStore: DataStore<Preferences> by preferencesDataStore(
    name = USER_PREFERENCES_NAME,
    scope = applicationScope
)

class OnlySportsApplication : Application() {
    private val logTag = "OnlySportsApplication"
    override fun onCreate() {
        super.onCreate()
        Log.i(logTag, "Application onCreate: Scheduling periodic worker.")
        scheduleSessionValidationWorker(applicationContext)
    }

    private fun scheduleSessionValidationWorker(context: Context) {
        Log.i(logTag,"Attempting to schedule Periodic Session Validation Worker...");val constraints=Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();val periodicWorkRequest=PeriodicWorkRequestBuilder<SessionValidationWorker>(repeatInterval=23,repeatIntervalTimeUnit=TimeUnit.HOURS).setConstraints(constraints).setBackoffCriteria(BackoffPolicy.EXPONENTIAL,WorkRequest.MIN_BACKOFF_MILLIS,TimeUnit.MILLISECONDS).addTag("SessionValidation").build();WorkManager.getInstance(context).enqueueUniquePeriodicWork("SESSION_VALIDATION_WORKER",ExistingPeriodicWorkPolicy.KEEP,periodicWorkRequest);Log.i(logTag,"Periodic session validation worker enqueued with policy KEEP.")
    }
}