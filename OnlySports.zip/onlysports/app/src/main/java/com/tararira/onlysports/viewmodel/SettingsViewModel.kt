package com.tararira.onlysports.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tararira.onlysports.data.local.PrefKeys
import com.tararira.onlysports.data.local.SettingsRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

// Estado de la UI solo para Configuración EPG
data class SettingsUiState(
    val epgUrl: String = PrefKeys.DEFAULT_EPG_URL,
    val selectedIntervalHours: Int = PrefKeys.DEFAULT_EPG_REFRESH_INTERVAL_HOURS,
    val availableIntervals: List<Int> = PrefKeys.EPG_INTERVAL_OPTIONS,
    val isLoading: Boolean = true,
    val showSavedMessage: Boolean = false
)

class SettingsViewModel(
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val logTag = "SettingsViewModel"
    private val _showSavedMessage = MutableStateFlow(false)

    // Combinar solo los flows de EPG
    val uiState: StateFlow<SettingsUiState> = combine(
        settingsRepository.epgUrlFlow,
        settingsRepository.epgRefreshIntervalHoursFlow,
        _showSavedMessage
    ) { url, interval, showMsg ->
        SettingsUiState(
            epgUrl = url,
            selectedIntervalHours = interval,
            availableIntervals = PrefKeys.EPG_INTERVAL_OPTIONS,
            isLoading = false,
            showSavedMessage = showMsg
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = SettingsUiState(isLoading = true)
    )

    // Guardar configuración EPG
    fun saveEpgSettings(newEpgUrl: String, newEpgInterval: Int) {
        Log.d(logTag, "Request save EPG settings - URL: $newEpgUrl, Interval: $newEpgInterval")
        viewModelScope.launch {
            settingsRepository.saveEpgSettings(newEpgUrl, newEpgInterval)
            _showSavedMessage.value = true
            kotlinx.coroutines.delay(2000)
            _showSavedMessage.value = false
        }
    }
}