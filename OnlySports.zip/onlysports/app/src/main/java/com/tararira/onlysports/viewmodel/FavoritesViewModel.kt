package com.tararira.onlysports.viewmodel

import android.util.Log // Añadir Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tararira.onlysports.data.epg.model.EpgProgramme // Importar EpgProgramme
import com.tararira.onlysports.data.local.FavoritesRepository
import com.tararira.onlysports.data.model.ChannelSample
import com.tararira.onlysports.data.repository.ChannelRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.Duration // Importar para cálculo EPG
import java.time.OffsetDateTime // Importar para cálculo EPG
import java.time.ZoneId // Importar para cálculo EPG

// --- UiState MODIFICADO: Añadir currentEpg ---
data class FavoritesUiState(
    val favoriteChannels: List<ChannelSample> = emptyList(),
    val currentEpg: Map<String, CurrentEpgInfo> = emptyMap(), // <-- AÑADIDO
    val isLoading: Boolean = false,
    val error: String? = null
)
// --- Fin UiState Modificado ---

class FavoritesViewModel(
    private val channelRepository: ChannelRepository,
    private val favoritesRepository: FavoritesRepository
) : ViewModel() {

    private val _isLoading = MutableStateFlow(false)
    private val _error = MutableStateFlow<String?>(null)
    private val logTag = "FavoritesViewModel" // Para logs

    // --- Flujo de datos EPG crudos (igual que en ChannelViewModel) ---
    private val _rawEpgData: StateFlow<Map<String, List<EpgProgramme>>?> = channelRepository.epgDataFlow

    // --- StateFlow final UI MODIFICADO ---
    val uiState: StateFlow<FavoritesUiState> = combine(
        // 1. Obtener IDs de favoritos
        favoritesRepository.favoriteChannelIdsFlow,
        // 2. Obtener datos crudos del EPG
        _rawEpgData,
        // 3. Estados de carga y error
        _isLoading,
        _error
    ) { favoriteIds, rawEpgMap, isLoading, error -> // Combinar 4 flows

        // Si no hay favoritos, devolver estado vacío rápidamente
        if (favoriteIds.isEmpty()) {
            Log.d(logTag, "No favorite IDs found. Emitting empty state.")
            FavoritesUiState(isLoading = false, error = null)
        } else {
            Log.d(logTag, "Processing ${favoriteIds.size} favorite IDs.")
            // 4. Obtener detalles de los canales favoritos (esto podría ser una llamada suspendida)
            //    Aquí asumimos que ChannelRepository puede manejar esto eficientemente.
            //    Una alternativa es usar flatMapLatest como antes, pero combinar es más simple aquí.
            val channelsResult = channelRepository.getFavoriteChannelDetails(favoriteIds)
            val favoriteChannelsList = channelsResult.getOrNull() ?: emptyList()
            val fetchError = channelsResult.exceptionOrNull()?.message

            // 5. Calcular EPG Info SÓLO para los canales favoritos obtenidos
            val currentEpgForFavorites = calculateCurrentAndNextEpgWithProgress(
                favoriteChannelsList, // Pasar la lista de canales favoritos
                rawEpgMap ?: emptyMap() // Pasar datos EPG crudos
            )
            Log.d(logTag, "Calculated EPG for ${currentEpgForFavorites.size} favorites.")

            // 6. Construir el estado final
            FavoritesUiState(
                favoriteChannels = favoriteChannelsList,
                currentEpg = currentEpgForFavorites, // <-- Pasar EPG calculado
                // Mostrar estado isLoading si la carga inicial de detalles aún no termina
                // (Considerar si isLoading debe basarse solo en channelRepository.getFavoriteChannelDetails)
                isLoading = isLoading,
                // Mostrar error de fetch o el error general
                error = fetchError ?: error
            )
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = FavoritesUiState(isLoading = true) // Iniciar como cargando
    )
    // --- Fin StateFlow UI Modificado ---


    // --- Lógica para calcular EPG (Duplicada/Adaptada de ChannelViewModel) ---
    // ¡IMPORTANTE! Sería mejor extraer esta lógica a un lugar común (ej. un UseCase o Helper)
    // para evitar duplicación con ChannelViewModel.
    private fun calculateCurrentAndNextEpgWithProgress(
        channels: List<ChannelSample>, // Recibe la lista de canales a procesar
        rawEpg: Map<String, List<EpgProgramme>>
    ): Map<String, CurrentEpgInfo> {
        if (channels.isEmpty() || rawEpg.isEmpty()) return emptyMap()
        val currentEpgMap = mutableMapOf<String, CurrentEpgInfo>()
        val now = OffsetDateTime.now(ZoneId.systemDefault())
        // Procesar solo los IDs de los canales pasados (favoritos en este caso)
        val channelIdsToProcess = channels.mapNotNull { it.channelId }.toSet()

        Log.v(logTag, "Calculating EPG for IDs: $channelIdsToProcess") // Log Verbose

        channelIdsToProcess.forEach { channelId ->
            val programsForChannel = rawEpg[channelId]?.sortedBy { it.start }
            val currentProgram = programsForChannel?.find { it.isAiringAt(now) }
            var progress: Float? = null
            var nextProgram: EpgProgramme? = null

            if (currentProgram != null) {
                try {
                    val totalDuration = Duration.between(currentProgram.start, currentProgram.stop)
                    val elapsedDuration = Duration.between(currentProgram.start, now)
                    if (!totalDuration.isZero && !totalDuration.isNegative && !elapsedDuration.isNegative) {
                        progress = (elapsedDuration.toMillis().toFloat() / totalDuration.toMillis().toFloat()).coerceIn(0.0f, 1.0f)
                    }
                } catch (e: Exception) {
                    Log.w(logTag, "Error calculating EPG progress for fav $channelId: ${e.message}")
                    progress = null
                }
                val currentIndex = programsForChannel.indexOf(currentProgram)
                if (currentIndex != -1 && currentIndex + 1 < programsForChannel.size) {
                    nextProgram = programsForChannel[currentIndex + 1]
                }
            } else {
                nextProgram = programsForChannel?.firstOrNull { !it.start.isBefore(now) }
            }
            currentEpgMap[channelId] = CurrentEpgInfo(currentProgram, progress, nextProgram)
        }
        return currentEpgMap
    }
    // --- Fin Lógica EPG ---


    // --- Quitar Favorito (sin cambios) ---
    fun removeFromFavorites(channelId: String?) {
        if (channelId.isNullOrBlank()) {
            Log.w(logTag, "removeFromFavorites called with null/blank ID")
            return
        }
        viewModelScope.launch {
            Log.d(logTag, "Removing favorite: $channelId")
            favoritesRepository.removeFavorite(channelId)
            // El uiState se actualizará automáticamente porque favoriteChannelIdsFlow emitirá un nuevo valor
        }
    }
    // --- Fin Quitar Favorito ---

    // Método fetchFavoriteDetailsFlow ya no es necesario con la nueva estructura de combine
    /*
    private fun fetchFavoriteDetailsFlow(ids: Set<String>) = flow { ... }
    */
}