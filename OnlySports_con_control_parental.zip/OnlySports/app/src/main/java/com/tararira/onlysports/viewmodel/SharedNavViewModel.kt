package com.tararira.onlysports.viewmodel

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

// ViewModel para compartir datos de navegación entre pantallas
class SharedNavViewModel : ViewModel() {

    // ID del canal actualmente seleccionado para reproducción
    private val _selectedChannelId = MutableStateFlow<String?>(null)
    val selectedChannelId = _selectedChannelId.asStateFlow()

    // Lista de IDs de canales en el orden en que se mostraron antes de ir al reproductor
    // Usado para navegación siguiente/anterior en el reproductor
    private val _currentChannelIdList = MutableStateFlow<List<String>>(emptyList())
    val currentChannelIdList = _currentChannelIdList.asStateFlow()

    // Guarda el último ID que se intentó reproducir (incluso si falló)
    private val _lastPlayedChannelId = MutableStateFlow<String?>(null)
    val lastPlayedChannelId = _lastPlayedChannelId.asStateFlow()

    // Flow para indicar que se seleccionó un NUEVO canal
    private val _newChannelSelectedEvent = MutableStateFlow(false)
    val newChannelSelectedEvent = _newChannelSelectedEvent.asStateFlow()

    // ID del canal al que se debe restaurar el foco en ChannelListScreen
    private val _channelToFocusAfterReturnInList = MutableStateFlow<String?>(null)
    val channelToFocusAfterReturnInList = _channelToFocusAfterReturnInList.asStateFlow()


    fun selectChannel(channelId: String?) {
        val previousId = _selectedChannelId.value
        _selectedChannelId.value = channelId
        if (channelId != null) {
            _lastPlayedChannelId.value = channelId
            if (channelId != previousId) {
                _newChannelSelectedEvent.value = true
            }
        }
    }

    fun clearChannelId() {
        _selectedChannelId.value = null
    }

    fun updateChannelIdList(ids: List<String>) {
        _currentChannelIdList.value = ids
    }

    fun consumeNewChannelSelectedEvent() {
        _newChannelSelectedEvent.value = false
    }

    /**
     * Llamado desde PlayerScreen al salir, para indicar a qué canal
     * debe intentar volver el foco ChannelListScreen.
     * Usa el lastPlayedChannelId como la fuente de verdad.
     */
    fun requestFocusOnLastPlayedChannelInList() {
        _channelToFocusAfterReturnInList.value = _lastPlayedChannelId.value
    }

    /**
     * Llamado por ChannelListScreen una vez que ha intentado restaurar el foco.
     */
    fun consumeFocusRequestForList() {
        _channelToFocusAfterReturnInList.value = null
    }
}