package com.tararira.onlysports.ui.screens

import android.util.Log
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
// import androidx.compose.ui.platform.LocalContext // No necesario si el VM se pasa
// import androidx.lifecycle.ViewModel // No necesario
// import androidx.lifecycle.ViewModelProvider // No necesario
// import androidx.lifecycle.viewmodel.compose.viewModel // No necesario
// import com.tararira.onlysports.data.remote.RetrofitClient // No necesario
// import com.tararira.onlysports.data.repository.ChannelRepository // No necesario
import com.tararira.onlysports.viewmodel.ChannelCheckStatus
import com.tararira.onlysports.viewmodel.ChannelDiagnosticInfo
import com.tararira.onlysports.viewmodel.ChannelDiagnosticsViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChannelDiagnosticsScreen(
    viewModel: ChannelDiagnosticsViewModel, // <--- ACEPTAR EL VIEWMODEL PASADO DESDE AppNavigation
    onBackPressed: () -> Unit
) {
    // El ViewModel ahora se recibe como parámetro, no se crea aquí.
    val uiState by viewModel.uiState.collectAsState()
    val logTag = "ChannelDiagnosticsScreen" // Tag para logs

    val lazyListState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()
    var lastScrolledIndex by remember { mutableIntStateOf(-1) }

    LaunchedEffect(Unit) {
        if (uiState.channelChecks.isEmpty() && !uiState.isChecking && uiState.error == null) {
            Log.d(logTag, "Initial state: No checks, not checking, no error. Starting channel check.")
            viewModel.startChannelCheck()
        } else {
            Log.d(logTag, "Initial state: Not starting check. isChecking=${uiState.isChecking}, error=${uiState.error}, checksEmpty=${uiState.channelChecks.isEmpty()}")
        }
    }

    LaunchedEffect(uiState.channelChecks, uiState.isChecking) {
        if (!uiState.isChecking) {
            lastScrolledIndex = -1
            return@LaunchedEffect
        }
        val targetIndex = uiState.channelChecks.indexOfFirst {
            it.status == ChannelCheckStatus.CHECKING
        }.takeIf { it != -1 } ?: uiState.channelChecks.indexOfLast {
            it.status != ChannelCheckStatus.PENDING
        }

        if (targetIndex != -1 && targetIndex > lastScrolledIndex) {
            Log.d("DiagScroll", "Target index for scroll: $targetIndex")
            coroutineScope.launch {
                try {
                    // Asegurar que el índice es válido antes de intentar scrollear
                    if (targetIndex >= 0 && targetIndex < lazyListState.layoutInfo.totalItemsCount) {
                        lazyListState.animateScrollToItem(index = targetIndex)
                        lastScrolledIndex = targetIndex
                    } else {
                        Log.w("DiagScroll", "Attempted to scroll to out-of-bounds index: $targetIndex. Total items: ${lazyListState.layoutInfo.totalItemsCount}")
                    }
                } catch (e: Exception) {
                    Log.e("DiagScroll", "Error during animateScrollToItem", e)
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Diagnóstico de Canales") },
                navigationIcon = {
                    IconButton(onClick = onBackPressed) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Atrás")
                    }
                },
                actions = {
                    if (uiState.isChecking) {
                        IconButton(onClick = {
                            Log.d(logTag, "Cancel button clicked.")
                            viewModel.cancelChannelCheck()
                        }) {
                            Icon(Icons.Filled.Cancel, contentDescription = "Cancelar Comprobación")
                        }
                    } else {
                        IconButton(onClick = {
                            lastScrolledIndex = -1
                            Log.d(logTag, "Refresh button clicked. Starting channel check.")
                            viewModel.startChannelCheck()
                        }) {
                            Icon(Icons.Filled.Refresh, contentDescription = "Volver a Comprobar")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors( containerColor = MaterialTheme.colorScheme.surface )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(modifier = Modifier.fillMaxSize().padding(paddingValues).padding(horizontal = 16.dp, vertical = 8.dp)) {

            if (uiState.isChecking) {
                LinearProgressIndicator(
                    progress = { uiState.progress },
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                )
            } else if (uiState.channelChecks.isNotEmpty() && uiState.error == null) {
                Text(
                    "Comprobación finalizada.",
                    modifier = Modifier.padding(bottom = 8.dp).align(Alignment.CenterHorizontally),
                    style = MaterialTheme.typography.labelMedium
                )
            }

            val errorMessage = uiState.error
            if(errorMessage != null) {
                Text(
                    text = "Error al cargar lista inicial: $errorMessage", // Ser más específico
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(bottom=8.dp).align(Alignment.CenterHorizontally)
                )
            }

            // Mostrar mensaje inicial o si la lista está vacía y no hay error de carga
            if (uiState.channelChecks.isEmpty() && !uiState.isChecking && errorMessage == null) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Presiona el botón de refrescar para iniciar la comprobación de canales.")
                }
            } else if (uiState.channelChecks.isNotEmpty()){ // Solo mostrar LazyColumn si hay items
                LazyColumn(
                    state = lazyListState,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(
                        items = uiState.channelChecks,
                        key = { index, item -> item.channelSample.channelId ?: index.toString() } // Clave debe ser única
                    ) { index, checkInfo ->
                        DiagnosticChannelItem(info = checkInfo)
                    }
                }
            }
            // Si hay error y la lista está vacía (y no está cargando), el mensaje de error de arriba se mostrará.
        }
    }
}

@Composable
fun DiagnosticChannelItem(info: ChannelDiagnosticInfo) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            StatusIcon(status = info.status)
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = info.channelSample.name,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Medium
                )
                if (info.status == ChannelCheckStatus.ERROR || info.status == ChannelCheckStatus.PARTIAL) {
                    info.errorMessage?.let {
                        Text(
                            text = it,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (info.status == ChannelCheckStatus.ERROR) MaterialTheme.colorScheme.error else Color(0xFFFFA000) // Ámbar para parcial
                        )
                    }
                }
            }
            if (info.status == ChannelCheckStatus.CHECKING) {
                CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
            }
        }
    }
}

@Composable
fun StatusIcon(status: ChannelCheckStatus) {
    val icon: ImageVector
    val tint: Color
    val description: String

    when (status) {
        ChannelCheckStatus.PENDING -> { icon = Icons.Filled.HourglassEmpty; tint = LocalContentColor.current.copy(alpha = 0.6f); description = "Pendiente" }
        ChannelCheckStatus.CHECKING -> { icon = Icons.Filled.Sync; tint = MaterialTheme.colorScheme.primary; description = "Comprobando" }
        ChannelCheckStatus.OK -> { icon = Icons.Filled.CheckCircle; tint = Color(0xFF4CAF50); description = "OK" }
        ChannelCheckStatus.PARTIAL -> { icon = Icons.Filled.Warning; tint = Color(0xFFFFC107); description = "Parcial" }
        ChannelCheckStatus.ERROR -> { icon = Icons.Filled.Error; tint = MaterialTheme.colorScheme.error; description = "Error" }
    }
    Icon(imageVector = icon, contentDescription = description, tint = tint, modifier = Modifier.size(28.dp))
}