package com.tararira.onlysports.data.epg.parser

import android.util.Log
import com.tararira.onlysports.data.epg.model.EpgProgramme
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserException
import org.xmlpull.v1.XmlPullParserFactory
import java.io.IOException
import java.io.StringReader
import java.time.OffsetDateTime
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException

class EpgXmlParser {

    private val logTag = "EpgXmlParser"
    private val xmlTvDateTimeFormatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss Z")

    fun parse(xmlString: String): Map<String, List<EpgProgramme>> {
        val programsByChannel = mutableMapOf<String, MutableList<EpgProgramme>>()
        Log.d(logTag, "Iniciando parseo de EPG XML (${xmlString.length} caracteres)...")
        try {
            val factory = XmlPullParserFactory.newInstance(); factory.isNamespaceAware = true
            val parser = factory.newPullParser(); parser.setInput(StringReader(xmlString))
            var eventType = parser.eventType
            var currentProgrammeData: MutableMap<String, String>? = null
            var currentTag: String? = null; var textContent: StringBuilder? = null

            while (eventType != XmlPullParser.END_DOCUMENT) {
                when (eventType) {
                    XmlPullParser.START_TAG -> {
                        currentTag = parser.name?.lowercase()
                        if (currentTag == "programme") {
                            currentProgrammeData = mutableMapOf(
                                "channel" to (parser.getAttributeValue(null, "channel") ?: ""),
                                "start" to (parser.getAttributeValue(null, "start") ?: ""),
                                "stop" to (parser.getAttributeValue(null, "stop") ?: "")
                            )
                        } else if (currentProgrammeData != null && (currentTag == "title" || currentTag == "desc")) {
                            textContent = StringBuilder()
                        }
                    }
                    XmlPullParser.TEXT -> { textContent?.append(parser.text) }
                    XmlPullParser.END_TAG -> {
                        val tagName = parser.name?.lowercase()
                        if (tagName == "programme" && currentProgrammeData != null) {
                            buildAndAddProgramme(currentProgrammeData, programsByChannel)
                            currentProgrammeData = null
                        } else if (currentProgrammeData != null && textContent != null && (tagName == "title" || tagName == "desc")) {
                            currentProgrammeData[tagName] = textContent.toString().trim()
                            textContent = null
                        }
                        currentTag = null
                    }
                }
                eventType = parser.next()
            }
        } catch (e: Exception) { Log.e(logTag, "Error parseando EPG XML", e) }
        Log.i(logTag, "Parseo finalizado. Canales con EPG: ${programsByChannel.keys.size}")
        return programsByChannel
    }

    private fun buildAndAddProgramme(data: Map<String, String>, programMap: MutableMap<String, MutableList<EpgProgramme>>) {
        val channelId = data["channel"]; val title = data["title"]; val startStr = data["start"]; val stopStr = data["stop"]
        if (channelId.isNullOrBlank() || title.isNullOrBlank() || startStr.isNullOrBlank() || stopStr.isNullOrBlank()) return
        try {
            val startDateTime = OffsetDateTime.parse(startStr, xmlTvDateTimeFormatter)
            val stopDateTime = OffsetDateTime.parse(stopStr, xmlTvDateTimeFormatter)
            val programme = EpgProgramme(channelId, title, data["desc"]?.trim(), startDateTime, stopDateTime)
            programMap.getOrPut(channelId) { mutableListOf() }.add(programme)
        } catch (e: DateTimeParseException) { Log.w(logTag, "Error parseando fecha '$startStr'/'$stopStr' para '$channelId' ($title)", e)
        } catch (e: Exception) { Log.e(logTag, "Error construyendo EpgProgramme para '$channelId' ($title)", e) }
    }
}