package com.tararira.onlysports.navigation


sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Login : Screen("login") // Se mantiene por si se reactiva
    object Main : Screen("main")
    object ChannelList : Screen("channel_list")
    object Favorites : Screen("favorites")
    object Settings : Screen("settings")
    object Player : Screen("player/{channelId}") { // <-- MODIFICADO para aceptar channelId como argumento
        fun createRoute(channelId: String) = "player/$channelId"
    }
    object CodeEntry : Screen("code_entry") // Para diagnóstico
    object ChannelDiagnostics : Screen("channel_diagnostics")
    object ParentalPinEntry : Screen("parental_pin_entry/{channelIdToPlay}") { // <-- NUEVA RUTA
        fun createRoute(channelId: String) = "parental_pin_entry/$channelId"
    }
}