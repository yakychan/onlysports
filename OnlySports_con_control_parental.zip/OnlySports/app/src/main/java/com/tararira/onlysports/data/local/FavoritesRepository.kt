package com.tararira.onlysports.data.local

import android.content.Context
import androidx.datastore.core.DataStore // Asegúrate de tener este import
import androidx.datastore.preferences.core.Preferences // Asegúrate de tener este import
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import com.tararira.onlysports.AppPrefsDataStore // Asegúrate de tener este import
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class FavoritesRepository(context: Context) { // El contexto viene del constructor

    // Accede a la extensión AppPrefsDataStore usando la instancia de context
    private val dataStore: DataStore<Preferences> = context.AppPrefsDataStore

    companion object {
        // La clave sigue igual
        private val FAVORITE_CHANNEL_IDS = stringSetPreferencesKey("favorite_channel_ids")
    }

    // El resto del código no necesita cambios
    val favoriteChannelIdsFlow: Flow<Set<String>> = dataStore.data
        .map { preferences ->
            preferences[FAVORITE_CHANNEL_IDS] ?: emptySet()
        }

    suspend fun addFavorite(channelId: String) {
        dataStore.edit { preferences ->
            val currentFavorites = preferences[FAVORITE_CHANNEL_IDS] ?: emptySet()
            preferences[FAVORITE_CHANNEL_IDS] = currentFavorites + channelId
        }
    }

    suspend fun removeFavorite(channelId: String) {
        dataStore.edit { preferences ->
            val currentFavorites = preferences[FAVORITE_CHANNEL_IDS] ?: emptySet()
            preferences[FAVORITE_CHANNEL_IDS] = currentFavorites - channelId
        }
    }

    suspend fun toggleFavorite(channelId: String) {
        dataStore.edit { preferences ->
            val currentFavorites = preferences[FAVORITE_CHANNEL_IDS] ?: emptySet()
            if (currentFavorites.contains(channelId)) {
                preferences[FAVORITE_CHANNEL_IDS] = currentFavorites - channelId
            } else {
                preferences[FAVORITE_CHANNEL_IDS] = currentFavorites + channelId
            }
        }
    }
}