package com.tararira.onlysports.data.local

import android.content.Context
import android.util.Log
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import com.tararira.onlysports.AppPrefsDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.io.IOException

class SettingsRepository(context: Context) {

    private val dataStore: DataStore<Preferences> = context.AppPrefsDataStore
    private val logTag = "SettingsRepository"

    val epgUrlFlow: Flow<String> = dataStore.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { preferences -> preferences[PrefKeys.EPG_URL] ?: PrefKeys.DEFAULT_EPG_URL }

    val epgRefreshIntervalHoursFlow: Flow<Int> = dataStore.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { preferences -> preferences[PrefKeys.EPG_REFRESH_INTERVAL_HOURS] ?: PrefKeys.DEFAULT_EPG_REFRESH_INTERVAL_HOURS }

    suspend fun saveEpgSettings(url: String, intervalHours: Int) {
        val validInterval = if (intervalHours in PrefKeys.EPG_INTERVAL_OPTIONS) intervalHours else PrefKeys.DEFAULT_EPG_REFRESH_INTERVAL_HOURS
        try {
            dataStore.edit { preferences ->
                preferences[PrefKeys.EPG_URL] = url
                preferences[PrefKeys.EPG_REFRESH_INTERVAL_HOURS] = validInterval
            }
        } catch (e: Exception) { Log.e(logTag, "Error saving EPG settings", e) }
    }

    // --- FUNCIONES PARA CONTROL PARENTAL ---
    val parentalControlEnabledFlow: Flow<Boolean> = dataStore.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { preferences -> preferences[PrefKeys.PARENTAL_CONTROL_ENABLED] ?: false } // Deshabilitado por defecto

    val parentalPinFlow: Flow<String> = dataStore.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { preferences -> preferences[PrefKeys.PARENTAL_PIN] ?: PrefKeys.DEFAULT_PARENTAL_PIN }

    suspend fun saveParentalControlSettings(enabled: Boolean, pin: String) {
        // Validar PIN antes de guardar (longitud, etc.) si es necesario
        val validPin = pin.filter { it.isDigit() }.take(PrefKeys.MAX_PIN_LENGTH)
        if (validPin.length < PrefKeys.MIN_PIN_LENGTH) {
            Log.w(logTag, "PIN inválido para guardar: '$pin'. No se guardará el PIN. Habilitado: $enabled")
            // Solo guardar el estado enabled si el PIN es inválido pero se intenta guardar.
            // O podrías decidir no guardar nada y dar un error.
            dataStore.edit { preferences ->
                preferences[PrefKeys.PARENTAL_CONTROL_ENABLED] = enabled
            }
            return // No guardar PIN inválido
        }

        try {
            dataStore.edit { preferences ->
                preferences[PrefKeys.PARENTAL_CONTROL_ENABLED] = enabled
                preferences[PrefKeys.PARENTAL_PIN] = validPin
            }
        } catch (e: Exception) { Log.e(logTag, "Error saving parental control settings", e) }
    }

    // Para uso síncrono si es necesario, ej. en PlayerViewModel antes de navegar
    suspend fun getCurrentParentalControlEnabled(): Boolean {
        return parentalControlEnabledFlow.first()
    }

    suspend fun getCurrentParentalPin(): String {
        return parentalPinFlow.first()
    }
    // --- FIN FUNCIONES CONTROL PARENTAL ---
}
