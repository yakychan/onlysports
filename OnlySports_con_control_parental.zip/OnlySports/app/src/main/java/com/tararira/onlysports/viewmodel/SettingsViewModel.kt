package com.tararira.onlysports.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tararira.onlysports.data.local.SettingsRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class EpgSettingsUiState(
    val epgUrl: String = "",
    val selectedIntervalHours: Int = 24,
    val isLoading: Boolean = true,
    val showEpgSavedMessage: Boolean = false
)

class SettingsViewModel(
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val _showEpgSavedMessage = MutableStateFlow(false)

    val epgUiState: StateFlow<EpgSettingsUiState> = combine(
        settingsRepository.epgUrlFlow,
        settingsRepository.epgRefreshIntervalHoursFlow,
        _showEpgSavedMessage
    ) { url, interval, showMsg ->
        EpgSettingsUiState(
            epgUrl = url,
            selectedIntervalHours = interval,
            isLoading = false,
            showEpgSavedMessage = showMsg
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = EpgSettingsUiState(isLoading = true)
    )

    fun saveEpgSettings(newEpgUrl: String, newEpgInterval: Int) {
        viewModelScope.launch {
            settingsRepository.saveEpgSettings(newEpgUrl, newEpgInterval)
            _showEpgSavedMessage.value = true
            kotlinx.coroutines.delay(2000)
            _showEpgSavedMessage.value = false
        }
    }
}