package com.tararira.onlysports.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tararira.onlysports.data.epg.model.EpgProgramme
import com.tararira.onlysports.data.local.FavoritesRepository
import com.tararira.onlysports.data.local.PrefKeys
import com.tararira.onlysports.data.model.ChannelCategory
import com.tararira.onlysports.data.model.ChannelSample
import com.tararira.onlysports.data.repository.ChannelRepository
import com.tararira.onlysports.data.repository.ChannelRepository.ChannelDataResult
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.Duration
import java.time.OffsetDateTime
import java.time.ZoneId

data class CurrentEpgInfo(
    val programme: EpgProgramme?,
    val progress: Float?,
    val nextProgramme: EpgProgramme?
)

data class ChannelListUiState(
    val categories: Map<String, List<ChannelSample>> = emptyMap(),
    val currentEpg: Map<String, CurrentEpgInfo> = emptyMap(),
    val favoriteChannelIds: Set<String> = emptySet(),
    val isLoadingChannels: Boolean = true,
    val error: String? = null
)

class ChannelViewModel(
    private val channelRepository: ChannelRepository,
    private val favoritesRepository: FavoritesRepository,
    private val parentalControlViewModel: ParentalControlViewModel
) : ViewModel() {

    private val _channelResultFlow: StateFlow<ChannelDataResult> = channelRepository.channelDataFlow

    private val _categoriesFlow: StateFlow<List<ChannelCategory>> = _channelResultFlow
        .map { result ->
            if (result is ChannelDataResult.Success) result.categories else emptyList()
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val uiState: StateFlow<ChannelListUiState> = combine(
        _categoriesFlow,
        channelRepository.epgDataFlow,
        favoritesRepository.favoriteChannelIdsFlow,
        parentalControlViewModel.isCensoringActive,
        _channelResultFlow
    ) { categoriesList, rawEpgMap, favoriteIds, isCensoring, channelResult ->

        val filteredCategories = if (isCensoring) {
            categoriesList.filter { category -> category.categoryName !in PrefKeys.ADULT_CATEGORY_NAMES }
        } else {
            categoriesList
        }

        val categoriesMapForUi = filteredCategories.associate { category ->
            category.categoryName to category.samples.distinctBy { it.channelId }
        }.filterValues { it.isNotEmpty() }

        val allVisibleChannels = categoriesMapForUi.values.flatten()
        val currentEpgMap = calculateCurrentAndNextEpgWithProgress(allVisibleChannels, rawEpgMap ?: emptyMap())

        ChannelListUiState(
            categories = categoriesMapForUi,
            currentEpg = currentEpgMap,
            favoriteChannelIds = favoriteIds,
            isLoadingChannels = channelResult is ChannelDataResult.Loading,
            error = if (channelResult is ChannelDataResult.Error) channelResult.message else null
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = ChannelListUiState(isLoadingChannels = true)
    )

    val uniqueOrderedChannelIds: StateFlow<List<String>> = uiState
        .map { state ->
            state.categories.values.flatten().mapNotNull { it.channelId }.distinct()
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    init {
        refreshEpg()
    }

    fun refreshEpg() {
        channelRepository.refreshEpgInBackgroundIfNeeded()
    }

    private fun calculateCurrentAndNextEpgWithProgress(
        channels: List<ChannelSample>,
        rawEpg: Map<String, List<EpgProgramme>>
    ): Map<String, CurrentEpgInfo> {
        if (channels.isEmpty() || rawEpg.isEmpty()) return emptyMap()

        val currentEpgMap = mutableMapOf<String, CurrentEpgInfo>()
        val now = OffsetDateTime.now(ZoneId.systemDefault())
        val displayedChannelIds = channels.mapNotNull { it.channelId }.toSet()

        displayedChannelIds.forEach { channelId ->
            val programsForChannel = rawEpg[channelId]?.sortedBy { it.start }
            val currentProgram = programsForChannel?.find { it.isAiringAt(now) }
            var progress: Float? = null
            var nextProgram: EpgProgramme? = null

            if (currentProgram != null) {
                try {
                    val totalDuration = Duration.between(currentProgram.start, currentProgram.stop)
                    val elapsedDuration = Duration.between(currentProgram.start, now)
                    if (!totalDuration.isZero && !totalDuration.isNegative && !elapsedDuration.isNegative) {
                        progress = (elapsedDuration.toMillis().toFloat() / totalDuration.toMillis().toFloat()).coerceIn(0.0f, 1.0f)
                    }
                } catch (e: Exception) {
                    progress = null
                }
                val currentIndex = programsForChannel.indexOf(currentProgram)
                if (currentIndex != -1 && currentIndex + 1 < programsForChannel.size) {
                    nextProgram = programsForChannel[currentIndex + 1]
                }
            } else {
                nextProgram = programsForChannel?.firstOrNull { !it.start.isBefore(now) }
            }
            currentEpgMap[channelId] = CurrentEpgInfo(currentProgram, progress, nextProgram)
        }
        return currentEpgMap
    }

    fun toggleFavorite(channelId: String?) {
        if (channelId.isNullOrBlank()) return
        viewModelScope.launch {
            favoritesRepository.toggleFavorite(channelId)
        }
    }
}