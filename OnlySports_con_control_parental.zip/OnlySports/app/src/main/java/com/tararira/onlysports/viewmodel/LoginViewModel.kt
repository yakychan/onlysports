package com.tararira.onlysports.viewmodel

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tararira.onlysports.auth.AuthManager
// Ya no se necesita UserCredentials aquí
// import com.tararira.onlysports.data.model.UserCredentials
import com.tararira.onlysports.data.repository.UserRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch

data class LoginUiState(
    val isLoading: Boolean = false,
    val errorMessage: String? = null // Mensaje para mostrar en la UI (distinto del Toast)
)

class LoginViewModel(
    private val userRepository: UserRepository,
    private val authManager: AuthManager
) : ViewModel() {

    var usernameInput by mutableStateOf("")
    var passwordInput by mutableStateOf("")
    var rememberMeChecked by mutableStateOf(false)

    var uiState by mutableStateOf(LoginUiState())
        private set

    private val _loginResultFlow = MutableSharedFlow<LoginResult>()
    val loginResultFlow = _loginResultFlow.asSharedFlow()

    sealed class LoginResult {
        object Success : LoginResult()
        data class Error(val message: String) : LoginResult()
    }

    private val logTag = "LoginViewModel"

    init {
        Log.d(logTag, "ViewModel initialized.")
    }

    fun onLoginClicked() {
        val userToLogin = usernameInput.trim() // Usar versión trim
        val passToLogin = passwordInput // No trimmear contraseña

        Log.d(logTag, "onLoginClicked called. User: '$userToLogin', Pass: [PROTECTED], Remember: $rememberMeChecked")

        if (userToLogin.isBlank() || passToLogin.isBlank()) {
            Log.w(logTag, "Validation failed: Username or Password blank.")
            uiState = uiState.copy(errorMessage = "Usuario y contraseña requeridos.")
            return
        }
        uiState = uiState.copy(isLoading = true, errorMessage = null)
        Log.d(logTag, "Set isLoading = true. Launching login API call...")

        viewModelScope.launch {
            // --- LLAMAR A LA NUEVA FUNCIÓN DEL REPOSITORIO ---
            Log.d(logTag, "Coroutine started. Calling userRepository.loginUserApi...")
            val loginResponse = userRepository.loginUserApi(userToLogin, passToLogin)
            // --- FIN LLAMADA ---

            if (loginResponse == null) {
                // Error de red o comunicación con la API
                Log.e(logTag, "loginUserApi returned null (Network/Server Error). Emitting error.")
                uiState = uiState.copy(isLoading = false)
                _loginResultFlow.emit(LoginResult.Error("No se pudo conectar con el servidor."))
                return@launch
            }

            // Procesar la respuesta de la API
            if (loginResponse.success && loginResponse.username != null) {
                // Éxito desde la API
                Log.i(logTag, "API login SUCCESS for user '${loginResponse.username}'. Calling authManager.loginUser...")
                authManager.loginUser(loginResponse.username, rememberMeChecked)
                uiState = uiState.copy(isLoading = false)
                Log.i(logTag, "Emitting LoginResult.Success")
                _loginResultFlow.emit(LoginResult.Success)
            } else {
                // Fallo reportado por la API (usuario/pass incorrecto u otro error)
                val errorMessage = loginResponse.message ?: "Usuario o contraseña incorrectos."
                Log.w(logTag, "API login FAILED. Message: '$errorMessage'. Emitting error.")
                uiState = uiState.copy(isLoading = false)
                _loginResultFlow.emit(LoginResult.Error(errorMessage))
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        Log.d(logTag, "ViewModel cleared.")
    }
}