package com.tararira.onlysports.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tararira.onlysports.data.local.PrefKeys
import com.tararira.onlysports.viewmodel.ParentalControlViewModel
import com.tararira.onlysports.viewmodel.SettingsViewModel
import kotlinx.coroutines.launch

private enum class PinAction { NONE, DISABLE_CONTROL, CHANGE_PIN }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    settingsViewModel: SettingsViewModel,
    parentalControlViewModel: ParentalControlViewModel,
    onNavigateToDiagnostics: () -> Unit,
    onBackPressed: () -> Unit
) {
    val localContextForToast = LocalContext.current
    val scope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current

    val epgUiState by settingsViewModel.epgUiState.collectAsStateWithLifecycle()
    val isParentalControlEnabled by parentalControlViewModel.isEnabled.collectAsStateWithLifecycle()

    var showVerifyDialog by remember { mutableStateOf(false) }
    var pinAction by remember { mutableStateOf(PinAction.NONE) }
    var showChangePinSection by remember { mutableStateOf(false) }

    LaunchedEffect(epgUiState.showEpgSavedMessage) {
        if (epgUiState.showEpgSavedMessage) {
            Toast.makeText(localContextForToast, "Configuración EPG guardada", Toast.LENGTH_SHORT).show()
        }
    }

    if (showVerifyDialog) {
        VerifyPinDialog(
            action = pinAction,
            onDismiss = { showVerifyDialog = false },
            onPinVerified = {
                showVerifyDialog = false
                when (pinAction) {
                    PinAction.DISABLE_CONTROL -> {
                        parentalControlViewModel.setEnabled(false, "")
                        Toast.makeText(localContextForToast, "Control Parental Desactivado", Toast.LENGTH_SHORT).show()
                    }
                    PinAction.CHANGE_PIN -> {
                        showChangePinSection = true
                    }
                    else -> {}
                }
            },
            parentalControlViewModel = parentalControlViewModel
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Configuración") },
                navigationIcon = { IconButton(onClick = onBackPressed) { Icon(Icons.Filled.ArrowBack, "Atrás") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 32.dp, vertical = 16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (epgUiState.isLoading) {
                CircularProgressIndicator()
            } else {
                Text("Configuración EPG", style = MaterialTheme.typography.titleLarge)
                Spacer(modifier = Modifier.height(16.dp))
                var epgUrlInputState by remember(epgUiState.epgUrl) { mutableStateOf(epgUiState.epgUrl) }
                OutlinedTextField(
                    value = epgUrlInputState,
                    onValueChange = { epgUrlInputState = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("URL del Archivo EPG XML") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Next),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(16.dp))
                var selectedIntervalHoursState by remember(epgUiState.selectedIntervalHours) { mutableIntStateOf(epgUiState.selectedIntervalHours) }
                var intervalDropdownExpanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(
                    expanded = intervalDropdownExpanded,
                    onExpandedChange = { intervalDropdownExpanded = !intervalDropdownExpanded },
                ) {
                    OutlinedTextField(
                        value = "$selectedIntervalHoursState horas",
                        onValueChange = {}, readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = intervalDropdownExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = intervalDropdownExpanded,
                        onDismissRequest = { intervalDropdownExpanded = false }
                    ) {
                        PrefKeys.EPG_INTERVAL_OPTIONS.forEach { interval ->
                            DropdownMenuItem(
                                text = { Text("$interval horas") },
                                onClick = {
                                    selectedIntervalHoursState = interval
                                    intervalDropdownExpanded = false
                                }
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = {
                        settingsViewModel.saveEpgSettings(epgUrlInputState, selectedIntervalHoursState)
                        focusManager.clearFocus()
                    },
                    modifier = Modifier.fillMaxWidth(0.6f)
                ) { Text("Guardar Config. EPG") }

                Divider(modifier = Modifier.padding(vertical = 32.dp))

                Text("Control Parental", style = MaterialTheme.typography.titleLarge)
                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Activar Control Parental", style = MaterialTheme.typography.titleMedium)
                    Switch(
                        checked = isParentalControlEnabled,
                        onCheckedChange = { isEnabled ->
                            if (isEnabled) {
                                parentalControlViewModel.setEnabled(true, PrefKeys.DEFAULT_PARENTAL_PIN)
                                Toast.makeText(localContextForToast, "Control Parental Activado", Toast.LENGTH_SHORT).show()
                            } else {
                                pinAction = PinAction.DISABLE_CONTROL
                                showVerifyDialog = true
                            }
                        }
                    )
                }

                AnimatedVisibility(visible = isParentalControlEnabled) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = {
                                pinAction = PinAction.CHANGE_PIN
                                showVerifyDialog = true
                            },
                            modifier = Modifier.fillMaxWidth(0.6f)
                        ) {
                            Text("Cambiar PIN")
                        }
                    }
                }

                AnimatedVisibility(visible = showChangePinSection && isParentalControlEnabled) {
                    ChangePinSection(
                        onPinChanged = { newPin ->
                            parentalControlViewModel.changePin(newPin)
                            showChangePinSection = false
                            Toast.makeText(localContextForToast, "PIN actualizado correctamente", Toast.LENGTH_SHORT).show()
                        },
                        onCancel = { showChangePinSection = false }
                    )
                }

                Divider(modifier = Modifier.padding(vertical = 32.dp))

                Text("Herramientas", style = MaterialTheme.typography.titleLarge)
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = onNavigateToDiagnostics,
                    modifier = Modifier.fillMaxWidth(0.6f)
                ) {
                    Icon(Icons.Filled.NetworkCheck, null, Modifier.size(ButtonDefaults.IconSize))
                    Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                    Text("Comprobar Canales")
                }
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}

@Composable
private fun VerifyPinDialog(
    action: PinAction,
    onDismiss: () -> Unit,
    onPinVerified: () -> Unit,
    parentalControlViewModel: ParentalControlViewModel
) {
    var enteredPin by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val title = if (action == PinAction.DISABLE_CONTROL) "Desactivar Control Parental" else "Cambiar PIN"
    val description = "Por favor, ingrese su PIN actual para continuar."

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                Text(description)
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedTextField(
                    value = enteredPin,
                    onValueChange = { enteredPin = it },
                    label = { Text("PIN Actual") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword, imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = {
                        scope.launch {
                            if (parentalControlViewModel.verifyPinAndUnlock(enteredPin)) {
                                onPinVerified()
                            } else {
                                Toast.makeText(context, "PIN Incorrecto", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }),
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                scope.launch {
                    if (parentalControlViewModel.verifyPinAndUnlock(enteredPin)) {
                        onPinVerified()
                    } else {
                        Toast.makeText(context, "PIN Incorrecto", Toast.LENGTH_SHORT).show()
                    }
                }
            }) {
                Text("Verificar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}

@Composable
private fun ChangePinSection(onPinChanged: (String) -> Unit, onCancel: () -> Unit) {
    var newPin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    val context = LocalContext.current

    Column(
        modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        OutlinedTextField(
            value = newPin,
            onValueChange = { if (it.length <= PrefKeys.MAX_PIN_LENGTH && it.all { c -> c.isDigit() } ) newPin = it },
            label = { Text("Nuevo PIN") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            visualTransformation = PasswordVisualTransformation()
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = confirmPin,
            onValueChange = { if (it.length <= PrefKeys.MAX_PIN_LENGTH && it.all { c -> c.isDigit() } ) confirmPin = it },
            label = { Text("Confirmar Nuevo PIN") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            visualTransformation = PasswordVisualTransformation()
        )
        Spacer(modifier = Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            OutlinedButton(onClick = onCancel) { Text("Cancelar") }
            Button(onClick = {
                if (newPin.length >= PrefKeys.MIN_PIN_LENGTH && newPin == confirmPin) {
                    onPinChanged(newPin)
                } else {
                    Toast.makeText(context, "Los PINs no coinciden o son inválidos", Toast.LENGTH_SHORT).show()
                }
            }) { Text("Guardar Nuevo PIN") }
        }
    }
}