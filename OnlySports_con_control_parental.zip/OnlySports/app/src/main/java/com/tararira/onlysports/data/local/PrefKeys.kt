package com.tararira.onlysports.data.local

import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey

object PrefKeys {

    val FAVORITE_CHANNEL_IDS = stringSetPreferencesKey("favorite_channel_ids")

    val EPG_URL = stringPreferencesKey("epg_url")
    val EPG_REFRESH_INTERVAL_HOURS = intPreferencesKey("epg_refresh_interval_hours")
    val EPG_LAST_FETCH_TIMESTAMP_KEY = longPreferencesKey("epg_last_fetch_timestamp")

    const val DEFAULT_EPG_URL = "https://www.open-epg.com/files/argentina4.xml"
    const val DEFAULT_EPG_REFRESH_INTERVAL_HOURS = 24
    val EPG_INTERVAL_OPTIONS = listOf(6, 12, 24, 48)

    const val DEFAULT_JSON_URL = "http://IP/lista_encriptada.json"

    val PARENTAL_CONTROL_ENABLED = booleanPreferencesKey("parental_control_enabled_v1")
    val PARENTAL_PIN = stringPreferencesKey("parental_pin_v1")
    const val DEFAULT_PARENTAL_PIN = "6969"
    const val MIN_PIN_LENGTH = 4
    const val MAX_PIN_LENGTH = 8

    // --- LISTA DE CATEGORÍAS A OCULTAR ---
    val ADULT_CATEGORY_NAMES = setOf("XXX") // Añade más nombres aquí si es necesario, ej: setOf("XXX", "Adultos")
}