package com.tararira.onlysports.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class ValidationResponse(
    @SerialName("valid") val isValid: Boolean,
    @SerialName("message") val message: String? = null,
    @SerialName("username") val username: String? = null
)