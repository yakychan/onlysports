package com.tararira.onlysports.ui.screens

import android.util.Log
import androidx.compose.animation.animateColorAsState // Mantenemos para el CategoryHeader
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.tararira.onlysports.R
import com.tararira.onlysports.data.model.ChannelSample
import com.tararira.onlysports.viewmodel.ChannelListUiState
import com.tararira.onlysports.viewmodel.CurrentEpgInfo
import com.tararira.onlysports.viewmodel.SharedNavViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ChannelListScreen(
    uiState: ChannelListUiState,
    sharedViewModel: SharedNavViewModel,
    onChannelClick: (ChannelSample) -> Unit,
    onFavoriteClick: (String?) -> Unit,
    onBackPressed: () -> Unit
) {
    val sortedCategories = uiState.categories.entries.sortedBy { it.key }
    var expandedCategoryName by remember(sortedCategories, uiState.categories) {
        val focusId = sharedViewModel.channelToFocusAfterReturnInList.value
        if (focusId != null) {
            val catOfFocus = sortedCategories.find { entry -> entry.value.any { it.channelId == focusId } }?.key
            mutableStateOf(catOfFocus ?: sortedCategories.firstOrNull()?.key)
        } else {
            mutableStateOf(sortedCategories.firstOrNull()?.key)
        }
    }

    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    val channelIdToFocus by sharedViewModel.channelToFocusAfterReturnInList.collectAsStateWithLifecycle()
    val focusRequesters = remember { mutableMapOf<String, FocusRequester>() }

    // Efecto para scroll de categoría al top (sin cambios)
    LaunchedEffect(expandedCategoryName, sortedCategories, listState.layoutInfo.totalItemsCount) {
        val targetCategoryName = expandedCategoryName
        if (targetCategoryName != null && listState.layoutInfo.totalItemsCount > 0) {
            val categoryIndexInSortedList = sortedCategories.indexOfFirst { it.key == targetCategoryName }
            if (categoryIndexInSortedList != -1) {
                val targetItemIndex = categoryIndexInSortedList * 3
                Log.d("ChannelListScreen", "SCROLL_CAT: Scrolling to category header: '$targetCategoryName' at index $targetItemIndex")
                coroutineScope.launch {
                    try {
                        if (targetItemIndex >= 0 && targetItemIndex < listState.layoutInfo.totalItemsCount) {
                            listState.animateScrollToItem(index = targetItemIndex, scrollOffset = 0)
                        } else {
                            Log.w("ChannelListScreen", "SCROLL_CAT: Target index $targetItemIndex out of bounds (${listState.layoutInfo.totalItemsCount}).")
                        }
                    } catch (e: Exception) {
                        Log.e("ChannelListScreen", "SCROLL_CAT: Error scrolling to category header", e)
                    }
                }
            } else {
                Log.w("ChannelListScreen", "SCROLL_CAT: Category '$targetCategoryName' not found for scroll.")
            }
        }
    }

    // Efecto para restaurar foco (sin cambios)
    LaunchedEffect(channelIdToFocus, uiState.categories, listState.layoutInfo.totalItemsCount) {
        if (channelIdToFocus != null && uiState.categories.isNotEmpty() && listState.layoutInfo.totalItemsCount > 0) {
            Log.d("ChannelListScreen", "FOCUS_RESTORE: Attempting for channel ID: '$channelIdToFocus'")
            val categoryOfChannelToFocus = uiState.categories.entries.find { entry ->
                entry.value.any { it.channelId == channelIdToFocus }
            }?.key

            if (categoryOfChannelToFocus != null) {
                Log.d("ChannelListScreen", "FOCUS_RESTORE: Category for '$channelIdToFocus' is '$categoryOfChannelToFocus'. Current expanded: '$expandedCategoryName'")
                if (expandedCategoryName != categoryOfChannelToFocus) {
                    Log.d("ChannelListScreen", "FOCUS_RESTORE: Expanding category '$categoryOfChannelToFocus'")
                    expandedCategoryName = categoryOfChannelToFocus
                    delay(100) // Menor delay ya que no hay animación de visibilidad
                } else {
                    delay(50)
                }

                coroutineScope.launch {
                    delay(50)
                    val requester = focusRequesters[channelIdToFocus]
                    if (requester != null) {
                        try {
                            Log.d("ChannelListScreen", "FOCUS_RESTORE: Requesting focus for '$channelIdToFocus'")
                            requester.requestFocus()
                        } catch (e: Exception) {
                            Log.e("ChannelListScreen", "FOCUS_RESTORE: Error requesting focus for '$channelIdToFocus'", e)
                        }
                    } else {
                        Log.w("ChannelListScreen", "FOCUS_RESTORE: FocusRequester not found for '$channelIdToFocus'. Available: ${focusRequesters.keys}")
                    }
                    Log.d("ChannelListScreen", "FOCUS_RESTORE: Consuming focus request for '$channelIdToFocus'")
                    sharedViewModel.consumeFocusRequestForList()
                }
            } else {
                Log.w("ChannelListScreen", "FOCUS_RESTORE: Category not found for channel ID to focus: '$channelIdToFocus'. Consuming.")
                sharedViewModel.consumeFocusRequestForList()
            }
        } else if (channelIdToFocus != null && (uiState.categories.isEmpty() || listState.layoutInfo.totalItemsCount == 0 )) {
            Log.d("ChannelListScreen", "FOCUS_RESTORE: Conditions not met. ID: $channelIdToFocus, CategoriesEmpty: ${uiState.categories.isEmpty()}, TotalItems: ${listState.layoutInfo.totalItemsCount}")
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Canales por Categoría") },
                navigationIcon = { IconButton(onClick = onBackPressed) { Icon(Icons.Filled.ArrowBack, contentDescription = "Atrás") } },
                colors = TopAppBarDefaults.topAppBarColors( containerColor = MaterialTheme.colorScheme.surface )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Box( modifier = Modifier.fillMaxSize().padding(paddingValues) ) {
            when {
                uiState.isLoadingChannels -> { CircularProgressIndicator(modifier = Modifier.align(Alignment.Center)) }
                uiState.error != null -> { Text( text = "Error al cargar canales:\n${uiState.error}", color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center, modifier = Modifier.align(Alignment.Center).padding(16.dp) ) }
                sortedCategories.isEmpty() && !uiState.isLoadingChannels -> { Text( text = "No hay canales disponibles.", color = MaterialTheme.colorScheme.onBackground, textAlign = TextAlign.Center, modifier = Modifier.align(Alignment.Center).padding(16.dp) ) }
                else -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 16.dp),
                        state = listState
                    ) {
                        sortedCategories.forEach { (categoryName, channelsInCategory) ->
                            stickyHeader(
                                key = "header_$categoryName",
                                contentType = "CategoryHeader"
                            ) {
                                CategoryHeader(
                                    name = categoryName,
                                    isExpanded = categoryName == expandedCategoryName,
                                    onClick = { clickedName ->
                                        expandedCategoryName = if (expandedCategoryName == clickedName) null else clickedName
                                    }
                                )
                            }

                            item(
                                key = "channels_content_$categoryName",
                                contentType = "ChannelListItemsContainer"
                            ) {
                                // --- SIN AnimatedVisibility ---
                                if (categoryName == expandedCategoryName) {
                                    Column {
                                        channelsInCategory.forEach { channel ->
                                            val isFavorite = uiState.favoriteChannelIds.contains(channel.channelId)
                                            val currentEpgInfo = uiState.currentEpg[channel.channelId]
                                            val focusRequester = channel.channelId?.let { id ->
                                                focusRequesters.getOrPut(id) { FocusRequester() }
                                            } ?: remember { FocusRequester() }
                                            val interactionSource = remember { MutableInteractionSource() }
                                            val isItemFocused by interactionSource.collectIsFocusedAsState()

                                            // --- LAMBDAS REMEMBERIZADAS ---
                                            val rememberedOnChannelClick = remember<(ChannelSample) -> Unit> { { ch -> onChannelClick(ch) } }
                                            val rememberedOnFavoriteClick = remember<() -> Unit> { { onFavoriteClick(channel.channelId) } }


                                            ChannelItem(
                                                channel = channel,
                                                isFavorite = isFavorite,
                                                currentEpgInfo = currentEpgInfo,
                                                onChannelClick = rememberedOnChannelClick, // Usar lambda rememberizada
                                                onFavoriteClick = rememberedOnFavoriteClick, // Usar lambda rememberizada
                                                isFocused = isItemFocused,
                                                modifier = Modifier
                                                    .focusRequester(focusRequester)
                                                    .focusable(interactionSource = interactionSource)
                                            )
                                        }
                                    }
                                }
                                // --- FIN SIN AnimatedVisibility ---
                            }
                            item(
                                key = "divider_after_$categoryName",
                                contentType = "CategoryDivider"
                            ) {
                                if (categoryName == expandedCategoryName) {
                                    Divider(
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f),
                                        thickness = 1.dp,
                                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                                    )
                                } else {
                                    Spacer(modifier = Modifier.height(1.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CategoryHeader(name: String, isExpanded: Boolean, onClick: (String) -> Unit) {
    // Animación de color para el header se mantiene, es ligera
    val backgroundColor by animateColorAsState(
        targetValue = if (isExpanded) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.95f),
        animationSpec = tween(durationMillis = 200), label = "CHBg"
    )
    val textColor by animateColorAsState(
        targetValue = if (isExpanded) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
        animationSpec = tween(durationMillis = 200), label = "CHText"
    )
    Text(
        text = name.uppercase(),
        style = MaterialTheme.typography.titleMedium,
        color = textColor,
        modifier = Modifier.fillMaxWidth().clickable { onClick(name) }.background(backgroundColor).padding(horizontal = 24.dp, vertical = 12.dp)
    )
}

@Composable
fun ChannelItem(
    channel: ChannelSample,
    isFavorite: Boolean,
    currentEpgInfo: CurrentEpgInfo?,
    onChannelClick: (ChannelSample) -> Unit,
    onFavoriteClick: () -> Unit,
    isFocused: Boolean,
    modifier: Modifier = Modifier
) {
    val currentProgram = currentEpgInfo?.programme
    val progress = currentEpgInfo?.progress

    // --- SIN ANIMACIÓN PARA EL FONDO DEL ITEM ---
    val backgroundColor = if (isFocused) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f) else Color.Transparent
    // --- FIN SIN ANIMACIÓN ---

    Column(
        modifier = modifier
            .background(backgroundColor) // Aplicar color directamente
            .clickable { onChannelClick(channel) }
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp, horizontal = 24.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AsyncImage(model = ImageRequest.Builder(LocalContext.current).data(channel.iconUrl).placeholder(R.drawable.ic_placeholder).error(R.drawable.ic_placeholder).crossfade(true).build(), contentDescription = "${channel.name} logo", modifier = Modifier.size(48.dp), contentScale = ContentScale.Fit)
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                Text(text = channel.name, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onBackground, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(modifier = Modifier.height(3.dp))
                Text(text = if (currentProgram != null) "${currentProgram.getFormattedTimeRange()} - ${currentProgram.title}" else " ", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(modifier = Modifier.height(4.dp))
                if (progress != null) {
                    LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(4.dp).padding(vertical = 1.dp), color = Color(0xFF00BCD4), trackColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                } else {
                    Spacer(modifier = Modifier.height(4.dp).padding(vertical = 1.dp))
                }
            }
            Spacer(modifier = Modifier.width(16.dp))
            IconButton(onClick = onFavoriteClick, modifier = Modifier.size(40.dp)) {
                Icon(imageVector = if (isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, contentDescription = if (isFavorite) "Quitar de favoritos" else "Añadir a favoritos", tint = if (isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
            }
        }
        Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f), thickness = 0.5.dp, modifier = Modifier.padding(start = 24.dp + 48.dp + 16.dp, end = 24.dp))
    }
}