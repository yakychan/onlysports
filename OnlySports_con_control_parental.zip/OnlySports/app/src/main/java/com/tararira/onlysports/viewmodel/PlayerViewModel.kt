package com.tararira.onlysports.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tararira.onlysports.data.epg.model.EpgProgramme
import com.tararira.onlysports.data.model.ChannelSample
import com.tararira.onlysports.data.repository.ChannelRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.Duration
import java.time.OffsetDateTime
import java.time.ZoneId

data class PlayerUiState(
    val channelSamples: List<ChannelSample> = emptyList(),
    val isLoading: Boolean = true,
    val loadingError: String? = null,
    val fatalError: String? = null,
    val playbackError: String? = null,
    val currentEpgInfo: CurrentEpgInfo? = null
)

class PlayerViewModel(
    private val sharedNavViewModel: SharedNavViewModel,
    private val channelRepository: ChannelRepository
) : ViewModel() {

    private val logTag = "PlayerViewModel"
    private val _uiState = MutableStateFlow(PlayerUiState())
    val uiState: StateFlow<PlayerUiState> = _uiState.asStateFlow()

    private val rawEpgDataFlow: StateFlow<Map<String, List<EpgProgramme>>?> = channelRepository.epgDataFlow

    init {
        observeSharedChannelId()
    }

    private fun observeSharedChannelId() {
        viewModelScope.launch {
            sharedNavViewModel.selectedChannelId
                .filterNotNull()
                .distinctUntilChanged()
                .collectLatest { id ->
                    loadChannelDataAndEpg(id)
                }
        }
    }

    private fun loadChannelDataAndEpg(channelId: String) {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isLoading = true,
                    loadingError = null,
                    fatalError = null,
                    playbackError = null,
                    channelSamples = emptyList(),
                    currentEpgInfo = null
                )
            }

            val samplesResult = channelRepository.getChannelsById(channelId)
            val currentEpg = calculateSingleCurrentEpgInfo(channelId, rawEpgDataFlow.value)

            if (samplesResult.isSuccess) {
                val samples = samplesResult.getOrThrow()
                if (samples.isNotEmpty()) {
                    _uiState.update {
                        it.copy(
                            channelSamples = samples,
                            isLoading = false,
                            currentEpgInfo = currentEpg
                        )
                    }
                } else {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            loadingError = "Canal '$channelId' no encontrado o sin fuentes.",
                            currentEpgInfo = currentEpg
                        )
                    }
                }
            } else {
                val error = samplesResult.exceptionOrNull()
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        loadingError = "Error al cargar datos: ${error?.message ?: "Desconocido"}",
                        currentEpgInfo = currentEpg
                    )
                }
            }
        }
    }


    private fun calculateSingleCurrentEpgInfo(
        channelId: String?,
        rawEpg: Map<String, List<EpgProgramme>>?
    ): CurrentEpgInfo? {
        if (channelId == null || rawEpg == null) {
            return null
        }
        val programsForChannel = rawEpg[channelId]?.sortedBy { it.start }
        if (programsForChannel.isNullOrEmpty()){
            return CurrentEpgInfo(null, null, null)
        }

        val now = OffsetDateTime.now(ZoneId.systemDefault())
        val currentProgram = programsForChannel.find { it.isAiringAt(now) }
        var progress: Float? = null
        var nextProgram: EpgProgramme? = null

        if (currentProgram != null) {
            try {
                val totalDuration = Duration.between(currentProgram.start, currentProgram.stop)
                val elapsedDuration = Duration.between(currentProgram.start, now)
                if (!totalDuration.isZero && !totalDuration.isNegative && !elapsedDuration.isNegative) {
                    progress = (elapsedDuration.toMillis().toFloat() / totalDuration.toMillis().toFloat()).coerceIn(0.0f, 1.0f)
                }
            } catch (e: Exception) {
                progress = null
            }
            val currentIndex = programsForChannel.indexOf(currentProgram)
            if (currentIndex != -1 && currentIndex + 1 < programsForChannel.size) {
                nextProgram = programsForChannel[currentIndex + 1]
            }
        } else {
            nextProgram = programsForChannel.firstOrNull { !it.start.isBefore(now) }
        }
        return CurrentEpgInfo(currentProgram, progress, nextProgram)
    }

    fun setPlaybackError(errorMessage: String?) {
        _uiState.update { it.copy(playbackError = errorMessage) }
    }

    fun setFatalError(errorMessage: String?) {
        _uiState.update { it.copy(fatalError = errorMessage, isLoading = false, playbackError = null) }
    }

    override fun onCleared() {
        super.onCleared()
    }
}