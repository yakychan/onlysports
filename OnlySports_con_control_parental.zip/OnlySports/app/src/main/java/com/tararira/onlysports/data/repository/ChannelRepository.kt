package com.tararira.onlysports.data.repository

import android.content.Context
import android.util.Log
import androidx.datastore.preferences.core.edit
import com.tararira.onlysports.AppPrefsDataStore
import com.tararira.onlysports.data.epg.model.EpgProgramme
import com.tararira.onlysports.data.epg.parser.EpgXmlParser
import com.tararira.onlysports.data.local.PrefKeys
import com.tararira.onlysports.data.model.ChannelCategory
import com.tararira.onlysports.data.model.ChannelSample
import com.tararira.onlysports.data.remote.ApiService
import com.tararira.onlysports.util.EncryptionHelper // Asegúrate que la ruta sea correcta
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class ChannelRepository(
    private val context: Context,
    private val apiService: ApiService
) {
    companion object {
        private const val EPG_FILENAME = "epg_cache.xml"
        private val EPG_CACHE_DURATION_MILLIS = TimeUnit.HOURS.toMillis(PrefKeys.DEFAULT_EPG_REFRESH_INTERVAL_HOURS.toLong())
        // ¡¡¡ASEGÚRATE DE QUE ESTA URL APUNTE A TU lista.json ENCRIPTADO!!!
        private const val CHANNELS_JSON_URL = "http://IP/lista_encriptada.json"
    }

    private val logTag = "ChannelRepository"
    private val repositoryScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val _channelDataState = MutableStateFlow<ChannelDataResult>(ChannelDataResult.Loading)
    val channelDataFlow: StateFlow<ChannelDataResult> = _channelDataState.asStateFlow()
    private var allChannelsCache: List<ChannelSample>? = null

    private val _epgDataStateFlow = MutableStateFlow<Map<String, List<EpgProgramme>>?>(null)
    val epgDataFlow: StateFlow<Map<String, List<EpgProgramme>>?> = _epgDataStateFlow.asStateFlow()
    private val isEpgRefreshing = AtomicBoolean(false)
    private var lastEpgFetchTimeMillis: Long = 0L
    private val epgUrl = PrefKeys.DEFAULT_EPG_URL
    private val epgParser = EpgXmlParser()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS) // Timeout para conexión
        .readTimeout(90, TimeUnit.SECONDS)    // Timeout para leer la respuesta (puede ser largo si el JSON es grande)
        .build()
    private val jsonParser = Json {
        ignoreUnknownKeys = true
        coerceInputValues = true
        isLenient = true
    }

    sealed class ChannelDataResult {
        object Loading : ChannelDataResult()
        data class Success(val categories: List<ChannelCategory>) : ChannelDataResult()
        data class Error(val message: String) : ChannelDataResult()
    }

    private val initialLoadTriggered = AtomicBoolean(false) // Para asegurar una sola carga inicial

    init {
        Log.i(logTag, "Repository Initializing. apiService instance: $apiService")
        repositoryScope.launch { loadInitialEpgFromFileCache() }

        // Disparar la carga inicial de canales solo una vez
        if (initialLoadTriggered.compareAndSet(false, true)) {
            Log.i(logTag, "INIT: Triggering initial loadAndDecryptChannels via forceRefreshChannels.")
            forceRefreshChannels() // Llama a la función que ahora tiene la lógica de carga y desencriptación
        } else {
            // Este log es normal si el repositorio es un singleton y ya se inicializó
            Log.w(logTag, "INIT: Initial loadAndDecryptChannels already triggered or was in progress by this instance.")
        }
    }

    private suspend fun loadAndDecryptChannels() {
        // Siempre poner en Loading al iniciar esta función si no está ya en error y se fuerza
        // Esto permite que un forceRefresh desde un estado de Error también muestre Loading
        if (!(_channelDataState.value is ChannelDataResult.Loading && _channelDataState.value !is ChannelDataResult.Error)) {
            _channelDataState.value = ChannelDataResult.Loading
        }
        Log.i(logTag, ">>> loadAndDecryptChannels: EXECUTION STARTING. URL: $CHANNELS_JSON_URL. Current state before starting: ${_channelDataState.value::class.simpleName}")

        withContext(Dispatchers.IO) { // Asegurar que toda la operación se hace en IO
            Log.d(logTag, "loadAndDecryptChannels: Now running on Dispatchers.IO thread: ${Thread.currentThread().name}")
            try {
                Log.i(logTag, ">>> STEP 1: Calling apiService.getRawEncryptedChannels for URL: $CHANNELS_JSON_URL")
                val responseBody = apiService.getRawEncryptedChannels(CHANNELS_JSON_URL)
                Log.i(logTag, "<<< STEP 1: apiService.getRawEncryptedChannels FINISHED. Response body is present: ${responseBody != null}")

                Log.d(logTag, ">>> STEP 2: Reading response body as string...")
                val encryptedBase64String = responseBody.string() // Leer el cuerpo
                Log.i(logTag, "<<< STEP 2: Response body read. Length: ${encryptedBase64String.length}")

                if (encryptedBase64String.isBlank()) {
                    Log.e(logTag, "Encrypted string from server is BLANK. Throwing IOException.")
                    throw IOException("Respuesta vacía o en blanco del servidor para la lista de canales.")
                }
                Log.d(logTag, "Received encrypted channel data. Base64 starts with: ${encryptedBase64String.take(80)}...")

                Log.d(logTag, ">>> STEP 3: Attempting to decrypt using EncryptionHelper.decryptAES...")
                val decryptedJsonString = EncryptionHelper.decryptAES(encryptedBase64String)

                if (decryptedJsonString == null) {
                    Log.e(logTag, "!!! DECRYPTION FAILED. EncryptionHelper.decryptAES returned null. Check Key/IV/Method and data integrity.")
                    throw IOException("Fallo al desencriptar la lista de canales. Clave/IV/Método incorrectos o datos corruptos.")
                }
                Log.i(logTag, "<<< STEP 3: Decryption SUCCESS. JSON length: ${decryptedJsonString.length}. Attempting JSON parsing...")
                Log.v(logTag, "Decrypted JSON Preview (first 500 chars): ${decryptedJsonString.take(500)}")

                Log.d(logTag, ">>> STEP 4: Parsing decrypted JSON string into List<ChannelCategory>...")
                // ASUNCIÓN: El JSON raíz desencriptado es un ARRAY de objetos ChannelCategory
                val categories: List<ChannelCategory> = jsonParser.decodeFromString(decryptedJsonString)
                Log.i(logTag, "<<< STEP 4: JSON Parsing SUCCESS. Parsed ${categories.size} categories.")

                allChannelsCache = categories.flatMap { it.samples ?: emptyList() } // Manejar samples nulos
                Log.d(logTag, "Updated allChannelsCache with ${allChannelsCache?.size ?: 0} total samples.")
                _channelDataState.value = ChannelDataResult.Success(categories)
                Log.i(logTag, ">>> Channel data loaded, decrypted, parsed, and processed successfully.")

            } catch (e: kotlinx.serialization.SerializationException) {
                Log.e(logTag, "!!! JSON PARSING ERROR after decryption: ${e.message} !!!", e)
                _channelDataState.value = ChannelDataResult.Error("Error al parsear datos de canales: ${e.message}")
                allChannelsCache = null
            } catch (e: IOException) { // Captura errores de red (ej. fallo de conexión) o I/O (ej. string vacío)
                Log.e(logTag, "!!! NETWORK/IO ERROR during channel load/decrypt: ${e.message} !!!", e)
                _channelDataState.value = ChannelDataResult.Error("Error de red o datos: ${e.message}")
                allChannelsCache = null
            } catch (t: Throwable) { // Captura genérica para otros errores inesperados
                Log.e(logTag, "!!! UNEXPECTED THROWABLE during channel load/decrypt: ${t.message} !!!", t)
                _channelDataState.value = ChannelDataResult.Error("Error desconocido cargando canales: ${t.message}")
                allChannelsCache = null
            }
        }
        Log.i(logTag, ">>> loadAndDecryptChannels: EXECUTION FINISHED. Final state of _channelDataState: ${_channelDataState.value::class.simpleName}")
    }

    fun forceRefreshChannels() {
        Log.i(logTag, ">>> forceRefreshChannels called. Current _channelDataState: ${_channelDataState.value::class.simpleName}")
        // Permitir forzar el refresco incluso si ya está cargando, cancelando la anterior implícitamente por el scope de launch
        // o simplemente no hacer nada si ya está cargando para evitar trabajo duplicado.
        // La lógica actual de 'loadAndDecryptChannels' ya pone en Loading al inicio.
        repositoryScope.launch {
            loadAndDecryptChannels()
        }
    }

    // --- Lógica de EPG (Restaurada completamente) ---
    private suspend fun loadInitialEpgFromFileCache() {
        Log.d(logTag, "Init: Loading initial EPG from file cache...")
        readEpgFromFile()?.let { parseAndEmitEpg(it) }
            ?: Log.d(logTag, "Init: No initial EPG cache file found.")
    }

    private suspend fun readEpgFromFile(): String? = withContext(Dispatchers.IO) {
        try { File(context.filesDir, EPG_FILENAME).takeIf { it.exists() }?.readText(Charsets.UTF_8) }
        catch (e: IOException) { Log.e(logTag, "Error reading EPG file", e); null }
    }

    private suspend fun saveEpgToFile(xmlString: String): Boolean = withContext(Dispatchers.IO) {
        try { File(context.filesDir, EPG_FILENAME).writeText(xmlString, Charsets.UTF_8); true }
        catch (e: IOException) { Log.e(logTag, "Error saving EPG file", e); false }
    }

    private suspend fun getLastEpgFetchTimestamp(): Long = withContext(Dispatchers.IO) {
        try { context.AppPrefsDataStore.data.map { prefs -> prefs[PrefKeys.EPG_LAST_FETCH_TIMESTAMP_KEY] ?: 0L }.first() }
        catch (e: Exception) { Log.e(logTag, "Error getting EPG timestamp", e); 0L }
    }

    private suspend fun updateLastEpgFetchTimestamp(timestamp: Long) {
        try { context.AppPrefsDataStore.edit { prefs -> prefs[PrefKeys.EPG_LAST_FETCH_TIMESTAMP_KEY] = timestamp } }
        catch (e: Exception) { Log.e(logTag, "Error updating EPG timestamp", e) }
    }

    fun refreshEpgInBackgroundIfNeeded() {
        if (isEpgRefreshing.compareAndSet(false, true)) {
            Log.i(logTag, "refreshEpgInBackgroundIfNeeded: Starting check...")
            repositoryScope.launch {
                var needsRefresh = false
                val currentEpgUrl = epgUrl
                val refreshIntervalMillis = EPG_CACHE_DURATION_MILLIS
                try {
                    val now = System.currentTimeMillis()
                    val lastFetchTime = getLastEpgFetchTimestamp()
                    needsRefresh = (now - lastFetchTime >= refreshIntervalMillis) || _epgDataStateFlow.value == null
                    Log.d(logTag, "EPG Check - URL:'$currentEpgUrl', Interval:${refreshIntervalMillis / (3600 * 1000)}h, NeedsRefresh:$needsRefresh")

                    if (needsRefresh && currentEpgUrl.isNotBlank()) {
                        Log.i(logTag, "EPG refresh needed. Fetching from: $currentEpgUrl")
                        fetchEpgXml(currentEpgUrl)?.let { fetchedXml ->
                            Log.d(logTag, "EPG downloaded (${fetchedXml.length} chars). Saving/Parsing...")
                            if (saveEpgToFile(fetchedXml)) {
                                updateLastEpgFetchTimestamp(now)
                            } else {
                                Log.e(logTag, "Failed to save EPG file.")
                            }
                            parseAndEmitEpg(fetchedXml)
                        } ?: Log.e(logTag, "Failed to download new EPG from $currentEpgUrl.")
                    } else if (!needsRefresh && _epgDataStateFlow.value == null) {
                        Log.d(logTag,"EPG cache valid but memory empty. Loading from file...")
                        readEpgFromFile()?.let { parseAndEmitEpg(it) }
                    } else if (currentEpgUrl.isBlank()) {
                        Log.w(logTag, "EPG URL is blank, cannot refresh.")
                    } else {
                        Log.i(logTag, "EPG refresh not needed or already loaded.")
                    }
                } catch (e: Exception) {
                    Log.e(logTag, "Error during background EPG refresh check", e)
                } finally {
                    isEpgRefreshing.set(false)
                    Log.d(logTag, "EPG refresh check finished.")
                }
            }
        } else {
            Log.d(logTag, "EPG refresh already in progress.")
        }
    }

    private suspend fun parseAndEmitEpg(xmlString: String) {
        Log.d(logTag, "Parsing EPG XML (${xmlString.length} chars)...")
        try {
            val parsedData = withContext(Dispatchers.Default) { epgParser.parse(xmlString) }
            _epgDataStateFlow.value = parsedData
            lastEpgFetchTimeMillis = System.currentTimeMillis()
            Log.i(logTag, "EPG data parsed and emitted (${parsedData.size} channels with EPG).")
        } catch (e: Exception) {
            Log.e(logTag, "Error parsing EPG XML for emission", e)
            _epgDataStateFlow.value = null
        }
    }

    private suspend fun fetchEpgXml(url: String): String? = withContext(Dispatchers.IO) {
        if (url.isBlank()) return@withContext null
        val request = Request.Builder().url(url).build()
        Log.d(logTag, "fetchEpgXml: Requesting $url")
        try {
            okHttpClient.newCall(request).execute().use { response ->
                Log.d(logTag, "fetchEpgXml: Response Code ${response.code} for $url")
                if (response.isSuccessful) response.body?.string() else null
            }
        } catch (e: IOException) { Log.e(logTag, "IOException during EPG fetch $url", e); null }
        catch (e: Exception) { Log.e(logTag, "Generic Exception during EPG fetch $url", e); null }
    }
    // --- Fin Lógica de EPG ---

    // --- Funciones de Acceso a Datos (restauradas) ---
    suspend fun getCategorizedChannels(): Result<Map<String, List<ChannelSample>>> {
        return when (val result = _channelDataState.value) {
            is ChannelDataResult.Success -> {
                Log.d(logTag, "getCategorizedChannels from Success state with ${result.categories.size} categories.")
                val processedMap = result.categories.associate { category ->
                    val uniqueSamples = (category.samples ?: emptyList())
                        .filter { !it.channelId.isNullOrBlank() }
                        .distinctBy { it.channelId }
                    category.categoryName to uniqueSamples
                }.filterValues { it.isNotEmpty() }
                Result.success(processedMap)
            }
            is ChannelDataResult.Error -> {
                Log.e(logTag, "getCategorizedChannels returning error: ${result.message}")
                Result.failure(IOException(result.message))
            }
            is ChannelDataResult.Loading -> {
                Log.w(logTag, "getCategorizedChannels called while data is Loading. Returning failure.")
                Result.failure(IllegalStateException("Channel data is currently loading."))
            }
        }
    }

    suspend fun getChannelsById(channelId: String): Result<List<ChannelSample>> {
        val cache = allChannelsCache
        return if (cache != null) {
            Log.d(logTag, "getChannelsById '$channelId' - Using memory cache with ${cache.size} total samples.")
            Result.success(cache.filter { it.channelId == channelId })
        } else {
            Log.w(logTag, "getChannelsById '$channelId' - Cache not ready. State: ${_channelDataState.value::class.simpleName}")
            Result.failure(IllegalStateException("Cache de canales no inicializada o carga en progreso."))
        }
    }

    suspend fun getFavoriteChannelDetails(favoriteIds: Set<String>): Result<List<ChannelSample>> {
        val cache = allChannelsCache
        return if (cache != null) {
            Log.d(logTag, "getFavoriteChannelDetails - Using memory cache for ${favoriteIds.size} IDs.")
            val favoriteMap = cache
                .filter { it.channelId in favoriteIds && !it.channelId.isNullOrBlank() }
                .associateBy { it.channelId!! }
            Result.success(favoriteMap.values.toList())
        } else {
            Log.w(logTag, "getFavoriteChannelDetails - Cache not ready. State: ${_channelDataState.value::class.simpleName}")
            Result.failure(IllegalStateException("Cache de canales no inicializada o carga en progreso."))
        }
    }

    suspend fun getFlatUniqueChannels(): Result<List<ChannelSample>> {
        val cache = allChannelsCache
        return if (cache != null) {
            Log.d(logTag, "getFlatUniqueChannels - Using memory cache.")
            val uniqueList = cache
                .filter { !it.channelId.isNullOrBlank() }
                .distinctBy { it.channelId }
            Result.success(uniqueList)
        } else {
            Log.w(logTag, "getFlatUniqueChannels - Cache not ready. State: ${_channelDataState.value::class.simpleName}")
            Result.failure(IllegalStateException("Cache de canales no inicializada o carga en progreso."))
        }
    }

    fun clearScope() {
        Log.i(logTag, "Repository scope cancelling...")
        repositoryScope.cancel()
        Log.i(logTag, "Repository scope cancelled.")
    }
}