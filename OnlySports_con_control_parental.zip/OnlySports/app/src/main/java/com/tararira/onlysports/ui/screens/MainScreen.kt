package com.tararira.onlysports.ui.screens

import android.app.Activity // Necesario para cerrar la actividad
import android.widget.Toast // Necesario para el mensaje
import androidx.activity.compose.BackHandler // Necesario para interceptar atrás
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue // Importar delegados
import androidx.compose.runtime.mutableStateOf // Importar estado mutable
import androidx.compose.runtime.remember // Importar remember
import androidx.compose.runtime.setValue // Importar delegados
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext // Necesario para obtener contexto/actividad
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.tararira.onlysports.R

// Constante para el tiempo de espera entre pulsaciones (en milisegundos)
private const val BACK_PRESS_EXIT_DELAY = 2000L // 2 segundos

@Composable
fun MainScreen(
    onNavigateToChannels: () -> Unit,
    onNavigateToFavorites: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val context = LocalContext.current
    // Intentar obtener la actividad desde el contexto
    val activity = context as? Activity

    // Estado para guardar el timestamp de la última pulsación de "Atrás"
    var backPressedTime by remember { mutableStateOf(0L) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        // Contenido principal de la pantalla (los 3 iconos)
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(32.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            MainMenuItem(
                text = "Canales",
                iconResId = R.drawable.ic_channels,
                onClick = onNavigateToChannels
            )
            Spacer(modifier = Modifier.width(48.dp))
            MainMenuItem(
                text = "Favoritos",
                iconResId = R.drawable.ic_favorites,
                onClick = onNavigateToFavorites
            )
            Spacer(modifier = Modifier.width(48.dp))
            MainMenuItem(
                text = "Configuración",
                iconResId = R.drawable.ic_settings,
                onClick = onNavigateToSettings
            )
        }

        // --- INICIO: Lógica para doble pulsación atrás ---
        BackHandler(enabled = true) { // true para interceptar siempre en esta pantalla
            val currentTime = System.currentTimeMillis()
            if (currentTime - backPressedTime < BACK_PRESS_EXIT_DELAY) {
                // Si la segunda pulsación es dentro del tiempo límite, cerrar la app
                activity?.finish() // Cierra la actividad actual
            } else {
                // Si es la primera pulsación o pasó mucho tiempo, mostrar mensaje
                Toast.makeText(context, "Presiona Atrás de nuevo para salir", Toast.LENGTH_SHORT).show()
                // Actualizar el tiempo de la última pulsación
                backPressedTime = currentTime
            }
        }
        // --- FIN: Lógica para doble pulsación atrás ---
    }
}

// El Composable MainMenuItem no necesita cambios
@Composable
fun MainMenuItem(
    text: String,
    iconResId: Int,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .size(width = 180.dp, height = 150.dp)
            .clickable(onClick = onClick),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                painter = painterResource(id = iconResId),
                contentDescription = text,
                modifier = Modifier.size(64.dp),
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}